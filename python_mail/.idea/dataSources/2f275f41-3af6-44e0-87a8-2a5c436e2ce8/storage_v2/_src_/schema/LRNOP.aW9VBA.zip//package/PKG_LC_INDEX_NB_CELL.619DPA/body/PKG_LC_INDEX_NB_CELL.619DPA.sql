create PACKAGE BODY PKG_LC_INDEX_NB_CELL AS
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_3
    --out：OMC_NB_8
    PROCEDURE PROC_OMC_NB_8(V_DATE_THRESHOLD_START VARCHAR2) IS
    --v_date_start  date;
    --v_date_end   date;
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'OMC_NB_8';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        --或拼接待插入分区名
        --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;

        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');

        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        s_date,
        s_month,
        s_week,
        s_day,
        0 as s_hour,
        --min(start_time) start_time,
        cast(to_date(to_char(s_date, ''yyyy-mm-dd''),''yyyy-mm-dd'') as timestamp) as start_time,
        enb_id,
        cell_id,
        tac,
        ecgi,
        vendor,
        100*(decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4))) nb_0001,
        sum(nb_0002) nb_0002,
        sum(nb_0003) nb_0003,
        100*(decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4))) nb_0004,
        sum(nb_0005) nb_0005,
        sum(nb_0006) nb_0006,
        round(avg(nb_0007),2) nb_0007,
        max(nb_0008) nb_0008,
        100*(decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4))) nb_0009,
        100*(decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4))) nb_0010,
        sum(nb_0011) nb_0011,
        sum(nb_0012) nb_0012,
        sum(nb_0013) nb_0013,
        sum(nb_0014) nb_0014,
        case when avg(nb_0015) >= 0 then null else decode(avg(nb_0015),null,null,round(avg(nb_0015))) end nb_0015
        from OMC_NB_3 partition('||v_partition_name||')
        group by s_date, s_month, s_week, s_day, enb_id, cell_id, tac, ecgi, vendor';
        commit;
        
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') group by s_date, ecgi having count(1)>1 )'
        into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 天级数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
    END PROC_OMC_NB_8;
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_8
    --out：OMC_NB_9
    PROCEDURE PROC_OMC_NB_9(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_date_start  date;
    v_date_end   date;
    v_date_start_vc varchar2(10);--用于指定分区号
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_ssql_t1 clob;
    v_ssql_t2 clob;
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'OMC_NB_9';
        --从系统中获取待插入分区名
        /*select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611*/
        --或拼接待插入分区名
        --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;

        --返回输入时间戳所在周上周周一的日期，in：20190624~20190630 out：2019/06/17
        select (trunc(next_day(to_date(v_date_threshold_start,'yyyymmdd'),2))-14) into v_date_start from dual;--2019/06/17
        select (trunc(next_day(to_date(v_date_threshold_start,'yyyymmdd'),2))-14) + 6 into v_date_end from dual;--2019/06/23
        v_date_start_vc := to_char(v_date_start, 'yyyymmdd');--20190617

        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');

        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_start_vc; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
 
        
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_start_vc||''','''||v_date_start_vc||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
    
        --循环拼接分区表，遍历多日数据
        while v_date_start <= v_date_end loop
          v_partition_name :='P_'||to_char(v_date_start, 'yyyymmdd');
          if v_date_start <> v_date_end 
            then 
              v_ssql_t1 := v_ssql_t1 || 'select * from OMC_NB_8 PARTITION('||v_partition_name||')
              union all ';
          else 
              v_ssql_t1 := v_ssql_t1 || 'select * from OMC_NB_8 PARTITION('||v_partition_name||')';
          end if;
          v_date_start := v_date_start + 1;
        end loop; --2019/07/01
        
        --NB周级数据插入
        v_ssql_t2 := 
        'insert /*+append */ into '||v_tbname||'
        select 
        to_date('||v_date_start_vc||', ''yyyymmdd'') as s_date,
        min(s_month) s_month,
        min(s_week) s_week,
        min(s_day) s_day,
        min(s_hour) s_hour,
        min(start_time) start_time,
        enb_id,
        cell_id,
        tac,
        ecgi,
        vendor,
        100*(decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4))) nb_0001,
        sum(nb_0002) nb_0002,
        sum(nb_0003) nb_0003,
        100*(decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4))) nb_0004,
        sum(nb_0005) nb_0005,
        sum(nb_0006) nb_0006,
        round(avg(nb_0007),2) nb_0007,
        max(nb_0008) nb_0008,
        100*(decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4))) nb_0009,
        100*(decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4))) nb_0010,
        sum(nb_0011) nb_0011,
        sum(nb_0012) nb_0012,
        sum(nb_0013) nb_0013,
        sum(nb_0014) nb_0014,
        round(avg(nb_0015))  nb_0015
        from(';
        v_ssql_t2 := v_ssql_t2||v_ssql_t1||')T1
        group by enb_id, cell_id, tac, ecgi, vendor';
        --dbms_output.put_line(v_ssql_t2);--打印拼接结果
        execute immediate v_ssql_t2;
        commit;
        
        --v_date_start := to_date(v_date_start_vc, 'yyyymmdd'); --2019/06/17
        --v_partition_name := 'P_'||v_date_start_vc;

        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||') group by s_date, ecgi having count(1)>1 )'
        into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 周级数据插入完成！时间戳：'||v_date_start_vc||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_OMC_NB_9;
    
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_8
    --out：OMC_NB_A
    PROCEDURE PROC_OMC_NB_A(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_date_start  date;
    v_date_end   date;
    v_date_start_vc varchar2(10);--用于指定分区号
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_ssql_t1 clob;
    v_ssql_t2 clob;    
    v_clean_flag number;

    BEGIN
        select trunc(trunc(to_date(v_date_threshold_start,'yyyymmdd'), 'mm')-1, 'mm') into v_date_start from dual; --2019/06/01
        select trunc(to_date(v_date_threshold_start,'yyyymmdd'),'mm')-1 into v_date_end from dual;--2019/06/30
        v_date_start_vc := to_char(v_date_start, 'yyyymmdd'); --20190601 
        v_tbname := 'OMC_NB_A';
        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');

        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_start_vc||''','''||v_date_start_vc||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_clean_flag;
        end loop;
        
        --循环拼接分区表，遍历多日数据
        while v_date_start <= v_date_end loop
          v_partition_name :='P_'||to_char(v_date_start, 'yyyymmdd');
          if v_date_start <> v_date_end 
            then 
              v_ssql_t1 := v_ssql_t1 || 'select * from OMC_NB_8 PARTITION('||v_partition_name||')
              union all ';
          else 
              v_ssql_t1 := v_ssql_t1 || 'select * from OMC_NB_8 PARTITION('||v_partition_name||')';
          end if;
          v_date_start := v_date_start + 1;
        end loop; --2019/07/01
        
        --NB月级数据插入
        v_ssql_t2 := 
        'insert /*+append */ into '||v_tbname||'
        select 
        to_date('||v_date_start_vc||', ''yyyymmdd'') as s_date,
        min(s_month) s_month,
        min(s_week) s_week,
        min(s_day) s_day,
        min(s_hour) s_hour,
        min(start_time) start_time,
        enb_id,
        cell_id,
        tac,
        ecgi,
        vendor,
        100*(decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4))) nb_0001,
        sum(nb_0002) nb_0002,
        sum(nb_0003) nb_0003,
        100*(decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4))) nb_0004,
        sum(nb_0005) nb_0005,
        sum(nb_0006) nb_0006,
        round(avg(nb_0007),2) nb_0007,
        max(nb_0008) nb_0008,
        100*(decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4))) nb_0009,
        100*(decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4))) nb_0010,
        sum(nb_0011) nb_0011,
        sum(nb_0012) nb_0012,
        sum(nb_0013) nb_0013,
        sum(nb_0014) nb_0014,
        round(avg(nb_0015))  nb_0015
        from(';
        v_ssql_t2 := v_ssql_t2||v_ssql_t1||')T1
        group by enb_id, cell_id, tac, ecgi, vendor';
        dbms_output.put_line(v_ssql_t2);--打印拼接结果
        execute immediate v_ssql_t2;
        commit;
        
        --v_date_start := to_date(v_date_start_vc, 'yyyymmdd'); --2019/06/17
        --v_partition_name := 'P_'||v_date_start_vc;

        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||') group by s_date, ecgi having count(1)>1 )'
        into v_insert_repeat;

        dbms_output.put_line('表 '||v_tbname||' 月级数据插入完成！时间戳：'||v_date_start_vc||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
    END PROC_OMC_NB_A;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_3 /DT_CELL_NB
    --out：LC_NB_CELL_LIST_HOUR
    PROCEDURE PROC_LC_NB_CELL_LIST_HOUR(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2) IS
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;
    i_date_hour varchar2(20);
    
    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'LC_NB_CELL_LIST_HOUR';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        if V_DATE_HOUR is null
          then i_date_hour := 'S_HOUR';
        else i_date_hour := V_DATE_HOUR;
        end if;
        
        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');

        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            /*'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;*/
            
            'DELETE FROM '|| table_name||' partition('||v_partition_name||') where s_hour='||i_date_hour
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            commit;
            --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_clean_flag;
        end loop;
        
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        A.*,
        B.PROVINCE,
        B.VENDOR_CELL_ID, 
        B.COUNTY, 
        B.VENDOR_ID, 
        B.RESERVED3, 
        B.RESERVED8, 
        B.TOWN_ID, 
        B.RNC, 
        B.RESERVED4, 
        B.RESERVED5, 
        B.COVER_TYPE, 
        B.PRE_FIELD4, 
        B.PRE_FIELD5, 
        B.LIFE, 
        B.LAT, 
        B.LON, 
        B.FANGWEI
        FROM
        (
            select 
            max(nb.S_DATE) S_DATE,
            nb.S_HOUR,
            nb.ENB_ID,
            nb.CELL_ID,
            nb.ECGI,
            100*decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4)) as NB_RRC, --NB_RRC建立成功率
            100*decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
            round(avg(nb_0007),2) as NB_AVG_USRNUM, --NB平均用户数
            max(nb_0008) as NB_MAX_USRNUM, --NB最大用户数
            100*decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4)) as NB_SXZB, --上行子载波利用率
            100*decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4)) as NB_XXZB, --下行子载波利用率
            case when avg(nb_0015) >= 0 then null else decode(avg(nb_0015),null,null,round(avg(nb_0015))) end NB_PJGR, -- 平均干扰
            --计算所需原始字段
            sum(nb_0002) nb_0002,
            sum(nb_0003) nb_0003,
            sum(nb_0005) nb_0005,
            sum(nb_0006) nb_0006,
            sum(nb_0011) nb_0011,
            sum(nb_0012) nb_0012,
            sum(nb_0013) nb_0013,
            sum(nb_0014) nb_0014
            from
            OMC_NB_3 partition('||v_partition_name||') nb
            where S_HOUR = '||i_date_hour||'
            group by enb_id, cell_id, ecgi, s_hour
        )A
        left join
        (
            select --dt.enb_id*256+dt.ci as ECGI, 
            dt.*
            from DT_CELL_NB dt
        )B--分区信息 
        on A.ECGI = B.ECGI';
        commit;
        
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour||' 
        group by s_date, s_hour, ecgi having count(1)>1)'into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 小时数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'-'||i_date_hour||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
    
    END PROC_LC_NB_CELL_LIST_HOUR;




-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_8 /DT_CELL_NB
    --out：LC_NB_CELL_LIST_DAY
    PROCEDURE PROC_LC_NB_CELL_LIST_DAY(V_DATE_THRESHOLD_START VARCHAR2) IS
    --v_date_start  date;
    --v_date_end   date;
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'LC_NB_CELL_LIST_DAY';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611

        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');

        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
                
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        A.*,
        B.PROVINCE,
        B.VENDOR_CELL_ID, 
        B.COUNTY, 
        B.VENDOR_ID, 
        B.RESERVED3, 
        B.RESERVED8, 
        B.TOWN_ID, 
        B.RNC, 
        B.RESERVED4, 
        B.RESERVED5, 
        B.COVER_TYPE, 
        B.PRE_FIELD4, 
        B.PRE_FIELD5, 
        B.LIFE, 
        B.LAT, 
        B.LON, 
        B.FANGWEI
        FROM
        (
            select 
            nb.S_DATE,
            nb.S_HOUR,
            nb.ENB_ID,
            nb.CELL_ID,
            nb.ECGI,
            100*decode(nb_0003,0,null,null,null,round(nb_0002/nb_0003,4)) as NB_RRC, --NB_RRC建立成功率
            100*decode((nb_0005+nb_0006),0,null,null,null,round(nb_0006/(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
            nb_0007 as NB_AVG_USRNUM, --NB平均用户数
            nb_0008 as NB_MAX_USRNUM, --NB最大用户数
            100*decode(nb_0012,0,null,null,null,round(nb_0011/nb_0012,4)) as NB_SXZB, --上行子载波利用率
            100*decode(nb_0014,0,null,null,null,round(nb_0013/nb_0014,4)) as NB_XXZB, --下行子载波利用率
            nb_0015 as NB_PJGR, -- 平均干扰
            --计算所需原始字段
            nb_0002,nb_0003,nb_0005,nb_0006,
            nb_0011,nb_0012,nb_0013,nb_0014
            from
            OMC_NB_8 partition('||v_partition_name||') nb
        )A
        left join
        (
            select --dt.enb_id*256+dt.ci as ECGI, 
            dt.*
            from DT_CELL_NB dt
        )B--分区信息 
        on A.ECGI = B.ECGI';
        commit;
        
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') 
        group by s_date, ecgi having count(1)>1)'into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 天级数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
        
        
    END PROC_LC_NB_CELL_LIST_DAY;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_3 /DT_CELL_NB
    --out：LC_INDEX_NB_HOUR
    PROCEDURE PROC_LC_INDEX_NB_HOUR(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2) IS
    --v_date_start  date;
    --v_date_end   date;
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;
    i_date_hour varchar2(20);

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'LC_INDEX_NB_HOUR';
        --i_date_hour := V_DATE_HOUR;
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        if V_DATE_HOUR is null
          then i_date_hour := 'S_HOUR';
        else i_date_hour := V_DATE_HOUR;
        end if;
        
        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');

        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            /*'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;*/
            'DELETE FROM '|| table_name||' partition('||v_partition_name||') where s_hour='||i_date_hour
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            commit;
            
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_clean_flag;
        end loop;
        
        
        --全网
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        S_DATE,
        S_HOUR,
        province as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        100*decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4)) as NB_RRC, --NB_RRC建立成功率
        100*decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
        round(avg(nb_0007),2) as NB_AVG_USRNUM, --NB平均用户数
        sum(nb_0008) as NB_MAX_USRNUM, --NB最大用户数
        100*decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4)) as NB_SXZB, --上行子载波利用率
        100*decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4)) as NB_XXZB, --下行子载波利用率
        round(avg(nb_0015)) as NB_PJGR -- 平均干扰
        from
        (
            select A.*,B.province from
            (
                select
                nb.s_date,
                nb.s_hour,
                nb.enb_id,
                nb.cell_id,
                nb.ecgi,
                nb_0002, nb_0003, nb_0005, nb_0006,
                -- 100*decode(nb_0003,0,null,null,null,round(nb_0002/nb_0003,4)) as NB_RRC, --NB_RRC建立成功率
                -- 100*decode((nb_0005+nb_0006),0,null,null,null,round(nb_0006/(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
                nb_0007, --NB平均用户数
                nb_0008, --NB最大用户数
                nb_0011, nb_0012,
                nb_0013, nb_0014,
                -- 100*decode(nb_0012,0,null,null,null,round(nb_0011/nb_0012,4)) as NB_SXZB, --上行子载波利用率
                -- 100*decode(nb_0014,0,null,null,null,round(nb_0013/nb_0014,4)) as NB_XXZB, --下行子载波利用率
                case when nb_0015 >= 0 then null else decode(nb_0015,null,null,nb_0015) end nb_0015 -- 平均干扰                
                from OMC_NB_3 partition('||v_partition_name||') nb
                where S_HOUR = '||i_date_hour||'
            )A--天级小区级
            left join
            (
                select --dt.enb_id*256+dt.ci as ECGI, 
                dt.*
                from DT_CELL_NB dt
            )B--工参分区信息
            on A.ECGI = B.ECGI
            where B.province is not null
        )D
        group by s_date, s_hour, province';
        commit;
        
        --厂家
        execute immediate'
        insert /*+append */ into LC_INDEX_NB_HOUR
        select 
        S_DATE,
        S_HOUR,
        vendor_id  AS AREA,--厂家
        ''厂家'' AS AREA_LEVEL,
        100*decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4)) as NB_RRC, --NB_RRC建立成功率
        100*decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
        round(avg(nb_0007),2) as NB_AVG_USRNUM, --NB平均用户数
        sum(nb_0008) as NB_MAX_USRNUM, --NB最大用户数
        100*decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4)) as NB_SXZB, --上行子载波利用率
        100*decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4)) as NB_XXZB, --下行子载波利用率
        round(avg(nb_0015)) as NB_PJGR -- 平均干扰
        from
        (
            select A.*,B.vendor_id from
            (
                select
                nb.s_date,
                nb.s_hour,
                nb.enb_id,
                nb.cell_id,
                nb.ECGI,
                nb_0002, nb_0003, nb_0005, nb_0006,
                -- 100*decode(nb_0003,0,null,null,null,round(nb_0002/nb_0003,4)) as NB_RRC, --NB_RRC建立成功率
                -- 100*decode((nb_0005+nb_0006),0,null,null,null,round(nb_0006/(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
                nb_0007, --NB平均用户数
                nb_0008, --NB最大用户数
                nb_0011, nb_0012,
                nb_0013, nb_0014,
                -- 100*decode(nb_0012,0,null,null,null,round(nb_0011/nb_0012,4)) as NB_SXZB, --上行子载波利用率
                -- 100*decode(nb_0014,0,null,null,null,round(nb_0013/nb_0014,4)) as NB_XXZB, --下行子载波利用率
                case when nb_0015 >= 0 then null else decode(nb_0015,null,null,nb_0015) end nb_0015 -- 平均干扰                
                from OMC_NB_3 partition('||v_partition_name||') nb
                where S_HOUR = '||i_date_hour||'
            )A--天级小区级
            left join
            (
                select --dt.enb_id*256+dt.ci as ECGI, 
                dt.*
                from DT_CELL_NB dt
            )B--工参分区信息
            on A.ECGI = B.ECGI
            where B.vendor_id is not null--部分小区关联不上厂家标识
        )D
        group by s_date, s_hour, vendor_id';
        commit;
        
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour||' 
        group by s_date, s_hour, area, area_level having count(1)>1)'into v_insert_repeat;
        dbms_output.put_line('表 '||v_tbname||' 小时数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'-'||i_date_hour||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_LC_INDEX_NB_HOUR;
 
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_NB_8 /DT_CELL_NB
    --out：LC_INDEX_NB_DAY
    PROCEDURE PROC_LC_INDEX_NB_DAY(V_DATE_THRESHOLD_START VARCHAR2) IS
    --v_date_start  date;
    --v_date_end   date;
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;
    
    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'LC_INDEX_NB_DAY';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');
        
        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/
        --select count(1) into v_clean_flag from LC_NB_CELL_LIST_DAY where s_date >= v_date_start and s_date < v_date_end;
        /*v_ssql := 'select count(1) from '||v_tbname||' where s_date = to_date('''||V_DATE_THRESHOLD_START||''', yyyymmdd)';
        execute immediate v_ssql into v_clean_flag;*/
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        
        --全网
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        S_DATE,
        province as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        100*decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4)) as NB_RRC, --NB_RRC建立成功率
        100*decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
        round(avg(nb_0007),2) as NB_AVG_USRNUM, --NB平均用户数
        sum(nb_0008) as NB_MAX_USRNUM, --NB最大用户数
        100*decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4)) as NB_SXZB, --上行子载波利用率
        100*decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4)) as NB_XXZB, --下行子载波利用率
        round(avg(nb_0015)) as NB_PJGR -- 平均干扰
        from
        (
            select A.*,B.province from
            (
                select
                nb.S_DATE,
                nb.ENB_ID,
                nb.CELL_ID,
                nb.ECGI,
                nb_0002, nb_0003, nb_0005, nb_0006,
                -- 100*decode(nb_0003,0,null,null,null,round(nb_0002/nb_0003,4)) as NB_RRC, --NB_RRC建立成功率
                -- 100*decode((nb_0005+nb_0006),0,null,null,null,round(nb_0006/(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
                nb_0007, --NB平均用户数
                nb_0008, --NB最大用户数
                nb_0011, nb_0012,
                nb_0013, nb_0014,
                -- 100*decode(nb_0012,0,null,null,null,round(nb_0011/nb_0012,4)) as NB_SXZB, --上行子载波利用率
                -- 100*decode(nb_0014,0,null,null,null,round(nb_0013/nb_0014,4)) as NB_XXZB, --下行子载波利用率
                nb_0015 -- 平均干扰
                from OMC_NB_8 partition('||v_partition_name||') nb
            )A--天级小区级
            left join
            (
                select --dt.enb_id*256+dt.ci as ECGI, 
                dt.*
                from DT_CELL_NB dt
            )B--工参分区信息
            on A.ECGI = B.ECGI
            where B.province is not null
        )D
        group by s_date, province';
        commit;
        
        --厂家
        execute immediate'
        insert /*+append */ into LC_INDEX_NB_DAY
        select 
        S_DATE,
        VENDOR_ID  AS AREA,--厂家
        ''厂家'' AS AREA_LEVEL,
        100*decode(sum(nb_0003),0,null,null,null,round(sum(nb_0002)/sum(nb_0003),4)) as NB_RRC, --NB_RRC建立成功率
        100*decode(sum(nb_0005+nb_0006),0,null,null,null,round(sum(nb_0006)/sum(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
        round(avg(nb_0007),2) as NB_AVG_USRNUM, --NB平均用户数
        sum(nb_0008) as NB_MAX_USRNUM, --NB最大用户数
        100*decode(sum(nb_0012),0,null,null,null,round(sum(nb_0011)/sum(nb_0012),4)) as NB_SXZB, --上行子载波利用率
        100*decode(sum(nb_0014),0,null,null,null,round(sum(nb_0013)/sum(nb_0014),4)) as NB_XXZB, --下行子载波利用率
        round(avg(nb_0015)) as NB_PJGR -- 平均干扰
        from
        (
            select A.*,B.vendor_id from
            (
                select
                nb.S_DATE,
                nb.ENB_ID,
                nb.CELL_ID,
                nb.ECGI,
                nb_0002, nb_0003, nb_0005, nb_0006,
                -- 100*decode(nb_0003,0,null,null,null,round(nb_0002/nb_0003,4)) as NB_RRC, --NB_RRC建立成功率
                -- 100*decode((nb_0005+nb_0006),0,null,null,null,round(nb_0006/(nb_0005+nb_0006),4)) as NB_DXL, --NB_掉线率
                nb_0007, --NB平均用户数
                nb_0008, --NB最大用户数
                nb_0011, nb_0012,
                nb_0013, nb_0014,
                -- 100*decode(nb_0012,0,null,null,null,round(nb_0011/nb_0012,4)) as NB_SXZB, --上行子载波利用率
                -- 100*decode(nb_0014,0,null,null,null,round(nb_0013/nb_0014,4)) as NB_XXZB, --下行子载波利用率
                nb_0015 -- 平均干扰
                from OMC_NB_8 partition('||v_partition_name||') nb
            )A--天级小区级
            left join
            (
                select --dt.enb_id*256+dt.ci as ECGI, 
                dt.*
                from DT_CELL_NB dt
            )B--工参分区信息
            on A.ECGI = B.ECGI
            where B.vendor_id is not null--部分小区关联不上厂家标识
        )D
        group by s_date, vendor_id';
        commit;

        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') 
        group by s_date, area, area_level having count(1)>1)'into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 天级数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_LC_INDEX_NB_DAY;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --NB基表数据周期性汇聚激活
    PROCEDURE ACTIVE_OMC_NB_89A_AUTO AS
    V_DATE_START  varchar2(15);
    V_DATE_MONDAY date;
    V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        --每日执行昨日天级汇聚
        PKG_LC_INDEX_NB_CELL.PROC_OMC_NB_8(V_DATE_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_NB_CELL_LIST_DAY(V_DATE_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_INDEX_NB_DAY(V_DATE_START);
        v_loop_log := v_loop_log +1;
        
        --周/月汇聚触发时间戳保存
        V_DATE_START :=  to_char(sysdate,'yyyymmdd');--20190701
        V_DATE_MONDAY := trunc(next_day(sysdate,'星期一'))-7;--20190819
        V_DATE_MONTH := trunc(sysdate, 'mm');--20190601
        if  trunc(sysdate) = V_DATE_MONDAY--每周周一执行上周周汇聚--2019/07/01 = 2019/07/01
          then 
            --V_DATE_START :=  to_char(sysdate,'yyyymmdd');--20190701
            PKG_LC_INDEX_NB_CELL.PROC_OMC_NB_9(V_DATE_START);--in：20190701 执行汇聚时间都会在包内转换为上周周一：20190624
            v_loop_log := v_loop_log +1;
        elsif  trunc(sysdate) = V_DATE_MONTH--每月一号执行上月月级汇聚--2019/07/01 = 2019/07/01
          then 
            --V_DATE_START := to_char(sysdate,'yyyymmdd');--20190701
            PKG_LC_INDEX_NB_CELL.PROC_OMC_NB_A(V_DATE_START);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
            v_loop_log := v_loop_log +1;
        end if;

        dbms_output.put_line('NB小区天/周/月基表汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');
      
    END ACTIVE_OMC_NB_89A_AUTO;



-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --NB小时级汇聚自动激活（小区/区域）
    PROCEDURE ACTIVE_LC_INDEX_NB_HOUR_AUTO AS
    V_DATE_START  varchar2(15);
    V_DATE_HOUR  varchar2(2);

    --V_DATE_MONDAY date;
    --V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        --V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        V_DATE_START := to_char(sysdate + interval '-4' hour, 'yyyymmdd'); --20190807
        V_DATE_HOUR := to_char(sysdate + interval '-4' hour, 'hh24'); --17:31 → 13 数据延迟入库约2.5小时，以防万一，执行4小时前的数据汇聚（保守操作）
        /*if  to_char(sysdate,'mi:ss') = '00:00'--每个小时的开始执行，好像不需要这句，DBJob里可以设置小时触发...
          then*/
        PKG_LC_INDEX_NB_CELL.PROC_LC_NB_CELL_LIST_HOUR(V_DATE_START,V_DATE_HOUR);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
        v_loop_log := v_loop_log + 1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_INDEX_NB_HOUR(V_DATE_START,V_DATE_HOUR);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
        v_loop_log := v_loop_log + 1;
        /*end if;*/
        dbms_output.put_line('NB小时级指标汇聚任务完成（小区/区域）！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');
    END ACTIVE_LC_INDEX_NB_HOUR_AUTO;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --NB天级汇聚自动激活（小区/区域）--可以合并至 ACTIVE_OMC_NB_89A_AUTO
    /*PROCEDURE ACTIVE_LC_INDEX_NB_DAY_AUTO AS
    V_DATE_START  varchar2(15);
    --V_DATE_MONDAY date;
    --V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        --每日执行昨日天级汇聚
        PKG_LC_INDEX_NB_CELL.PROC_LC_NB_CELL_LIST_DAY(V_DATE_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_INDEX_NB_DAY(V_DATE_START);
        v_loop_log := v_loop_log +1;
        dbms_output.put_line('NB天级指标汇聚任务完成（小区/区域）！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        
    END ACTIVE_LC_INDEX_NB_DAY_AUTO;*/

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --NB基表数据补偿
    PROCEDURE ACTIVE_OMC_NB_89A_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2) AS
    --V_DATE_START  varchar2(15);
    --V_DATE_MONDAY date;
    --V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        --V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        --每日执行昨日天级汇聚
        PKG_LC_INDEX_NB_CELL.PROC_OMC_NB_8(V_DATE_THRESHOLD_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_NB_CELL_LIST_DAY(V_DATE_THRESHOLD_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_INDEX_NB_DAY(V_DATE_THRESHOLD_START);
        v_loop_log := v_loop_log +1;
        
        --周/月汇聚触发时间戳保存
        /*V_DATE_START :=  to_char(sysdate,'yyyymmdd');--20190701
        V_DATE_MONDAY := trunc(next_day(sysdate,'星期一'))-7;--20190624
        V_DATE_MONTH := trunc(sysdate, 'mm');--20190601
        if  trunc(sysdate) = V_DATE_MONDAY--每周周一执行上周周汇聚--2019/07/01 = 2019/07/01
          then 
            --V_DATE_START :=  to_char(sysdate,'yyyymmdd');--20190701
            PKG_LC_INDEX_NB_CELL.PROC_OMC_NB_9(V_DATE_START);--in：20190701 执行汇聚时间都会在包内转换为上周周一：20190624
            v_loop_log := v_loop_log +1;
        elsif  trunc(sysdate) = V_DATE_MONTH--每月一号执行上月月级汇聚--2019/07/01 = 2019/07/01
          then 
            --V_DATE_START := to_char(sysdate,'yyyymmdd');--20190701
            PKG_LC_INDEX_NB_CELL.PROC_OMC_NB_A(V_DATE_START);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
            v_loop_log := v_loop_log +1;
        end if;*/

        dbms_output.put_line('NB小区天级基表/天级小区清单/天级区域指标补偿任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');
    END ACTIVE_OMC_NB_89A_SUPPLEMENT;

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --NB小时级补偿（小区/区域）
    PROCEDURE ACTIVE_LC_INDEX_NB_HOUR_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2) AS
    --V_DATE_START  varchar2(15);
    --V_DATE_HOUR  varchar2(2);

    --V_DATE_MONDAY date;
    --V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        --V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        --V_DATE_START := to_char(sysdate, 'yyyymmdd'); --20190807
        --V_DATE_HOUR := to_char(sysdate + interval '-4' hour, 'hh24'); --17:31 → 13 数据延迟入库约2.5小时，以防万一，执行4小时前的数据汇聚（保守操作）
        /*if  to_char(sysdate,'mi:ss') = '00:00'--每个小时的开始执行，好像不需要这句，DBJob里可以设置小时触发...
          then*/
        PKG_LC_INDEX_NB_CELL.PROC_LC_NB_CELL_LIST_HOUR(V_DATE_THRESHOLD_START,V_DATE_HOUR);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
        v_loop_log := v_loop_log + 1;
        PKG_LC_INDEX_NB_CELL.PROC_LC_INDEX_NB_HOUR(V_DATE_THRESHOLD_START,V_DATE_HOUR);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
        v_loop_log := v_loop_log + 1;
        /*end if;*/
        dbms_output.put_line('NB小时级指标补偿任务完成（小区/区域）！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');        
    END ACTIVE_LC_INDEX_NB_HOUR_SUPPLEMENT;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------    
    PROCEDURE PROC_TEST IS
    v_date_start  VARCHAR2(20);
    --v_ssql CLOB;
    /*i_tablename   varchar2(30);
    --v_loop_log number := 0 ;
    i_tablespace   varchar2(30);
    i_part_name   varchar2(30);
    i_part_date varchar2(30);
    i_partition_name varchar2(500);*/

    --v_clean_flag number;
    --v_proc_end_flag number :=0;    
    BEGIN
        select 1 into v_date_start from dual;
        /*select 
        dbms_output.put_line('234G质差小区清单天级汇聚任务完成！完成时间戳：'||sysdate)
        into v_ssql
        from dual;*/
        --select count(1) into v_date_start from sys.gv_$locked_object a;
    END PROC_TEST;END PKG_LC_INDEX_NB_CELL;
/

