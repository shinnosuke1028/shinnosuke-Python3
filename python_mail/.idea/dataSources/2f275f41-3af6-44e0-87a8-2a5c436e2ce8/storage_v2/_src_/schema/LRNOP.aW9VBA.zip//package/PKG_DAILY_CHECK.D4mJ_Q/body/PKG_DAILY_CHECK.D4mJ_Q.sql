create PACKAGE BODY PKG_DAILY_CHECK AS
    PROCEDURE CSV_CHECKRESULT IS
    --in:    85服务器（scp_checkResult.sh）
    --in：  CHECK_RESULT_2G4G_TEMP
    --out：CHECK_RESULT_2G4G
    ------------------------------------------------------------------------
    --  OVERVIEW
    --
    --Editor：Shinnosuke
    --
    --Updating：2019/10/31
    --
    --4G采集监控表ETL，85(scp) → 53
    --
    --------------------------------------
    v_tbname varchar2(50);
    v_pkg_name varchar2(200);
    v_date_start_vc varchar2(10);--用于指定分区号
    v_clean_flag number;
    v_ssql varchar2(500);
    v_inside_loop_log number := 0;
    v_partition_name varchar2(30);

    BEGIN
        v_date_start_vc := to_char(sysdate-1, 'yyyymmdd'); --20190831 
        v_tbname := 'CHECK_RESULT_2G4G';
        v_pkg_name := 'CSV_CHECKRESULT';  
        
        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_LOCATE(v_tbname, v_date_start_vc, v_partition_name);
        
        --待插入分区数据清理
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_start_vc||''','''||v_date_start_vc||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop; 

        while v_clean_flag = 0 loop 
          exit when v_inside_loop_log >=5;
          --数据清洗
          insert /*+ APPEND */  into CHECK_RESULT_2G4G 
          select trunc(sysdate-1) s_date,
          pathname, 
          file_date, 
          file_size, 
          file_name 
          from
          CHECK_RESULT_2G4G_TEMP t
          where regexp_substr(t.file_date,'^[0-9]+\.{0,1}') is not null
          and t.file_date = v_date_start_vc
          and t.file_name like 'SH_%';
          commit;
          execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
          v_inside_loop_log := v_inside_loop_log +1;
        end loop;

        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','CHECK_RESULT_2G4G',v_date_start,v_date_start,'0','0');

        --execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_clean_flag;
        if v_clean_flag = 0
          then 
            PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_LOGGING(sysdate, v_pkg_name, v_inside_loop_log, v_clean_flag);
            return;--数据未插入，或无数据，跳出程序，检查数据.
        else
            PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_LOGGING(sysdate, v_pkg_name, v_inside_loop_log, v_clean_flag);
            execute immediate 'truncate table CHECK_RESULT_2G4G_TEMP';
        end if;
        
    END CSV_CHECKRESULT;


END PKG_DAILY_CHECK;
/

