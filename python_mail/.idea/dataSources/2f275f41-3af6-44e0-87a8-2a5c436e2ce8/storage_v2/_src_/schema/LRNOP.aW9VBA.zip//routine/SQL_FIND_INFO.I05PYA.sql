create PROCEDURE SQL_FIND_INFO(I_TEMPLATE_ID  VARCHAR2) AS
    v_table_name varchar2(50);
    v_activate_flag number;
    v_ssql varchar2(300);
    BEGIN
        v_ssql := 'select table_name ,activate_flag  from FAST_DATA_PROCESS_TEMPLATE
        where template_id='||I_TEMPLATE_ID;
        execute immediate v_ssql 
        --using I_TEMPLATE_ID
        /*returning*/ into v_table_name,v_activate_flag; --动态SQL查询语句
        dbms_output.put_line('表 '||v_table_name||'的激活状态为：'||v_activate_flag);
        /*exception
        when others then
        dbms_output.put_line('找不到相应数据！');*/
    END SQL_FIND_INFO;
/

