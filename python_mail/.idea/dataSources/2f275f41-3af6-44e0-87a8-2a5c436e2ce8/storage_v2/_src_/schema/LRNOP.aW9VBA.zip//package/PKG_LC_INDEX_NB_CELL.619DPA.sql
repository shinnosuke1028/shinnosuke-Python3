create PACKAGE PKG_LC_INDEX_NB_CELL AUTHID CURRENT_USER as
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  大屏指标汇总-NB小区
  --
  --  OWNER:       Shinnosuke
  --
  --  VERSION:     1.4
  --
  --  CREATE DATE： 2019/08/06 version 1.0
  --               1.增加NB小区小时级清单结果表过程（清单含计算字段，前台导出） PROC_LC_NB_CELL_LIST_HOUR
  --               2.增加NB小区天级清单结果表过程（清单含计算字段，前台导出）PROC_LC_NB_CELL_LIST_DAY
  --               3.增加NB小区 3 → 8 周期性汇聚过程（小时 → 天） PROC_OMC_NB_8
  --
  --  UPDATE DATE：2019/08/07 version 1.1
  --               1.增加NB区域小时级清单结果表过程（清单不含计算字段，前台呈现） PROC_LC_INDEX_NB_HOUR
  --               2.增加NB区域天级清单结果表过程（清单不含计算字段，前台呈现） PROC_LC_INDEX_NB_DAY
  --               3.增加NB小区 8 → 9/A 周期性汇聚过程（天 → 周/月） PROC_OMC_NB_9 / PROC_OMC_NB_A
  --
  --  UPDATE DATE：2019/08/08 version 1.2
  --               1.修正NB小区小时级清单结果表过程（小时级汇聚每小时执行，仅执行4小时前的单小时的汇聚，例：16点执行12点的汇聚）
  --               2.修正NB区域小时级清单结果表过程（小时级汇聚每小时执行，仅执行4小时前的单小时的汇聚，例：16点执行12点的汇聚）
  --  
  --  UPDATE DATE：2019/08/09 version 1.3
  --               1.增加NB小区3/8/9/A周期性汇聚自动调度过程  ACTIVE_OMC_NB_89A_AUTO
  --               2.增加NB小区/区域小时级清单结果表自动调度过程 ACTIVE_LC_INDEX_NB_HOUR_AUTO
  --               3.增加NB小区/区域天级清单结果表自动调度过程 ACTIVE_LC_INDEX_NB_DAY_AUTO
  --               4.修正NB小区 3 → 8 周期性汇聚过程（s_hour/start_time定义简化）
  --
  --  UPDATE DATE：2019/09/01 version 1.4
  --               1.修正NB小区周期性汇聚过程 ACTIVE_OMC_NB_89A_AUTO（缺失周级入口时间参数）
  --               2.修正NB小区 8 → A 周期性汇聚过程 (清理部分时间参数错误，任务最终的 execute 未打开)
  --
  --  TODO    1.评估是否新增全流程补数据任务
  --               2.评估是否新增进程相关监控信息
  --
  --
------------------------------------------------------------------------

  --389A
  PROCEDURE PROC_OMC_NB_8(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_OMC_NB_9(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_OMC_NB_A(V_DATE_THRESHOLD_START VARCHAR2);
  
  --NB小区小时级清单（含计算字段，前台导出）
  PROCEDURE PROC_LC_NB_CELL_LIST_HOUR(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2);
  --NB小区天级清单（含计算字段，前台导出）
  PROCEDURE PROC_LC_NB_CELL_LIST_DAY(V_DATE_THRESHOLD_START VARCHAR2);
  
  --NB区域小时级清单（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_NB_HOUR(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2);
  --NB区域天级清单（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_NB_DAY(V_DATE_THRESHOLD_START VARCHAR2);
  
  --NB基表数据周期性汇聚自动激活
  PROCEDURE ACTIVE_OMC_NB_89A_AUTO;
  --NB小时级汇聚自动激活（小区/区域）
  PROCEDURE ACTIVE_LC_INDEX_NB_HOUR_AUTO;
  --NB天级汇聚自动激活（小区/区域）--暂不启动
  --PROCEDURE ACTIVE_LC_INDEX_NB_DAY_AUTO;--可以合并至 ACTIVE_OMC_NB_89A_AUTO

  --NB基表数据补偿
  PROCEDURE ACTIVE_OMC_NB_89A_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);
  --NB小时级汇聚补偿
  PROCEDURE ACTIVE_LC_INDEX_NB_HOUR_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2);


  PROCEDURE PROC_TEST;



end PKG_LC_INDEX_NB_CELL;
/

