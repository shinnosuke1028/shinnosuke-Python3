create PACKAGE PKG_LC_INDEX_5G_CELL AUTHID CURRENT_USER as
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  5G指标汇总
  --
  --  OWNER:       Shinnosuke
  --
  --  VERSION:     1.2
  --
  --  CREATE DATE: 2019/06/26 version 1.0
  --               1.增加5G小区天/周/月基表数据过程
  --
  --  UPDATE DATE:2019/06/27 version 1.1
  --               1.增加5G小区天/周/月基表调度过程
  --               2.增加5G小区多维度清单天表过程
  --               3.修正5G小区天/周/月基表数据过程（改为分区模式汇聚）
  --
  --  UPDATE DATE:2019/08/21 version 1.2
  --               1.该PKG下的5G任务中止
  --
  --  TODO    1.增加分区表自动清理功能
  --               2.评估是否新增进程相关监控信息
  --
  --
------------------------------------------------------------------------

  --全量质差清单
  --PROCEDURE PROC_OMC_NR_3(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_OMC_NR_8(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_OMC_NR_9(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_OMC_NR_A(V_DATE_THRESHOLD_START VARCHAR2);

  PROCEDURE PROC_LC_INDEX_5G_DAY(V_DATE_THRESHOLD_START VARCHAR2);

  --5G基表数据周期性汇聚激活
  PROCEDURE ACTIVE_OMC_NR_89A_AUTO;


end PKG_LC_INDEX_5G_CELL;
/

