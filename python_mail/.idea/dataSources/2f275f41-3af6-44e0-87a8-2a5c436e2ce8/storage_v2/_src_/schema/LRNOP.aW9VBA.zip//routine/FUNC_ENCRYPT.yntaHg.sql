create function func_encrypt(p_text varchar2, p_key varchar2) return varchar2 is
v_text varchar2(4000);
v_enc varchar2(4000);
raw_input RAW(128) ;
key_input RAW(128) ;
decrypted_raw RAW(2048); 
    begin
        dbms_output.put_line(p_text);
        v_text := rpad( p_text, (trunc(length(p_text)/8)+1)*8, chr(0));-- 拼接总长：(源数据长度/8+1)*8，右侧拼接 ASCII值为0的对应参数（ASCII[0]=NULL）
        --加密字符串需是8的倍数，故在右侧拼接空格补充
        raw_input := UTL_RAW.CAST_TO_RAW(v_text);--转为RAW格式
        key_input := UTL_RAW.CAST_TO_RAW(p_key);
        dbms_obfuscation_toolkit.DESENCRYPT(input => raw_input,key => key_input,encrypted_data =>decrypted_raw);
        v_enc := rawtohex(decrypted_raw);
        dbms_output.put_line(v_enc);
        return v_enc;
    end;
/

