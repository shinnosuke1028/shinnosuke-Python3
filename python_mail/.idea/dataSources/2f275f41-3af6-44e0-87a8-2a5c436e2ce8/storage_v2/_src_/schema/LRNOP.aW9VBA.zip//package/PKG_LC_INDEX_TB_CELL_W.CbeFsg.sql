create PACKAGE PKG_LC_INDEX_TB_CELL_W AUTHID CURRENT_USER AS
------------------------------------------------------------------------
    --  OVERVIEW
    --
    --  ZYJ-3G突变&质差小区流程包
    --
    --  OWNER:       Shinnosuke
    --
    --  VERSION:     1.3
    --
    --  CREATE DATE：2019/10/25 version 1.0
    --               1.增加3GTB小区小时级质差清单过程（含分子分母&<本周/上周>对比数据，用于后续质差计算）PROC_TB_LIST_CELL_HOUR_W
    --
    --  UPDATE DATE：2019/10/26 version 1.1
    --               1.增加3GTB小区天级质差&突变指标结果表过程（仅含标签） PROC_TB_INDEX_CELL_DAY
    --               2.增加3GTB小区导出表所需中间表过程（中间表，用于最后的导出表） PROC_TB_LIST_CELL_HOUR_FORMAT_W
    --               3.增加3GTB小区导出表最终表过程（每行：小区单指标；列：多小时） PROC_TB_LIST_CELL_HOUR_FORMAT2_W
    --
    --  UPDATE DATE：2019/10/27 version 1.2
    --               1.增加3GTB小区清单指标自动化流转过程
    --               2.增加3GTB小区小时级质差清单过程小时触发模式（入口参数不填小时时，默认处理全天忙时数据）
    --
    --  UPDATE DATE：2019/11/14 version 1.3
    --               1.增加数据补采过程（区分当日正常流程和补采流程，回避冲突）
    --
    --  TODO    1.
    --               4.评估是否新增进程相关监控信息
    --
    --
------------------------------------------------------------------------

    --LTE
    --TB小区小时级质差清单过程
    --in：OMC_LTE_3 / MR_LTE_MRS_CELL_3 / DT_CELL_L
    --out：TB_LIST_CELL_HOUR
    PROCEDURE PROC_TB_LIST_CELL_HOUR_W(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := NULL);

    --TB小区天级质差&突变指标结果表过程（仅含标签）
    --in：TB_LIST_CELL_HOUR
    --out：TB_INDEX_CELL_DAY_W
    PROCEDURE PROC_TB_INDEX_CELL_DAY_W(V_DATE_THRESHOLD_START VARCHAR2);

    --TB小区天级区域数量统计
    --in：TB_INDEX_CELL_DAY / DT_CELL_L
    --out：OSS_CELL_DAY
    PROCEDURE PROC_TB_OSS_DAY_W(V_DATE_THRESHOLD_START VARCHAR2);

    --TB小区导出表所需中间表过程（中间表）
    --in：TB_LIST_CELL_HOUR_W
    --out：TB_EXPORT_TMP_W
    PROCEDURE PROC_TB_LIST_CELL_HOUR_FORMAT_W(V_DATE_THRESHOLD_START VARCHAR2);

    --TB小区导出表最终表过程
    --in：TB_EXPORT_TMP_W
    --out：TB_EXPORT_W
    --计算全天，可以将入口参数2设置为：23
    PROCEDURE PROC_TB_LIST_CELL_HOUR_FORMAT2_W(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := '23');
    
    --数据补偿
    PROCEDURE PROC_TB_FORMAT_SUPPLEMENT_W(V_DATE_THRESHOLD_START VARCHAR2);
    PROCEDURE PROC_TB_FORMAT2_SUPPLEMENT_W(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := '23');

    -- --TB小区小时级清单&天级标签周期性汇聚任务自动激活（运行粒度：小时）
    PROCEDURE ACTIVE_LC_ZCTB_W_AUTO;
    
    -- --TB小区小时级清单&天级标签周期性汇聚补偿任务（全流程，只需传递天级标签）
    PROCEDURE ACTIVE_LC_ZCTB_W_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);

    --客户端视图呈现
    --TB_EXPORT_VIEW_W
    --in：TB_EXPORT_W / TB_INDEX_CELL_DAY_W
    --out：TB_EXPORT_VIEW_W

    --PROCEDURE PROC_TEST;

END PKG_LC_INDEX_TB_CELL_W;
/

