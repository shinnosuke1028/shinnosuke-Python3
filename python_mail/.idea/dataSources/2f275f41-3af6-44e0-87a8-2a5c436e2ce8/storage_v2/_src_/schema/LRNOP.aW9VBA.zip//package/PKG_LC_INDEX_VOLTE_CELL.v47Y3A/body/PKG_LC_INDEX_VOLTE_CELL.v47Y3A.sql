create PACKAGE BODY PKG_LC_INDEX_VOLTE_CELL AS
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_LTE_8/ DT_CELL_L
    --out：VOLTE_CELL_LIST_DAY
    /*PROCEDURE PROC_VOLTE_CELL_LIST_DAY(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_tbname varchar2(50);
    v_date_start  date;
    v_date_end   date;
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;
    --v_proc_end_flag number :=0;

    BEGIN
        v_tbname := 'LC_INDEX_VOLTE_CELL_DAY';
        --起止时间戳格式化
        --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
        v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
        v_date_end := v_date_start +1;--起始时间戳'yyyymmdd'格式化
        
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name 
        from USER_TAB_PARTITIONS t where t.table_name = v_tbname and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START;         

    END PROC_VOLTE_CELL_LIST_DAY;*/
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_LTE_3/ DT_CELL_L
    --out：LC_INDEX_VOLTE_3
    PROCEDURE PROC_LC_INDEX_VOLTE_3(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2) IS
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    --v_ssql varchar2(500);
    v_clean_flag number;
    i_date_hour varchar2(20);
    
    /*c_high_value varchar2(200);
    v_high_value_vc varchar2(20);
    c_table_name varchar2(50);
    c_partition_name varchar2(80);*/
    i_partition_name varchar2(30); --源表分区号，系统分区号（SYS_*）
     
    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        V_TBNAME := 'LC_INDEX_VOLTE_3';
        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_LOCATE(V_TBNAME, V_DATE_THRESHOLD_START, v_partition_name);
        
        if V_DATE_HOUR is null
          then i_date_hour := 'S_HOUR';
        else i_date_hour := V_DATE_HOUR;
        end if;
        
        --清理
        if v_partition_name <> 'NULL'
            then
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_clean_flag;
            while v_clean_flag !=0 loop
                execute immediate 'delete from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour;
                commit;
                /*select
                'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
                into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
                where s.table_name = v_tbname;
                execute immediate v_ssql;*/
                --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
                execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_clean_flag;
            end loop;
        end if;
        --准备工作完成！！
        
        V_TBNAME := 'OMC_LTE_3';
        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_LOCATE(V_TBNAME, V_DATE_THRESHOLD_START, i_partition_name);
        
                
        --全网
        execute immediate'
        insert /*+ append */ into LC_INDEX_VOLTE_3
        select 
        S_DATE,
        S_HOUR,
        PROVINCE as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, B.PROVINCE from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from 
            OMC_LTE_3 partition('||i_partition_name||') omc
            where S_HOUR = '||i_date_hour||'
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.PROVINCE from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.province is not null--去除工参中指定分区信息为空的
        )D
        group by S_DATE, S_HOUR, PROVINCE';
        commit;
        
        --厂家
        execute immediate'
        insert /*+ append */ into LC_INDEX_VOLTE_3
        select 
        S_DATE,
        S_HOUR,
        VENDOR_ID as AREA,--厂家
        ''厂家'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        from
        (
          select A.*, decode(B.VENDOR_ID,''1'',''华为'', ''7'',''诺基亚'',''中兴'') VENDOR_ID from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from 
            OMC_LTE_3 partition('||i_partition_name||') omc
            where S_HOUR = '||i_date_hour||'
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.vendor_id from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.VENDOR_ID is not null--去除工参中指定分区信息为空的
        )D
        group by S_DATE, S_HOUR, VENDOR_ID';
        commit;
        
        V_TBNAME := 'LC_INDEX_VOLTE_3';
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||i_date_hour||' 
        group by s_date, s_hour, area having count(1)>1)'into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 小时数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'-'||i_date_hour||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_LC_INDEX_VOLTE_3;
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_LTE_8/ DT_CELL_L
    --out：LC_INDEX_VOLTE_8
    PROCEDURE PROC_LC_INDEX_VOLTE_8(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'LC_INDEX_VOLTE_8';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        
        --清理
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        --准备工作完成！！
        
        --全网
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        S_DATE,
        PROVINCE as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, B.province from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from OMC_LTE_8 omc where s_date = to_date('||V_DATE_THRESHOLD_START||', ''yyyymmdd'')--******
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.province from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.province is not null--去除工参中指定分区信息为空的
        )D
        group by S_DATE, PROVINCE';
        commit;
        commit;
        --from OMC_LTE_8 partition('||v_partition_name||')--******
        
        
        --厂家
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        S_DATE,
        VENDOR_ID as AREA,--省份
        ''厂家'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, decode(B.VENDOR_ID,''1'',''华为'', ''7'',''诺基亚'',''中兴'') VENDOR_ID from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from 
            OMC_LTE_8 omc where s_date = to_date('||V_DATE_THRESHOLD_START||', ''yyyymmdd'')--******
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.vendor_id from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.VENDOR_ID is not null--去除工参中指定分区信息为空的
        )D
        group by S_DATE, VENDOR_ID';
        commit;
        commit;
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') 
        group by s_date, area having count(1)>1)'into v_insert_repeat;
        dbms_output.put_line('表 '||v_tbname||' 天级数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_LC_INDEX_VOLTE_8;

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_LTE_8/ DT_CELL_L
    --out：LC_INDEX_VOLTE_9
    PROCEDURE PROC_LC_INDEX_VOLTE_9(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_tbname varchar2(50);
    v_date_start  date;
    v_date_end   date;
    v_date_start_vc varchar2(10);--用于指定分区号
    v_date_end_vc varchar2(10);--用于指定结束时间，目前OMC_LTE_8无分区
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        select (trunc(next_day(to_date(V_DATE_THRESHOLD_START,'yyyymmdd'),2))-14) into v_date_start from dual;--2019/08/05
        select (trunc(next_day(to_date(V_DATE_THRESHOLD_START,'yyyymmdd'),2))-14) + 6 into v_date_end from dual;--2019/08/11
        v_date_start_vc := to_char(v_date_start, 'yyyymmdd');--20190805
        v_date_end_vc := to_char(v_date_end, 'yyyymmdd');--20190811

        v_tbname := 'LC_INDEX_VOLTE_9';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_start_vc; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        --清理
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_start_vc||''','''||v_date_start_vc||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        --准备工作完成！！
        
        --全网
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        to_date('||v_date_start_vc||', ''yyyymmdd'') as S_DATE,
        PROVINCE as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, B.province from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from OMC_LTE_8 omc where s_date between to_date('||v_date_start_vc||', ''yyyymmdd'') and to_date('||v_date_end_vc||', ''yyyymmdd'')--******
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.province from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.province is not null--去除工参中指定分区信息为空的
        )D
        group by PROVINCE';
        commit;
        
        --from OMC_LTE_8 partition('||v_partition_name||')--******
        
        --厂家
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        to_date('||v_date_start_vc||', ''yyyymmdd'') as S_DATE,
        VENDOR_ID as AREA,--省份
        ''厂家'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, decode(B.VENDOR_ID,''1'',''华为'', ''7'',''诺基亚'',''中兴'') VENDOR_ID from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from OMC_LTE_8 omc where s_date between to_date('||v_date_start_vc||', ''yyyymmdd'') and to_date('||v_date_end_vc||', ''yyyymmdd'')--******
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.vendor_id from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.VENDOR_ID is not null--去除工参中指定分区信息为空的
        )D
        group by VENDOR_ID';
        commit;

        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||') group by s_date, area having count(1)>1 )'
        into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 周级数据插入完成！时间戳：'||v_date_start_vc||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_LC_INDEX_VOLTE_9;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_LTE_8/ DT_CELL_L
    --out：LC_INDEX_VOLTE_A
    PROCEDURE PROC_LC_INDEX_VOLTE_A(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_tbname varchar2(50);
    v_date_start  date;
    v_date_end   date;
    v_date_start_vc varchar2(10);--用于指定分区号
    v_date_end_vc varchar2(10);--用于指定结束时间，目前OMC_LTE_8无分区
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        select trunc(trunc(to_date(V_DATE_THRESHOLD_START,'yyyymmdd'), 'mm')-1, 'mm') into v_date_start from dual; --2019/08/01
        select trunc(to_date(V_DATE_THRESHOLD_START,'yyyymmdd'),'mm')-1 into v_date_end from dual;--2019/08/31
        v_date_start_vc := to_char(v_date_start, 'yyyymmdd');--20190801
        v_date_end_vc := to_char(v_date_end, 'yyyymmdd');--20190831

        v_tbname := 'LC_INDEX_VOLTE_A';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_start_vc; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        --清理
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_start_vc||''','''||v_date_start_vc||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        --准备工作完成！！
        
        --全网
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        to_date('||v_date_start_vc||', ''yyyymmdd'') as S_DATE,
        PROVINCE as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, B.province from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from OMC_LTE_8 omc where s_date between to_date('||v_date_start_vc||', ''yyyymmdd'') and to_date('||v_date_end_vc||', ''yyyymmdd'')--******
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.province from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.province is not null--去除工参中指定分区信息为空的
        )D
        group by PROVINCE';
        commit;
        
        --from OMC_LTE_8 partition('||v_partition_name||')--******
        
        --厂家
        execute immediate'
        insert /*+append */ into '||v_tbname||'
        select 
        to_date('||v_date_start_vc||', ''yyyymmdd'') as S_DATE,
        VENDOR_ID as AREA,--省份
        ''厂家'' AS AREA_LEVEL,
        --接入类
        100*decode(sum(n4_0002),0,null,null,null,round(sum(n4_0001)/sum(n4_0002),4)) as RRC_JTL,--RRC接通率
        100*decode(sum(n4_0058),0,null,null,null,round(sum(n4_0057)/sum(n4_0058),4)) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率
        100*decode(sum(n4_0060),0,null,null,null,round(sum(n4_0059)/sum(n4_0060),4)) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率
        100*decode(sum(n4_0062),0,null,null,null,round(sum(n4_0061)/sum(n4_0062),4)) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率
        --保持类
        100*decode(sum(n4_0063+n4_0064),0,null,null,null,round(sum(n4_0064)/sum(n4_0063+n4_0064),4)) as CQI1_DHL,--CQI1掉话率
        100*decode(sum(n4_0065+n4_0066),0,null,null,null,round(sum(n4_0066)/sum(n4_0065+n4_0066),4)) as CQI2_DHL,--CQI2掉话率
        100*decode(sum(n4_0067+n4_0068),0,null,null,null,round(sum(n4_0068)/sum(n4_0067+n4_0068),4)) as CQI5_DHL,--CQI5掉话率
        100*decode(sum(n4_0070),0,null,null,null,round(sum(n4_0069)/sum(n4_0070),4)) as TPQH_RATE,--同频语音切换成功率
        100*decode(sum(n4_0072),0,null,null,null,round(sum(n4_0071)/sum(n4_0072),4)) as YPQH_RATE,--异频语音切换成功率
        --感知类
        100*decode(sum(n4_0074),0,null,null,null,round(sum(n4_0073)/sum(n4_0074),4)) as QCI1_KKSXDBL,--QCI1_空口上行丢包率
        100*decode(sum(n4_0076),0,null,null,null,round(sum(n4_0075)/sum(n4_0076),4)) as QCI1_KKXXDBL,--QCI1_空口下行丢包率
        100*decode(sum(n4_0078),0,null,null,null,round(sum(n4_0077)/sum(n4_0078),4)) as QCI2_KKSXDBL,--QCI2_空口上行丢包率
        100*decode(sum(n4_0080),0,null,null,null,round(sum(n4_0079)/sum(n4_0080),4)) as QCI2_KKXXDBL,--QCI2_空口下行丢包率
        100*decode(sum(n4_0082),0,null,null,null,round(sum(n4_0081)/sum(n4_0082),4)) as QCI5_KKSXDBL,--QCI5_空口上行丢包率
        100*decode(sum(n4_0084),0,null,null,null,round(sum(n4_0083)/sum(n4_0084),4)) as QCI5_KKXXDBL,--QCI5_空口下行丢包率
        --业务量
        round(sum(n4_0051),2) as CQI1_HWL,--CQI1话务量(Erl)
        round(sum(n4_0052),2) as CQI2_HWL,--CQI2话务量(Erl)
        round(sum(n4_0053)/8/1000/1000/1000,2) CQI1_SXYWLL,--CQI1上行业务流量(TB)
        round(sum(n4_0054)/8/1000/1000/1000,2) CQI1_XXYWLL,--CQI1下行业务流量(TB)
        round(sum(n4_0055)/8/1000/1000/1000,2) CQI2_SXYWLL,--CQI2上行业务流量(TB)
        round(sum(n4_0056)/8/1000/1000/1000,2) CQI2_XXYWLL--CQI2下行业务流量(TB)
        --select distinct s_hour
        from
        (
          select A.*, decode(B.VENDOR_ID,''1'',''华为'', ''7'',''诺基亚'',''中兴'') VENDOR_ID from
          (
            select
            s_date,
            s_hour,
            enb_id,
            cell_id,
            ecgi,
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from OMC_LTE_8 omc where s_date between to_date('||v_date_start_vc||', ''yyyymmdd'') and to_date('||v_date_end_vc||', ''yyyymmdd'')--******
          )A--小区天级VOLTE指标
          left join
          (
            select enb_id*256+ci as ECGI, dt.vendor_id from dt_cell_l dt
          )B--分区信息
          on A.ecgi = B.ecgi
          where B.VENDOR_ID is not null--去除工参中指定分区信息为空的
        )D
        group by VENDOR_ID';
        commit;

        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition(P_'||v_date_start_vc||') group by s_date, area having count(1)>1 )'
        into v_insert_repeat;
        
        dbms_output.put_line('表 '||v_tbname||' 周级数据插入完成！时间戳：'||v_date_start_vc||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_LC_INDEX_VOLTE_A;

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：OMC_LTE_8/ DT_CELL_L
    --out：ZC_CELL_LIST_VOLTE_DAY
    PROCEDURE PROC_ZC_CELL_LIST_VOLTE_DAY(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        v_tbname := 'ZC_CELL_LIST_VOLTE_DAY';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        --清理
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        --准备工作完成！！
        
        execute immediate'
        insert into '||v_tbname||'
        select A.*,
        case when (QCI1_E_RAB_RATE <98 or QCI2_E_RAB_RATE <98 or QCI5_E_RAB_RATE <98) then 1 else 0 end DJR_BADFLAG, --低接入小区占比
        case when (CQI1_DHL >10 or CQI2_DHL >10 or CQI5_DHL >10) then 1 else 0 end GDH_BADFLAG,--高掉话小区占比
        case when (QCI1_KKSXDBL >0.5 or QCI2_KKSXDBL >0.5 or QCI5_KKSXDBL >0.5) then 1 else 0 end KKSXGDB_BADFLAG,--空口上行高丢包小区占比
        case when (QCI1_KKXXDBL >0.5 or QCI2_KKXXDBL >0.5 or QCI5_KKXXDBL >0.5) then 1 else 0 end KKXXGDB_BADFLAG,--空口下行高丢包小区占比
        province ,--省份 , 
        vendor_cell_id ,--行政区 , 
        county ,--优化分区 , 
        decode(vendor_id,null,null,''1'',''华为'',''7'',''诺基亚'',''中兴'') vendor_id, --厂家
        reserved3 ,--单元格 , 
        reserved8 ,--区县分公司 , 
        town_id ,--环线 , 
        rnc, 
        reserved4 ,--聚焦区域 , 
        reserved5 ,--频段 , 
        cover_type ,--基站类型 ,
        life --小区状态
        from
        (
            select
            --接入类
            s_date,
            enb_id,
            cell_id,
            ecgi,
            -- 100*decode(n4_0002,0,null,null,null,round(n4_0001/n4_0002,4) ) as RRC_JTL,--RRC接通率
            100*decode(n4_0058,0,null,null,null,round(n4_0057/n4_0058, 4) ) as QCI1_E_RAB_RATE,--QCI1_E-RAB成功率--
            100*decode(n4_0060,0,null,null,null,round(n4_0059/n4_0060, 4) ) as QCI2_E_RAB_RATE,--QCI2_E-RAB成功率--
            100*decode(n4_0062,0,null,null,null,round(n4_0061/n4_0062, 4) ) as QCI5_E_RAB_RATE,--QCI5_E-RAB成功率--
            --保持类
            100*decode((n4_0063+n4_0064),0,null,null,null,round(n4_0064/(n4_0063+n4_0064),4) ) as CQI1_DHL,--CQI1掉话率--
            100*decode((n4_0065+n4_0066),0,null,null,null,round(n4_0066/(n4_0065+n4_0066),4) ) as CQI2_DHL,--CQI2掉话率--
            100*decode((n4_0067+n4_0068),0,null,null,null,round(n4_0068/(n4_0067+n4_0068),4) ) as CQI5_DHL,--CQI5掉话率--
            100*decode(n4_0070,0,null,null,null,round(n4_0069/n4_0070, 4) ) as TPQH_RATE,--同频语音切换成功率
            100*decode(n4_0072,0,null,null,null,round(n4_0071/n4_0072, 4) ) as YPQH_RATE,--异频语音切换成功率
            --感知类
            100*decode(n4_0074,0,null,null,null,round(n4_0073/n4_0074, 4) ) as QCI1_KKSXDBL,--QCI1_空口上行丢包率--
            100*decode(n4_0076,0,null,null,null,round(n4_0075/n4_0076, 4) ) as QCI1_KKXXDBL,--QCI1_空口下行丢包率--
            100*decode(n4_0078,0,null,null,null,round(n4_0077/n4_0078, 4) ) as QCI2_KKSXDBL,--QCI2_空口上行丢包率--
            100*decode(n4_0080,0,null,null,null,round(n4_0079/n4_0080, 4) ) as QCI2_KKXXDBL,--QCI2_空口下行丢包率--
            100*decode(n4_0082,0,null,null,null,round(n4_0081/n4_0082, 4) ) as QCI5_KKSXDBL,--QCI5_空口上行丢包率--
            100*decode(n4_0084,0,null,null,null,round(n4_0083/n4_0084, 4) ) as QCI5_KKXXDBL,--QCI5_空口下行丢包率--
            --业务量 
            n4_0051 as CQI1_HWL,--CQI1话务量(Erl)
            n4_0052 as CQI2_HWL,--CQI2话务量(Erl)
            n4_0053/8/1000/1000/1000 CQI1_SXYWLL,--CQI1上行业务流量(TB)
            n4_0054/8/1000/1000/1000 CQI1_XXYWLL,--CQI1下行业务流量(TB)
            n4_0055/8/1000/1000/1000 CQI2_SXYWLL,--CQI2上行业务流量(TB)
            n4_0056/8/1000/1000/1000 CQI2_XXYWLL,--CQI2下行业务流量(TB)
            --接入类
            n4_0001, n4_0002, n4_0057, n4_0058, n4_0059, n4_0060, n4_0061, n4_0062,
            --保持类
            n4_0063, n4_0064, n4_0065, n4_0066, n4_0067, n4_0068, n4_0069, n4_0070, n4_0071, n4_0072, 
            --感知类
            n4_0073, n4_0074, n4_0075, n4_0076, n4_0077, n4_0078, 
            n4_0079, n4_0080, n4_0081, n4_0082, n4_0083, n4_0084, 
            --业务量
            n4_0051, n4_0052, n4_0053, n4_0054, n4_0055, n4_0056
            from
            OMC_LTE_8 omc where s_date = to_date('||V_DATE_THRESHOLD_START||', ''yyyymmdd'')--******OMC_LTE_8暂未分区，分区后替换见下
        )A--天级VOLTE数据 & 基础计算字段
        --LC_INDEX_VOLTE_CELL_DAY partition(P_20190811) A  --暂时不安排生成
        left join
        (
            select --dt.enb_id*256+dt.ci as ECGI, 
            dt.*
            from DT_CELL_L dt
        )B--分区信息 
        on A.ecgi = B.ecgi';
        commit;
        commit;
        --from OMC_LTE_8 partition('||v_partition_name||')--******

        
        
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||') 
        group by s_date, ecgi having count(1)>1)'into v_insert_repeat;
        dbms_output.put_line('表 '||v_tbname||' 天级数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
    END PROC_ZC_CELL_LIST_VOLTE_DAY;
        

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --in：ZC_CELL_LIST_VOLTE_DAY/ DT_CELL_L
    --out：LC_INDEX_VOLTE_BAD_CELL_DAY
    PROCEDURE PROC_LC_INDEX_VOLTE_BAD_CELL_DAY(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_tbname varchar2(50);
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;
    v_date_start  date;
    v_date_end   date;
    --v_date_start_vc varchar2(10);--用于指定分区号
    v_date_end_vc varchar2(10);
    v_ssql_t1 clob;
    v_ssql_t2 clob;
        
    BEGIN
        v_tbname := 'LC_INDEX_VOLTE_BAD_CELL_DAY';
        --起止时间戳格式化
        v_date_start := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd');--2019/08/12
        v_date_end := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd')-7;--2019/08/05
        --v_date_start_vc := to_char(v_date_start-1, 'yyyymmdd');--20190811
        v_date_end_vc := to_char(v_date_end, 'yyyymmdd');--20190805
        
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_THRESHOLD_START; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        
        --清理
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        while v_clean_flag !=0 loop
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = v_tbname;
            execute immediate v_ssql;
            execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_clean_flag;
        end loop;
        --准备工作完成！！

        --循环拼接分区表，遍历多日数据
        while v_date_start >= v_date_end loop--2019/08/14>=2019/08/07
          if v_date_start = to_date(V_DATE_THRESHOLD_START, 'yyyymmdd')--首次进循环，分区时间指向-1
            then 
              v_partition_name :='P_'||to_char(v_date_start-1, 'yyyymmdd');--2019/08/13
              v_date_start := v_date_start - 1;--2019/08/13
          end if;
          if v_date_start <> v_date_end 
            then 
              v_ssql_t1 := v_ssql_t1 || 'select * from ZC_CELL_LIST_VOLTE_DAY PARTITION('||v_partition_name||')
              union all ';
          else 
              v_ssql_t1 := v_ssql_t1 || 'select * from ZC_CELL_LIST_VOLTE_DAY PARTITION('||v_partition_name||')';
          end if;
          v_date_start := v_date_start - 1;--2019/08/12
          v_partition_name :='P_'||to_char(v_date_start, 'yyyymmdd');--P_20190812
        end loop; 
        --dbms_output.put_line(v_ssql_t1);--打印拼接结果
        
        --全网
        v_ssql_t2 := 
        'insert /*+append */ into '||v_tbname||'
        select S_DATE, DAYS_RANGE, 
        PROVINCE as AREA,--省份
        ''上海'' AS AREA_LEVEL,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(DJR_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as DJR_RATE,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(GDH_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as GDH_RATE,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(KKSXGDB_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as KKSXGDB_RATE,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(KKXXGDB_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as KKXXGDB_RATE,
        sum(DJR_BADFLAG_EXP) as DJR_BADCELL_NUM,
        sum(GDH_BADFLAG_EXP) as GDH_BADCELL_NUM,
        sum(KKSXGDB_BADFLAG_EXP) as KKSXGDB_BADCELL_NUM,
        sum(KKXXGDB_BADFLAG_EXP) as KKXXGDB_BADCELL_NUM,
        max(dt.CELL_NUM_BWH) CELL_NUM_BWH
        from
        (
          select 
          to_date('||V_DATE_THRESHOLD_START||', ''yyyymmdd'') as s_date,
          substr('||V_DATE_THRESHOLD_START||',3,2)||'': ''||to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''mm'')||''/''|| to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''dd'')||''~''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''mm'')||''/''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''dd'') DAYS_RANGE, --评估周级范围, --当前日期下的前7天
          ecgi, 
          case when sum(DJR_BADFLAG)>=3 then 1 else 0 end DJR_BADFLAG_EXP,--7天指标内有3天不达标  --低接入小区
          case when sum(GDH_BADFLAG)>=3 then 1 else 0 end GDH_BADFLAG_EXP,--高掉话小区占比
          case when sum(KKSXGDB_BADFLAG)>=3 then 1 else 0 end KKSXGDB_BADFLAG_EXP,--空口上行高丢包小区占比
          case when sum(KKXXGDB_BADFLAG)>=3 then 1 else 0 end KKXXGDB_BADFLAG_EXP,--空口下行高丢包小区占比
          province ,--省份 , 
          life
          from
          (';
        v_ssql_t2 := v_ssql_t2||v_ssql_t1||')A--质差数据
          where A.life  like ''%报维护%'' and A.province is not null
          group by
          ecgi, province, 
          life
        )T1,
        (
          select count(1) as CELL_NUM_BWH from dt_cell_l dt where dt.life like ''%报维护%''--分母中仅考虑报维护类型的小区
        )dt
        group by S_DATE, DAYS_RANGE, PROVINCE';
        --dbms_output.put_line(v_ssql_t2);--打印拼接结果
        execute immediate v_ssql_t2;
        commit;
        commit;
        --厂家
        v_ssql_t2 := 
        'insert /*+append */ into '||v_tbname||'
        select S_DATE, DAYS_RANGE, 
        VENDOR_ID as AREA,--省份
        ''厂家'' AS AREA_LEVEL,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(DJR_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as DJR_RATE,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(GDH_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as GDH_RATE,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(KKSXGDB_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as KKSXGDB_RATE,
        100*decode(max(dt.CELL_NUM_BWH),0,null,null,null, round(sum(KKXXGDB_BADFLAG_EXP)/max(dt.CELL_NUM_BWH), 4)) as KKXXGDB_RATE,
        sum(DJR_BADFLAG_EXP) as DJR_BADCELL_NUM,
        sum(GDH_BADFLAG_EXP) as GDH_BADCELL_NUM,
        sum(KKSXGDB_BADFLAG_EXP) as KKSXGDB_BADCELL_NUM,
        sum(KKXXGDB_BADFLAG_EXP) as KKXXGDB_BADCELL_NUM,
        max(dt.CELL_NUM_BWH) CELL_NUM_BWH
        from
        (
          select 
          to_date('||V_DATE_THRESHOLD_START||', ''yyyymmdd'') as s_date,
          substr('||V_DATE_THRESHOLD_START||',3,2)||'': ''||to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''mm'')||''/''|| to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''dd'')||''~''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''mm'')||''/''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''dd'') DAYS_RANGE, --评估周级范围, --当前日期下的前7天
          ecgi, 
          case when sum(DJR_BADFLAG)>=3 then 1 else 0 end DJR_BADFLAG_EXP,--7天指标内有3天不达标  --低接入小区
          case when sum(GDH_BADFLAG)>=3 then 1 else 0 end GDH_BADFLAG_EXP,--高掉话小区占比
          case when sum(KKSXGDB_BADFLAG)>=3 then 1 else 0 end KKSXGDB_BADFLAG_EXP,--空口上行高丢包小区占比
          case when sum(KKXXGDB_BADFLAG)>=3 then 1 else 0 end KKXXGDB_BADFLAG_EXP,--空口下行高丢包小区占比
          vendor_id, --厂家
          life
          from
          (';
        v_ssql_t2 := v_ssql_t2||v_ssql_t1||')A--质差数据
          where A.life like ''%报维护%'' and A.vendor_id is not null
          group by
          ecgi, vendor_id, 
          life
        )T1,
        (
          select count(1) as CELL_NUM_BWH from dt_cell_l dt where dt.life like ''%报维护%''--分母中仅考虑报维护类型的小区
        )dt
        group by S_DATE, DAYS_RANGE, VENDOR_ID';
        --dbms_output.put_line(v_ssql_t2);--打印拼接结果
        execute immediate v_ssql_t2;
        commit;
        commit;
        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition(P_'||V_DATE_THRESHOLD_START||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition(P_'||V_DATE_THRESHOLD_START||') 
        group by s_date, area having count(1)>1)'into v_insert_repeat;
        dbms_output.put_line('表 '||v_tbname||' 天级数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
        
    END PROC_LC_INDEX_VOLTE_BAD_CELL_DAY;

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --VOLTE区域指标结果表周期性汇聚任务激活
    PROCEDURE ACTIVE_LC_INDEX_VOLTE_89A_AUTO AS
    V_DATE_START  varchar2(15);--天表任务激活时间戳
    V_DATE_MONDAY date;
    V_DATE_MONTH   date;
    v_inside_loop_log number := 0;
    v_loop_log number := 0;
    v_tbname varchar2(50);
    v_partition_name varchar2(30);
    v_exsit_flag number := 0;
    v_pkg_name varchar2(200);
    
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190814
        
        --每日执行昨日天级汇聚
        v_tbname := 'LC_INDEX_VOLTE_8';
        v_pkg_name := 'PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_8';
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t
        where t.table_name = v_tbname
        --and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = V_DATE_START;
        
        --这里三表的分区名均严格遵守分区格式，故只需索引一张表即可获取其余表的待处理分区名，P_20190825...
        --LC_INDEX_VOLTE_8
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_exsit_flag;
        while v_exsit_flag = 0 and v_partition_name is not null loop 
          exit when v_inside_loop_log >=5;
          PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_8(V_DATE_START);
          execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_exsit_flag;
          v_inside_loop_log := v_inside_loop_log +1;
        end loop;
        --log
        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_LOGGING(sysdate, v_pkg_name, v_inside_loop_log, v_exsit_flag);
        /*insert into db_check(execute_sdate, execute_sql, v_loop_log, v_exsit_flag)
        (
          select sysdate,
          'PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_8('||V_DATE_START||')',
          v_inside_loop_log,
          v_exsit_flag
          from dual
        );
        commit;*/
        v_loop_log := v_loop_log +1;
        
        --ZC_CELL_LIST_VOLTE_DAY
        v_tbname := 'ZC_CELL_LIST_VOLTE_DAY';
        v_pkg_name := 'PKG_LC_INDEX_VOLTE_CELL.PROC_ZC_CELL_LIST_VOLTE_DAY';
        v_inside_loop_log := 0;
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_exsit_flag;
        while v_exsit_flag = 0 and v_partition_name is not null loop 
          exit when v_inside_loop_log >=5;
          PKG_LC_INDEX_VOLTE_CELL.PROC_ZC_CELL_LIST_VOLTE_DAY(V_DATE_START);
          execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_exsit_flag;
          v_inside_loop_log := v_inside_loop_log +1;          
        end loop;
        --log
        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_LOGGING(sysdate, v_pkg_name, v_inside_loop_log, v_exsit_flag);
        v_loop_log := v_loop_log +1;
        
        --LC_INDEX_VOLTE_BAD_CELL_DAY
        v_tbname := 'LC_INDEX_VOLTE_BAD_CELL_DAY';
        v_pkg_name := 'PKG_LC_INDEX_VOLTE_CELL.LC_INDEX_VOLTE_BAD_CELL_DAY';
        v_inside_loop_log := 0;
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_exsit_flag;
        while v_exsit_flag = 0 and v_partition_name is not null loop 
          exit when v_inside_loop_log >=5;
          PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_BAD_CELL_DAY(V_DATE_START);
          execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_exsit_flag;
          v_inside_loop_log := v_inside_loop_log +1;          
        end loop;
        --log
        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_LOGGING(sysdate, v_pkg_name, v_inside_loop_log, v_exsit_flag);
        v_loop_log := v_loop_log +1;
        
        --select /*rownum,*/ t.*, t.rowid from FAST_DATA_PROCESS_TEMPLATE t /*where t.table_name = 'PERF_CELL_L_HW_PRE_3' */order by t.template_id;

        
        --周/月汇聚触发时间戳保存
        V_DATE_START :=  to_char(sysdate,'yyyymmdd');--20190819
        V_DATE_MONDAY := trunc(next_day(sysdate,'星期一'))-7;--20190819
        V_DATE_MONTH := trunc(sysdate, 'mm');--20190801
        
        if  trunc(sysdate) = V_DATE_MONDAY--每周周一执行上周周汇聚--2019/08/19 = 2019/08/19
          then 
            PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_9(V_DATE_START);--in：20190812 执行汇聚时间都会在包内转换为上周周一：20190624
            v_loop_log := v_loop_log +1;
        elsif  trunc(sysdate) = V_DATE_MONTH--每月一号执行上月月级汇聚--2019/08/01 = 2019/08/01
          then 
            PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_A(V_DATE_START);--in：20190801 执行汇聚时间会在包内转换为上月首日：20190601
            v_loop_log := v_loop_log +1;
        end if;

        dbms_output.put_line('VOLTE区域指标天/周/月汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');

    END ACTIVE_LC_INDEX_VOLTE_89A_AUTO;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --VOLTE区域指标结果表周期性汇聚任务激活（小时/区域）
    PROCEDURE ACTIVE_LC_INDEX_VOLTE_3_AUTO AS
    V_DATE_START  varchar2(15);
    V_DATE_HOUR  varchar2(2);

    --V_DATE_MONDAY date;
    --V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        --V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        V_DATE_START := to_char(sysdate + interval '-4' hour, 'yyyymmdd'); --20190807
        V_DATE_HOUR := to_char(sysdate + interval '-4' hour, 'hh24'); --17:31 → 13 数据延迟入库约2.5小时，以防万一，执行4小时前的数据汇聚（保守操作）
        /*if  to_char(sysdate,'mi:ss') = '00:00'--每个小时的开始执行，好像不需要这句，DBJob里可以设置小时触发...
          then*/
        PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_3(V_DATE_START,V_DATE_HOUR);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
        v_loop_log := v_loop_log + 1;

        /*end if;*/
        dbms_output.put_line('VOLTE小时级区域指标汇聚任务完成（小时/区域）！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');    
    END ACTIVE_LC_INDEX_VOLTE_3_AUTO;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    --NB基表数据补偿
    PROCEDURE ACTIVE_LC_INDEX_VOLTE_89A_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2) AS
    --V_DATE_START  varchar2(15);
    --V_DATE_MONDAY date;
    --V_DATE_MONTH   date;
    v_loop_log number := 0;
    BEGIN
        --起止时间戳格式化，时间自动化，读取时间：sysdate--2019/07/01
        --V_DATE_START :=  to_char(sysdate-1,'yyyymmdd');--20190630
        --每日执行昨日天级汇聚
        PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_8(V_DATE_THRESHOLD_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_VOLTE_CELL.PROC_ZC_CELL_LIST_VOLTE_DAY(V_DATE_THRESHOLD_START);
        v_loop_log := v_loop_log +1;
        PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_BAD_CELL_DAY(V_DATE_THRESHOLD_START);
        v_loop_log := v_loop_log +1;
        
        --周/月汇聚触发时间戳保存
        /*
        if  trunc(sysdate) = V_DATE_MONDAY--每周周一执行上周周汇聚--2019/07/01 = 2019/07/01
          then 
            --V_DATE_START :=  to_char(sysdate,'yyyymmdd');--20190701
            PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_9(V_DATE_START);--in：20190701 执行汇聚时间都会在包内转换为上周周一：20190624
            v_loop_log := v_loop_log +1;
        elsif  trunc(sysdate) = V_DATE_MONTH--每月一号执行上月月级汇聚--2019/07/01 = 2019/07/01
          then 
            --V_DATE_START := to_char(sysdate,'yyyymmdd');--20190701
            PKG_LC_INDEX_VOLTE_CELL.PROC_LC_INDEX_VOLTE_A(V_DATE_START);--in：20190701 执行汇聚时间会在包内转换为上月首日：20190601
            v_loop_log := v_loop_log +1;
        end if;*/

        dbms_output.put_line('VOLTE天级区域指标/天级质差小区清单/天级质差区域指标补偿任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，存储过程执行数量：'||v_loop_log||'.');
        dbms_output.put_line('****------------------------------------------------------------------****
        ');
    END ACTIVE_LC_INDEX_VOLTE_89A_SUPPLEMENT;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
    PROCEDURE PROC_TEST IS
    v_date_start  VARCHAR2(20);
    --v_ssql CLOB;
    /*i_tablename   varchar2(30);
    --v_loop_log number := 0 ;
    i_tablespace   varchar2(30);
    i_part_name   varchar2(30);
    i_part_date varchar2(30);
    i_partition_name varchar2(500);*/

    --v_clean_flag number;
    --v_proc_end_flag number :=0;    
    BEGIN
        select 1 into v_date_start from dual;
        /*select dbms_output.put_line('234G质差小区清单天级汇聚任务完成！完成时间戳：'||sysdate) into v_ssql from dual;*/
        --select count(1) into v_date_start from sys.gv_$locked_object a;
    END PROC_TEST;
    


END PKG_LC_INDEX_VOLTE_CELL;
/

