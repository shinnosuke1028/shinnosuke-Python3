create PROCEDURE PARTITION_LOCATE(V_TABLE_NAME VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2, V_PARTITION_NAME OUT VARCHAR2) AS
    v_high_value_vc                 varchar2(20);

    TYPE PARTITION_TYPE IS RECORD(
        table_name      varchar2(200),
        partition_name  varchar2(50),
        high_value      varchar2(100)
    );

    -- 定义基于记录的嵌套表
    TYPE NESTED_TYPE IS TABLE OF PARTITION_TYPE;
    -- 声明集合变量
    NESTED_TAB      NESTED_TYPE;
    -- 定义了一个变量来作为limit的值
    V_LIMIT         PLS_INTEGER := 500;
    -- 定义变量来记录FETCH次数
    V_COUNTER       INTEGER := 0;

    cursor CUR_PARTITION is --字典表内获取非标准分区的分区名
    select table_name,t.partition_name,t.high_value from USER_TAB_PARTITIONS t where table_name = V_TABLE_NAME and partition_name not like 'P2%'--SYS_21313
    order by to_number(substr(partition_name,6)) desc;--按照分区名降序遍历

    BEGIN
        OPEN CUR_PARTITION; --开始索引字典表
        LOOP--------------
            FETCH CUR_PARTITION BULK COLLECT INTO NESTED_TAB LIMIT V_LIMIT;
            EXIT WHEN NESTED_TAB.count = 0;
            V_COUNTER := V_COUNTER + 1; 
            FOR I IN NESTED_TAB.FIRST .. NESTED_TAB.LAST
            LOOP
                --区分TIMESTAMP类型：TIMESTAMP' 2019-04-25 00:00:00'
                if substr(NESTED_TAB(I).high_value, 1, 2) = 'TI'
                    then v_high_value_vc := substr(NESTED_TAB(I).high_value, 12, 10);
                else 
                    v_high_value_vc := substr(NESTED_TAB(I).high_value, 11, 10); --正常自增：less than 2019-07-14 ...
                end if;

                if (to_char(to_date(v_high_value_vc,'yyyy-mm-dd')-1, 'yyyymmdd') = V_DATE_THRESHOLD_START)
                then
                    V_PARTITION_NAME := NESTED_TAB(I).partition_name;
                    dbms_output.put_line('目标分区名：'||V_PARTITION_NAME);
                    exit;--降序遍历，达到目标分区值时(指定时间&指定时间一周前)，游标结束，退出！！！抛弃多余遍历
                end if;
            END LOOP;
        END LOOP;
        close cur_partition;--------------

        if V_PARTITION_NAME is NULL 
            then V_PARTITION_NAME := 'NULL'; 
        end if;

    END PARTITION_LOCATE;
/

