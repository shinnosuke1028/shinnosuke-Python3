create PACKAGE PKG_DAILY_CHECK AUTHID CURRENT_USER AS
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  指标监控-全局
  --
  --  OWNER:       Shinnosuke
  --
  --  VERSION:     1.0
  --
  --  CREATE DATE： 2019/09/09 version 1.0
  --               1.增加4G采集监控表ETL，85(scp) → 53
  --
------------------------------------------------------------------------

  --4G采集监控表ETL （CHECK_RESULT_2G4G）
  PROCEDURE CSV_CHECKRESULT;

END PKG_DAILY_CHECK;

/

