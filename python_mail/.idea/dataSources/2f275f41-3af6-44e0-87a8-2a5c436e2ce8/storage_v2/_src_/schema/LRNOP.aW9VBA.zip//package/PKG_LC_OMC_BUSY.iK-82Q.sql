create PACKAGE PKG_LC_OMC_BUSY AUTHID CURRENT_USER AS
------------------------------------------------------------------------
    --  OVERVIEW
    --
    --  34G OMC忙时表
    --
    --  OWNER:       Shinnosuke
    --
    --  VERSION:     1.1
    --
    --  CREATE DATE：2019/11/04 version 1.0
    --               1.增加4G OMC_LTE_3 忙时表输出过程（MAX:上下行流量排序） PROC_OMC_LTE_BUSY
    --               2.增加3G OMC_UMTS_3 忙时表输出过程（MAX:50*3600*n3_0009+1.2*8*n3_0019） PROC_OMC_UMTS_BUSY
    --               3.增加OMC忙时数据自动输出过程 ACTIVE_OMC_BUSY_AUTO
    --               4.增加OMC忙时数据补偿过程 ACTIVE_OMC_BUSY_SUPPLEMENT
    --
    --  UPDATE DATE：2019/11/12 version 1.1
    --               1.增加OSS工参表生成过程    PROC_OSS_DT_CELL_L
    --               2.增加OSS工参表生成过程    PROC_OSS_DT_CELL_W
    --               3.增加OSS工参自动输出过程   ACTIVE_OSS_DT_CELL_AUTO
    --               4.增加OSS工参补偿过程     ACTIVE_OSS_DT_CELL_SUPPLEMENT
    --               5.上述过程为独立过程，与忙时数据无关！！！
    --
    --  TODO    1.
    --
    --
------------------------------------------------------------------------
    --WCDMA-OMC忙时表输出过程
    --in：OMC_UMTS_3
    --out：OMC_UMTS_3_BUSY
    PROCEDURE PROC_OMC_UMTS_BUSY(V_DATE_THRESHOLD_START VARCHAR2);

    --LTE-OMC忙时表输出过程
    --in：OMC_LTE_3
    --out：OMC_LTE_3_BUSY
    PROCEDURE PROC_OMC_LTE_BUSY(V_DATE_THRESHOLD_START VARCHAR2);

    --OMC忙时自动任务
    PROCEDURE ACTIVE_OMC_BUSY_AUTO;

    --OMC忙时补偿任务
    PROCEDURE ACTIVE_OMC_BUSY_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);
    --PROCEDURE PROC_TEST;

------------------------------------------------------------------------
    --WCDMA OSS工参任务
    --in：OMC_UMTS_8, DT_CELL_W
    --out：OSS_DT_CELL_W
    PROCEDURE PROC_OSS_DT_CELL_W(V_DATE_THRESHOLD_START VARCHAR2);

    --LTE OSS工参任务
    --in：OMC_LTE_8, DT_CELL_L
    --out：OSS_DT_CELL_L
    PROCEDURE PROC_OSS_DT_CELL_L(V_DATE_THRESHOLD_START VARCHAR2);

    --LTE OSS工参任务
    --in：OMC_LTE_8, DT_CELL_NB
    --out：OSS_DT_CELL_NB
    --PROCEDURE PROC_OSS_DT_CELL_NB(V_DATE_THRESHOLD_START VARCHAR2);

    --LTE OSS工参任务
    --in：OMC_LTE_8, DT_CELL_NR
    --out：OSS_DT_CELL_NR
    --PROCEDURE PROC_OSS_DT_CELL_NR(V_DATE_THRESHOLD_START VARCHAR2);
    

END PKG_LC_OMC_BUSY;
/

