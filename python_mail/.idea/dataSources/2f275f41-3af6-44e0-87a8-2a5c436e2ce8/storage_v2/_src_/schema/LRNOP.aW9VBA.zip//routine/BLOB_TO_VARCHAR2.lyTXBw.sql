create FUNCTION BLOB_TO_VARCHAR2(BLOB_IN IN BLOB) RETURN VARCHAR2 IS
    v_varchar VARCHAR2(4000);
    v_start   PLS_INTEGER := 1;
    v_buffer  PLS_INTEGER := 4000;

    BEGIN
      --select userenv('LANGUAGE') into g_nls_db_char from dual;
      if DBMS_LOB.GETLENGTH(BLOB_IN) is null then
         return empty_clob();
      end if;

      DBMS_OUTPUT.put_line('Length:' || CEIL(DBMS_LOB.GETLENGTH(BLOB_IN)));
      --DBMS_LOB.CREATETEMPORARY(v_clob, TRUE);
      FOR i IN 1 .. CEIL(DBMS_LOB.GETLENGTH(BLOB_IN) / v_buffer) LOOP --处理4次，每次 v_buffer 个字符
          --乱码则注释掉下一行
          /*v_varchar := UTL_RAW.CAST_TO_VARCHAR2(utl_raw.convert(DBMS_LOB.SUBSTR(BLOB_IN, v_buffer, v_start),
                                                                'SIMPLIFIED CHINESE_CHINA.ZHS16GBK',
                                                                'AMERICAN_THE NETHERLANDS.UTF8'
                                                                ));*/
          v_varchar := UTL_RAW.CAST_TO_VARCHAR2(DBMS_LOB.SUBSTR(BLOB_IN, v_buffer, v_start));

          --DBMS_LOB.WRITEAPPEND(v_clob, LENGTH(v_varchar), v_varchar);
          v_start := v_start + v_buffer;
      END LOOP;

      --DBMS_OUTPUT.put_line(v_varchar);

      RETURN V_VARCHAR;

    END BLOB_TO_VARCHAR2;
/

