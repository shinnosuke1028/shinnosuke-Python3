create view TB_EXPORT_VIEW_W as
select A.s_date, A.lac_ci, PRE_FIELD4 as CELL_NAME, COUNTRY county, key "指标项", regexp_substr(value, '[^/]+',1,1,'i') "是否质差", regexp_substr(value, '[^/]+',1,2,'i') "是否突变", KPI_9 as "KPI_9", KPI_10, KPI_11, KPI_12, KPI_13, KPI_14, KPI_15, KPI_16, KPI_17, KPI_18, KPI_19, KPI_20, KPI_21, KPI_22, KPI_23/*,C.ex*/
,zc_style, tb_style
from
(
    select s_date, lac_ci, key, value from
    (
        select s_date, lac_ci,
        decode(W_JTL_BADFLAG,1,'是','否')||':'|| W_JTL_BADFLAG_SOURCE ||'/'|| decode(W_JTL_TBFLAG,1,'是','否') ||':'|| W_JTL_TBFLAG_SOURCE "3G接通率",
        decode(W_DHL_BADFLAG,1,'是','否')||':'|| W_DHL_BADFLAG_SOURCE ||'/'|| decode(W_DHL_TBFLAG,1,'是','否') ||':'|| W_DHL_TBFLAG_SOURCE "3G掉话率",
        decode(W_RTWP_BADFLAG,1,'是','否')||':'|| W_RTWP_BADFLAG_SOURCE ||'/'|| decode(W_RTWP_TBFLAG,1,'是','否') ||':'|| W_RTWP_TBFLAG_SOURCE "3G高干扰",
        decode(W_GCJ_BADFLAG,1,'是','否')||':'|| W_GCJ_BADFLAG_SOURCE ||'/'|| decode(W_GCJ_TBFLAG,1,'是','否') ||':'|| W_GCJ_TBFLAG_SOURCE "3G高重建",
        decode(W_RQH_BADFLAG,1,'是','否')||':'|| W_RQH_BADFLAG_SOURCE ||'/'|| decode(W_RQH_TBFLAG,1,'是','否') ||':'|| W_RQH_TBFLAG_SOURCE "3G软切换成功率",
        ' '||'/'|| decode(W_HWL_TBFLAG,1,'是','否')||':'|| W_HWL_TBFLAG_SOURCE "3G话务量"

        /* decode(jtl_badflag,1,'是','否')||'/'||decode(jtl_tbflag,1,'是','否')||':'|| jtl_badflag_source||'/'||jtl_tbflag_source "4G接通率",
        decode(dxl_badflag,1,'是','否')||'/'||decode(dxl_tbflag,1,'是','否')||':'|| dxl_badflag_source||'/'||dxl_tbflag_source "4G掉线率",
        decode(avg_rtwp_badflag,1,'是','否')||'/'||decode(avg_rtwp_tbflag,1,'是','否')||':'|| avg_rtwp_badflag_source||'/'||avg_rtwp_tbflag_source "4G高干扰",
        decode(ll_tbflag,1,'是','否')||':'|| ll_tbflag_source "4G流量",
        decode(csfb_cgl_badflag,1,'是','否')||'/'||decode(csfb_cgl_tbflag,1,'是','否')||':'|| csfb_cgl_badflag_source||'/'||csfb_cgl_tbflag_source "CSFB",
        decode(tpqh_cgl_badflag,1,'是','否')||'/'||decode(tpqh_cgl_tbflag,1,'是','否')||':'|| tpqh_cgl_badflag_source||'/'||tpqh_cgl_tbflag_source "4G切换",
        decode(ta_tbflag,1,'是','否')||':'|| ta_tbflag_source "4GTA",
        decode(mr_badflag,1,'是','否')||'/'||decode(mr_tbflag,1,'是','否')||':'|| mr_badflag_source||'/'||mr_tbflag_source "4GMR" */
        --jtl_badflag_source, jtl_tbflag_source,
        --dxl_badflag_source, dxl_tbflag_source,
        -- avg_rtwp_badflag_source, avg_rtwp_tbflag_source,
        -- ll_tbflag_source,
        -- csfb_cgl_badflag_source, csfb_cgl_tbflag_source,
        -- tpqh_cgl_badflag_source, tpqh_cgl_tbflag_source,
        -- ta_tbflag_source,
        -- mr_badflag_source, mr_tbflag_source
        from TB_INDEX_CELL_DAY_W where s_date >= trunc(sysdate-60, 'mm')  --and lac_ci = 8806412
    ) t1 unpivot
    (
      VALUE for KEY in ("3G接通率", "3G掉话率", "3G高干扰", "3G高重建", "3G软切换成功率", "3G话务量"/*,
      JTL_BADFLAG_SOURCE, DXL_BADFLAG_SOURCE, AVG_RTWP_BADFLAG_SOURCE, CSFB_CGL_BADFLAG_SOURCE,
      TPQH_CGL_BADFLAG_SOURCE, MR_BADFLAG_SOURCE, JTL_TBFLAG_SOURCE, DXL_TBFLAG_SOURCE, AVG_RTWP_TBFLAG_SOURCE,
      LL_TBFLAG_SOURCE, CSFB_CGL_TBFLAG_SOURCE, TPQH_CGL_TBFLAG_SOURCE, TA_TBFLAG_SOURCE, MR_TBFLAG_SOURCE*/)
    )
)A
left join
(
    select s_date, lac_ci, style, KPI_9, KPI_10, KPI_11, KPI_12, KPI_13, KPI_14, KPI_15, KPI_16, KPI_17, KPI_18, KPI_19, KPI_20, KPI_21, KPI_22, KPI_23, /*PROVINCE, VENDOR_CELL_ID,*/ COUNTRY,
    /*VENDOR_ID, RESERVED3, RESERVED8, TOWN_ID, RNC, RESERVED4, RESERVED5, COVER_TYPE, */ PRE_FIELD4,/*, PRE_FIELD5, LIFE, LON, LAT*/
    case when (style = '3G话务量') then '' else '质差-'||style end as zc_style,
    '突变-'||style tb_style
    from TB_EXPORT_W
    where s_date >= trunc(sysdate-60, 'mm') --and lac_ci = 8806412
)B
on A.s_date = B.s_date and A.lac_ci = B.lac_ci and A.key = B.style
/

comment on table TB_EXPORT_VIEW_W is '3G质差突变趋势表'
/

comment on column TB_EXPORT_VIEW_W.S_DATE is '日期'
/

comment on column TB_EXPORT_VIEW_W.LAC_CI is 'LAC_CI'
/

comment on column TB_EXPORT_VIEW_W.CELL_NAME is '小区中文名'
/

comment on column TB_EXPORT_VIEW_W.COUNTY is '优化分区'
/

comment on column TB_EXPORT_VIEW_W."指标项" is '指标项'
/

comment on column TB_EXPORT_VIEW_W."是否质差" is '质差标签（粒度：天+小区）是:3<连续3日> / 是:6<累计6日> / 是:3-6 / 否:0'
/

comment on column TB_EXPORT_VIEW_W."是否突变" is '突变标签（粒度：天+小区）是:3<连续3日> / 是:6<累计6日> / 是:3-6 / 否:0'
/

comment on column TB_EXPORT_VIEW_W.KPI_9 is '9点(上周\本周)，"~"表示单指标含两组判定内容，如：3G掉话率~3G掉话次数'
/

comment on column TB_EXPORT_VIEW_W.KPI_10 is '10点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_11 is '11点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_12 is '12点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_13 is '13点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_14 is '14点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_15 is '15点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_16 is '16点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_17 is '17点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_18 is '18点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_19 is '19点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_20 is '20点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_21 is '21点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_22 is '22点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW_W.KPI_23 is '23点(上周\本周)，"~"表示单指标含两组判定内容'
/

