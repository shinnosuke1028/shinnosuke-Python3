create view SCHEDULER_LOG_VIEW as
select log_id, log_date+0 log_date, owner, t1.job_name,
/* job_subname,*/ status, error#, actual_start_date+0 actual_start_date,
run_duration, t2.next_run_date,
cpu_used, additional_info, errors, output, binary_errors,
binary_output, instance_id, session_id, slave_pid
from
(
    select * from dba_scheduler_job_run_details t
    where owner = 'LRNOP' and log_date >= trunc(sysdate-7)
)t1
left join
(
    select job_name, t.last_start_date + 0 last_start_date, t.next_run_date +0 next_run_date, repeat_interval
    from dba_scheduler_jobs t where OWNER = 'LRNOP'
)t2
on t1.job_name = t2.job_name
order by 2 desc
/

