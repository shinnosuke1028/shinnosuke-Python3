create FUNCTION INDEX_RECOGN(V_TABLE_NAME VARCHAR2) RETURN INDEX_TABLE IS
    --游标明细
    -- 定义基于记录的嵌套表
    --TYPE INDEX_TYPE_TB IS TABLE OF INDEX_TYPE;
    -- 声明集合变量
    INDEX_TAB INDEX_TABLE;

    -- -- 定义了一个变量来作为limit的值
    -- V_LIMIT PLS_INTEGER := 1000;
    -- -- 定义变量来记录FETCH次数
    -- V_COUNTER INTEGER := 0;

    -- TYPE CurTyp IS REF CURSOR;
    -- CUR_SQL_1  CurTyp;

    BEGIN
        select INDEX_TYPE(table_name_type, constraint_type, search_condition_vc, index_vc, tablespace_name,
        part_index_status,
        non_part_tbspace,
        non_part_index_status,
        uniqueness)--这里不通过最底层的INDEX_TYPE格式化结果，会报参数不够的错误
        BULK COLLECT INTO INDEX_TAB
        from
        (
            select 
            nvl(table_name_type, 'NULL') as table_name_type, 
            nvl(constraint_type, 'NULL') as constraint_type, 
            nvl(search_condition_vc, 'NULL') as search_condition_vc, 
            nvl(index_vc, 'NULL') as index_vc, 
            nvl(s.tablespace_name, 'NULL') as tablespace_name,
            nvl(s.status, 'NULL') as part_index_status,
            nvl(u.tablespace_name, 'NULL')as non_part_tbspace,
            nvl(u.status, 'NULL') as non_part_index_status,
            nvl(uniqueness, 'NULL') as uniqueness from
            (
                select t1.table_name||'---'||t1.constraint_type as table_name_type,
                nvl(t1.search_condition_vc, t2.constraint_name) search_condition_vc,
                t1.table_name, t1.constraint_type
                from
                (
                  select u.table_name, u.constraint_type,
                  listagg(search_condition_vc, '
            ') within GROUP(order by search_condition_vc) search_condition_vc--换行符分隔
                  /*decode(listagg(search_condition_vc, ', ') within GROUP(order by search_condition_vc), null, u.constraint_name,
                  listagg(search_condition_vc, ', ') within GROUP(order by search_condition_vc))search_condition_vc*/
                  --select *
                  from user_constraints u where u.table_name = V_TABLE_NAME
                  group by table_name, constraint_type
                )t1,
                (
                  select * from user_constraints where constraint_type <>'C'
                ) t2
                where t1.table_name = t2.table_name --and t1.constraint_type = t2.constraint_type
                union
                select t.table_name||'---'||'INDEX' table_name_type, t.index_name as search_condition_vc, table_name, 'INDEX'
                from user_indexes t where t.table_name = V_TABLE_NAME
            )x
            --group by table_name
            left join
            (
                select index_name, table_name,
                listagg(column_name, ', ') within GROUP(order by column_position) index_vc
                --select *
                from user_ind_columns
                --where index_name='WK_TEST2_INDEX_LOCAL'
                where table_name = V_TABLE_NAME
                group by index_name, table_name
            )i
            on x.search_condition_vc = i.index_name
            and x.table_name = i.table_name
            left join
            user_indexes u
            on i.table_name = u.table_name and i.index_name = u.index_name
            left join
            USER_IND_PARTITIONS s
            on i.index_name = s.index_name
        )
        order by table_name_type, constraint_type
        ;

        RETURN INDEX_TAB;

    END INDEX_RECOGN;
/

