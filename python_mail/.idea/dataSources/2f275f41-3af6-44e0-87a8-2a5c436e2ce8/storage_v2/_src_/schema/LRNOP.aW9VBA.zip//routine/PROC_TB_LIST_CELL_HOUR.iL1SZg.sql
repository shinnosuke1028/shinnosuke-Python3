create PROCEDURE PROC_TB_LIST_CELL_HOUR(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := NULL) IS --小区小时指标
    --v_high_value_vc                 varchar2(20);
    v_partition_name                varchar2(50);
    --v_partition_name_7_ago          varchar2(50);
    --v_mr_partition_name                varchar2(50);
    --v_mr_partition_name_7_ago          varchar2(50);
    --V_DATE_THRESHOLD_START_7_AGO    varchar2(8);
    V_TBNAME                        varchar2(100);
    V_DATE_THRESHOLD_END    varchar2(8) := to_char(to_date(V_DATE_THRESHOLD_START, 'yyyymmdd') + 1, 'yyyymmdd');--20190927
    --v_s_date_7            date;
    --sql_2                   varchar2(4000);
    --V_DATE_THRESHOLD_HOUR                varchar2(20);

    v_insert_cnt   number;
    v_insert_repeat   number;
    v_ssql varchar2(500);
    v_clean_flag number;
    --i_date_hour varchar2(20);

    i number := 0;
    -- c_high_value varchar2(200);
    -- c_table_name varchar2(50);
    -- c_partition_name varchar2(80);

    type omc_3_type is record(
        s_date          date,
        s_hour          integer,
        enb_id          integer,
        cell_id         integer,
        ecgi            integer,
        LTE_JTL         number,
        JTL_QUEST_NUM   number,
        LTE_DXL         number,
        DXL_DX_NUM      number,
        AVG_RTWP        number,
        LTE_LL          number,
        LL_QAM_ZB       number,
        LL_GZSL         number,
        CSFB_CGL        number,
        CSFB_QUEST_NUM  number,
        TPQH_CGL        number,
        TPQH_QUEST_NUM  number,
        TA              number,

        n4_0001         number,
        n4_0002         number,
        n4_0003         number,
        n4_0004         number,
        n4_0005         number,
        n4_0006         number,
        n4_0033         number,
        n4_0050         number,
        n4_0027         number,
        n4_0037         number,
        n4_0036         number,
        n4_0032         number,
        n4_0023         number,
        n4_0024         number,
        n4_0041         number,
        n4_0042         number,
        n4_0045         number,

        RSRP_110_RATE   number,
        RSRP_ALL_SIMPLES      number,
        PROVINCE        varchar2(32),
        VENDOR_CELL_ID  varchar2(32),
        COUNTY          varchar2(32),
        VENDOR_ID       varchar2(32),
        RESERVED3       varchar2(32),
        RESERVED8       varchar2(32),
        TOWN_ID         varchar2(32),
        RNC             varchar2(32),
        RESERVED4       varchar2(32),
        RESERVED5       varchar2(32),
        COVER_TYPE      varchar2(32),
        LIFE            varchar2(32),
        LON             number,
        LAT             number
    );
    omc3_tmp_1 omc_3_type;

    JTL_BADFLAG         varchar2(10);
    DXL_BADFLAG         varchar2(10);
    AVG_RTWP_BADFLAG    varchar2(10);
    CSFB_CGL_BADFLAG    varchar2(10);
    TPQH_CGL_BADFLAG    varchar2(10);
    MR_BADFLAG          varchar2(10);

    /*type partition_type is record(
        table_name      varchar2(200),
        partition_name  varchar2(50),
        high_value      varchar2(100)
    );
    partition_tmp partition_type;


    cursor cur_partition is --字典表内获取非标准分区的分区名
    select table_name,t.partition_name,t.high_value
    from USER_TAB_PARTITIONS t
    where table_name = V_TBNAME and partition_name not like 'P2%'--SYS_21313
    order by to_number(substr(partition_name,6)) desc;--按照分区名降序遍历*/

    /*type curtyp is ref cursor;
    cur_sql_2 curtyp;*/


    cursor CUR_SQL_1 is
    select /*+ parallel(a,4)  nologging */ a.* from
    (
    select omc.*, mr.RSRP_110_RATE, mr.RSRP_ALL_SIMPLES,
/*    case when omc.LTE_JTL < 90 and omc.JTL_QUEST_NUM > 1000 then 1 else 0 end JTL_BADFLAG,
    case when omc.LTE_DXL > 5  and omc.DXL_DX_NUM > 200 then 1 else 0 end DXL_BADFLAG,
    case when omc.AVG_RTWP > -95 then 1 else 0 end AVG_RTWP_BADFLAG,
    case when omc.CSFB_CGL < 90 and omc.CSFB_QUEST_NUM > 20 then 1 else 0 end CSFB_CGL_BADFLAG,
    case when omc.TPQH_CGL < 80 and omc.TPQH_QUEST_NUM > 100 then 1 else 0 end TPQH_CGL_BADFLAG,
    case when mr.RSRP_110_RATE < 80 and mr.RSRP_ALL_SIMPLES > 5000 then 1 else 0 end MR_BADFLAG,*/
    PROVINCE, VENDOR_CELL_ID, COUNTY, VENDOR_ID, RESERVED3, RESERVED8,
    TOWN_ID, RNC, RESERVED4, RESERVED5, COVER_TYPE, /*PRE_FIELD4, PRE_FIELD5,*/ LIFE, LON, LAT from
    (
      select
      s_date, s_hour, omc_enb_id as enb_id, omc_cell_id as cell_id, omc_ecgi as ecgi,
      100*decode((n4_0002*n4_0004),0,null,null,null, round(n4_0001*n4_0003/(n4_0002*n4_0004), 4)) as LTE_JTL,
      decode(n4_0002,null,null, n4_0002) as JTL_QUEST_NUM,
      100*decode(n4_0006,0,null,null,null, round(n4_0005/n4_0006, 4)) as LTE_DXL,
      decode(n4_0005,null,null, n4_0005) as DXL_DX_NUM,
      decode(n4_0033,0,null,null,null, round(n4_0033, 2)) as AVG_RTWP,  --0的话为错误数据
      round((decode(n4_0050,null,0, n4_0050) + decode(n4_0027,null,0, n4_0027))*1024*1024/1000/1000/1000, 2) as LTE_LL,
      100*decode(n4_0037,0,null,null,null, round(n4_0036/n4_0037, 4)) as LL_QAM_ZB,
      round(n4_0032*1024*1024/1000/1000, 2) as LL_GZSL,
      100*decode(n4_0024,0,null,null,null, round(n4_0023/n4_0024, 4)) as CSFB_CGL,
      decode(n4_0024,null,0, n4_0024) as CSFB_QUEST_NUM,
      100*decode(n4_0042,0,null,null,null, round(n4_0041/n4_0042, 4)) as TPQH_CGL,
      decode(n4_0042,null,0, n4_0042) as TPQH_QUEST_NUM,
      round(n4_0045, 2) as TA,
      n4_0001, n4_0002, n4_0003, n4_0004,
      n4_0005, n4_0006,
      n4_0033,
      n4_0050, n4_0027,
      n4_0037, n4_0036, n4_0032,
      n4_0023, n4_0024,
      n4_0041, n4_0042,
      n4_0045
      from
      (
        select s_date, s_hour,
        enb_id as omc_enb_id, cell_id as omc_cell_id, ecgi as omc_ecgi, vendor,
        n4_0001, n4_0002, n4_0003, n4_0004,
        n4_0005, n4_0006,
        n4_0033,
        n4_0050, n4_0027,
        n4_0036, n4_0037,
        n4_0032,
        n4_0023, n4_0024,
        n4_0041, n4_0042,
        n4_0045
        from omc_lte_3 where s_date >= to_date(V_DATE_THRESHOLD_START ,'yyyymmdd') and s_date < to_date(V_DATE_THRESHOLD_END ,'yyyymmdd')
        and s_hour between 9 and 23
        and s_hour = (case when V_DATE_HOUR is null then s_hour else cast(V_DATE_HOUR as int) end)
      )
    )omc
    left join
    (
        select t.* from dt_cell_l t
    ) dt
    on omc.ecgi = dt.ecgi
    left join
    (
      select
      s_date,
      s_hour,
      mrs_ecgi,
      100*decode((RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47),0,null,null,null,
      round((RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47)/
      (RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47), 4) ) as RSRP_110_RATE,
      (RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47) as RSRP_ALL_SIMPLES
      from
      (
        select trunc(start_time) s_date,
        cast(s_hour as int) s_hour,
        regexp_substr(t.cell_uk, '[^-]+',1,1,'i') as enb_id, regexp_substr(t.cell_uk, '[^-]+',1,2,'i') as cell_id,
        --regexp_substr(t.cell_uk, '[^-]+',1,1,'i')*256 + regexp_substr(t.cell_uk, '[^-]+',1,2,'i') mrs_ecgi,
        ecgi mrs_ecgi,
        rsrp00, rsrp01, rsrp02_04, rsrp05_06,
        rsrp07_11, rsrp12_16, rsrp17_21, rsrp22_26,
        rsrp27_31, rsrp32_36, rsrp37_41, rsrp42_46,
        rsrp47
        from mr_lte_mrs_cell_3 t
        where start_time >= to_date(V_DATE_THRESHOLD_START ,'yyyymmdd') and start_time < to_date(V_DATE_THRESHOLD_END ,'yyyymmdd')
      )where s_hour = (case when V_DATE_HOUR is null then s_hour else cast(V_DATE_HOUR as int) end)
      and s_hour between 9 and 23
    )mr
    on omc.ecgi = mr.mrs_ecgi and omc.s_date = mr.s_date and omc.s_hour = mr.s_hour
    )a;

    BEGIN
        --起止时间戳格式化
        --v_date_start := to_date(V_DATE_THRESHOLD_START,'yyyymmdd');--起始时间戳'yyyymmdd'格式化
        --v_date_end := v_date_start + 1;--起始时间戳'yyyymmdd'格式化
        V_TBNAME := 'TB_LIST_CELL_HOUR';

        --从系统中获取待插入分区名
        /*execute immediate 'select t.partition_name from USER_TAB_PARTITIONS t
        where t.table_name = :V_TBNAME
        and regexp_substr(t.partition_name,''[^_]+'',1,2,''i'') = :V_DATE_THRESHOLD_START; '
        into v_partition_name using V_TBNAME, V_DATE_THRESHOLD_START;*/

        PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_LOCATE(V_TBNAME, V_DATE_THRESHOLD_START, V_PARTITION_NAME);

        /*open cur_partition; --开始索引字典表
        fetch cur_partition into partition_tmp.table_name, partition_tmp.partition_name, partition_tmp.high_value;
        loop--------------
            exit when NOT (cur_partition%FOUND);
            v_high_value_vc := substr(partition_tmp.high_value, 11, 10); --less than 2019-07-14 ...
            if (to_char(to_date(v_high_value_vc,'yyyy-mm-dd')-1, 'yyyymmdd') = V_DATE_THRESHOLD_START)
                then
                    v_partition_name := partition_tmp.partition_name;
                    dbms_output.put_line(v_partition_name);
                    exit;--降序遍历，达到目标分区值时(指定时间&指定时间一周前)，游标结束，退出！！！抛弃多余遍历
            \*elsif (to_char(to_date(v_high_value_vc,'yyyy-mm-dd')-1, 'yyyymmdd') = V_DATE_THRESHOLD_START_7_AGO)
                then
                    v_partition_name_7_ago := partition_tmp.partition_name;
                    dbms_output.put_line(v_partition_name_7_ago);*\
            end if;
            fetch cur_partition into partition_tmp.table_name, partition_tmp.partition_name, partition_tmp.high_value;
        end loop;
        close cur_partition;--------------*/

        if V_DATE_HOUR is not null
          then
              --清理
              execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||V_DATE_HOUR into v_clean_flag;
              while v_clean_flag !=0 loop
                  --若入口参数指定了小时，则仅重跑指定小时对应的数据，此处索引至天级分区，并按小时清除
                  execute immediate 'delete from '||v_tbname||' partition('||v_partition_name||') where s_hour='||V_DATE_HOUR;
                  commit;
                  dbms_output.put_line('表 '||v_tbname||' 的小时级数据已清理，清理时刻：'||V_DATE_HOUR);
                  /*select
                  'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
                  into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
                  where s.table_name = v_tbname;
                  execute immediate v_ssql;*/
                  --select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
                  execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||') where s_hour='||V_DATE_HOUR into v_clean_flag;
              end loop;
          elsif V_DATE_HOUR is null
          then
              --清理
              execute immediate 'select count(1) from '||V_TBNAME||' partition('||v_partition_name||')' into v_clean_flag;
              while v_clean_flag !=0 loop
                  select
                  'CALL PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||V_DATE_THRESHOLD_START||''','''||V_DATE_THRESHOLD_START||''')'
                  into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
                  where s.table_name = V_TBNAME;
                  execute immediate v_ssql;
                  execute immediate 'select count(1) from '||V_TBNAME||' partition('||v_partition_name||')' into v_clean_flag;
              end loop;
        end if;
        --准备工作完成！！

        --开始
        open cur_sql_1; --data_cur
        fetch cur_sql_1 into omc3_tmp_1;
        --v_s_date_7 := omc3_tmp_1.s_date - 7;
        loop
            exit when NOT (cur_sql_1%FOUND);
            --标签初始化
            JTL_BADFLAG := 0;
            DXL_BADFLAG := 0;
            AVG_RTWP_BADFLAG := 0;
            --LL_BADFLAG  := 0;
            CSFB_CGL_BADFLAG := 0;
            TPQH_CGL_BADFLAG := 0;
            MR_BADFLAG := 0;

            --测试语句
            i := i + 1;
            --dbms_output.put_line('i: '||i);
            --dbms_output.put_line(kpi_tmp_2.ecgi||'-'||to_char(kpi_tmp_2.s_date, 'yyyymmdd')||'-'||kpi_tmp_2.s_hour);--当前时间戳对应的小区小时数据
            --dbms_output.put_line(omc3_tmp_1.ecgi||'-'||to_char(omc3_tmp_1.s_date, 'yyyymmdd')||'-'||omc3_tmp_1.s_hour);--7日前对应小区小时数据

            --开始进行小区小时级标签判断
            --某小区某小时
            if omc3_tmp_1.LTE_JTL < 90 and omc3_tmp_1.JTL_QUEST_NUM > 1000
                then JTL_BADFLAG := 1;
            end if;
            if omc3_tmp_1.LTE_DXL > 5  and omc3_tmp_1.DXL_DX_NUM > 200
                then DXL_BADFLAG := 1;
            end if;
            if omc3_tmp_1.AVG_RTWP > -95
                then AVG_RTWP_BADFLAG := 1;
            end if;
            if omc3_tmp_1.CSFB_CGL < 90 and omc3_tmp_1.CSFB_QUEST_NUM > 10
                then CSFB_CGL_BADFLAG := 1;
            end if;
            if omc3_tmp_1.TPQH_CGL < 80 and omc3_tmp_1.TPQH_QUEST_NUM > 100
                then TPQH_CGL_BADFLAG := 1;
            end if;
            if omc3_tmp_1.RSRP_110_RATE < 80 and omc3_tmp_1.RSRP_ALL_SIMPLES > 5000
                then MR_BADFLAG := 1;
            end if;

            --执行插入
            execute immediate 'insert /*+ parallel(a,4)  nologging */  into TB_LIST_CELL_HOUR a
            values(:s_date, :s_hour, :enb_id, :cell_id, :ecgi,
            :LTE_JTL, :JTL_QUEST_NUM,
            :LTE_DXL, :DXL_DX_NUM,
            :AVG_RTWP,
            :LTE_LL, :LL_QAM_ZB, :LL_GZSL,
            :CSFB_CGL, :CSFB_QUEST_NUM,
            :TPQH_CGL, :TPQH_QUEST_NUM,
            :TA,
            :n4_0001, :n4_0002, :n4_0003, :n4_0004,
            :n4_0005, :n4_0006,
            :n4_0033,
            :n4_0050, :n4_0027,
            :n4_0037, :n4_0036, :n4_0032,
            :n4_0023, :n4_0024,
            :n4_0041, :n4_0042,
            :n4_0045,
            :RSRP_110_RATE,
            :RSRP_ALL_SIMPLES,
            :JTL_BADFLAG,
            :DXL_BADFLAG,
            :AVG_RTWP_BADFLAG,
            :CSFB_CGL_BADFLAG,
            :TPQH_CGL_BADFLAG,
            :MR_BADFLAG,
            :PROVINCE, :VENDOR_CELL_ID, :COUNTY, :VENDOR_ID, :RESERVED3, :RESERVED8,
            :TOWN_ID, :RNC, :RESERVED4, :RESERVED5, :COVER_TYPE, :LIFE, :LON, :LAT)'
            using
            omc3_tmp_1.s_date, omc3_tmp_1.s_hour, omc3_tmp_1.enb_id, omc3_tmp_1.cell_id, omc3_tmp_1.ecgi,
            omc3_tmp_1.LTE_JTL, omc3_tmp_1.JTL_QUEST_NUM,
            omc3_tmp_1.LTE_DXL, omc3_tmp_1.DXL_DX_NUM,
            omc3_tmp_1.AVG_RTWP,
            omc3_tmp_1.LTE_LL, omc3_tmp_1.LL_QAM_ZB, omc3_tmp_1.LL_GZSL,
            omc3_tmp_1.CSFB_CGL, omc3_tmp_1.CSFB_QUEST_NUM,
            omc3_tmp_1.TPQH_CGL, omc3_tmp_1.TPQH_QUEST_NUM,
            omc3_tmp_1.TA,
            omc3_tmp_1.n4_0001, omc3_tmp_1.n4_0002, omc3_tmp_1.n4_0003, omc3_tmp_1.n4_0004,
            omc3_tmp_1.n4_0005, omc3_tmp_1.n4_0006,
            omc3_tmp_1.n4_0033,
            omc3_tmp_1.n4_0050, omc3_tmp_1.n4_0027,
            omc3_tmp_1.n4_0037, omc3_tmp_1.n4_0036, omc3_tmp_1.n4_0032,
            omc3_tmp_1.n4_0023, omc3_tmp_1.n4_0024,
            omc3_tmp_1.n4_0041, omc3_tmp_1.n4_0042,
            omc3_tmp_1.n4_0045,
            omc3_tmp_1.RSRP_110_RATE, omc3_tmp_1.RSRP_ALL_SIMPLES,
            JTL_BADFLAG, DXL_BADFLAG,
            AVG_RTWP_BADFLAG, CSFB_CGL_BADFLAG,
            TPQH_CGL_BADFLAG,
            MR_BADFLAG,
            omc3_tmp_1.PROVINCE, omc3_tmp_1.VENDOR_CELL_ID, omc3_tmp_1.COUNTY,
            omc3_tmp_1.VENDOR_ID, omc3_tmp_1.RESERVED3, omc3_tmp_1.RESERVED8,
            omc3_tmp_1.TOWN_ID, omc3_tmp_1.RNC, omc3_tmp_1.RESERVED4, omc3_tmp_1.RESERVED5, omc3_tmp_1.COVER_TYPE,
            omc3_tmp_1.LIFE, omc3_tmp_1.LON, omc3_tmp_1.LAT;

            if mod(i, 100)=0 --commit every 100 times
                then commit;
            end if;

            --该小区下一小时
            fetch cur_sql_1 into omc3_tmp_1;


        end loop;
        commit;

        close cur_sql_1;
        dbms_output.put_line('i: '||i);

        --DBMS_STATS.GATHER_TABLE_STATS ('LRNOP','OMC_LTE_3');
        --DBMS_STATS.GATHER_TABLE_STATS ('LRNOP','MR_LTE_MRS_CELL_3');
        --DBMS_STATS.GATHER_TABLE_STATS ('LRNOP','TB_LIST_CELL_HOUR');

        --入库数量判断
        execute immediate 'select count(1) from '||v_tbname||' partition('||v_partition_name||')' into v_insert_cnt;
        --重复率判断
        execute immediate 'select count(1) from (select count(1) from '||v_tbname||' partition('||v_partition_name||')
        group by s_date, s_hour, ecgi having count(1)>1)'into v_insert_repeat;
        dbms_output.put_line('表 '||v_tbname||' 小时数据插入完成！时间戳：'||V_DATE_THRESHOLD_START||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');

    END PROC_TB_LIST_CELL_HOUR;
/

