create PACKAGE PKG_LC_INDEX_LXN_BAD_CELL_DAY AUTHID CURRENT_USER as
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  大屏指标汇总-质差小区
  --
  --  OWNER:       Shinnosuke
  --
  --  VERSION:     2.0
  --
  --  CREATE DATE： 2019/06/12 version 1.0
  --               1.增加234G质差小区清单结果表
  --
  --  UPDATE DATE：2019/06/13 version 1.1
  --               1.修正234G质差小区清单结果表过程（标签表）
  --               2.增加234G质差小区指标结果表过程（打点表）
  --               3.增加234G质差小区指标结果汇总表过程（打点汇总表）
  --
  --  UPDATE DATE：2019/06/14 version 1.2
  --               1.修正234G质差小区指标结果表过程
  --               2.增加234G质差小区清单结果表一键调度过程（ACTIVE_ZC_CELL_LIST）
  --               3.增加234G质差小区指标结果表一键调度过程（ACTIVE_LC_INDEX_DAY）
  --               4.增加4G质差小区清单结果表过程（全量导出）
  --
  --  UPDATE DATE：2019/06/17 version 1.3
  --               1.增加234G质差小区清单结果表自动调度过程（ACTIVE_ZC_CELL_LIST_AUTO）
  --               2.增加234G质差小区指标结果表自动调度过程（ACTIVE_LC_INDEX_DAY_AUTO）
  --               3.修正4G质差小区清单结果表过程（全量导出）
  --               4.ACTIVE_LC_INDEX_DAY_AUTO 过程中增加结果表 LC_INDEX_LXN_BAD_CELL_DAY 自动清理功能
  --
  --  UPDATE DATE：2019/06/18 version 1.4
  --               1.修正234G质差小区指标自动调度过程（ACTIVE_LC_INDEX_DAY_AUTO）
  --                 --ACTIVE_LC_INDEX_DAY_AUTO 中包含 ACTIVE_ZC_CELL_LIST_AUTO 过程（指标任务包含清单任务）
  --               2.增加23G质差小区清单结果表过程（全量导出）
  --
  --  UPDATE DATE：2019/06/19 version 1.5
  --               1.增加234G质差小区指标结果表过程（全量导出）
  --               2.修正234G质差小区指标自动调度过程（ACTIVE_LC_INDEX_DAY_AUTO）
  --
  --  UPDATE DATE：2019/06/25 version 1.6
  --               1.增加234G坏小区清单结果表过程（坏小区导出）
  --               2.增加234G坏小区清单结果表自动调度过程至以下三个调度中：
  --                  ACTIVE_ZC_CELL_LIST/ ACTIVE_ZC_CELL_LIST_AUTO/ ACTIVE_LC_INDEX_DAY_AUTO
  --               3.修正4G质差小区指标结果表，增加"非L900"分项
  --               4.增加所有过程的输入输出说明
  --
  --  UPDATE DATE：2019/06/25 version 1.7
  --               1.修正34G坏小区清单结果表过程（坏小区导出，MR覆盖类指标7天字段添加）
  --
  --  UPDATE DATE：2019/07/12 version 1.8
  --               1.增加234G质差小区指标数据补充过程（雷同于一键调度）
  --               2.删除234G质差小区清单结果表自动调度过程（ACTIVE_ZC_CELL_LIST_AUTO）
  --        
  --  UPDATE DATE：2019/07/17 version 1.9
  --               1.修正3G质差小区清单/指标结果表过程 , RSRP_3G 由小于-110占比 更改至 小于-95占比
  --
  --  UPDATE DATE：2019/08/16 version 2.0
  --               1.修正234G坏小区清单结果表过程（DAYS_RANG 重复问题）
  --
  --  TODO    1.增加分区表自动清理功能（Finished）
  --               2.ACTIVE_ZC_CELL_LIST_AUTO 中的分区清理暂时由备份表 LC_INDEX_LXN_BAD_CELL_DAY_ORC_TEST代替
  --                 --待LC_INDEX_LXN_BAD_CELL_DAY 分区扩展3个月以上之后，修正为 LC_INDEX_LXN_BAD_CELL_DAY
  --                 --详见 ACTIVE_ZC_CELL_LIST_AUTO 中的 "自动清理冗余数据部分"
  --               3.评估是否新增进程相关监控信息
  --
  --
------------------------------------------------------------------------

  --全量质差清单
  PROCEDURE PROC_ZC_CELL_LIST_2G(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_ZC_CELL_LIST_3G(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_ZC_CELL_LIST_4G(V_DATE_THRESHOLD_START VARCHAR2);
  
  --质差坏小区清单
  PROCEDURE PROC_ZC_BAD_CELL_LIST_2G(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_ZC_BAD_CELL_LIST_3G(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_ZC_BAD_CELL_LIST_4G(V_DATE_THRESHOLD_START VARCHAR2);

  
  --区域质差指标
  PROCEDURE PROC_LC_INDEX_DAY_2G(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_LC_INDEX_DAY_3G(V_DATE_THRESHOLD_START VARCHAR2);
  PROCEDURE PROC_LC_INDEX_DAY_4G(V_DATE_THRESHOLD_START VARCHAR2);
  --区域质差指标汇总
  PROCEDURE PROC_LC_INDEX_DAY_234G(V_DATE_THRESHOLD_START VARCHAR2);

  --质差清单激活
  PROCEDURE ACTIVE_ZC_CELL_LIST(V_DATE_THRESHOLD_START VARCHAR2);
  --质差指标&汇总激活
  PROCEDURE ACTIVE_LC_INDEX_DAY(V_DATE_THRESHOLD_START VARCHAR2);



  --质差清单自动
  --PROCEDURE ACTIVE_ZC_CELL_LIST_AUTO;
  
  --全流程自动
  PROCEDURE ACTIVE_LC_INDEX_DAY_AUTO;
  
  --全流程补偿
  PROCEDURE ACTIVE_LC_INDEX_DAY_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);
  
  PROCEDURE PROC_TEST;



end PKG_LC_INDEX_LXN_BAD_CELL_DAY;
/

