create view TB_EXPORT_VIEW as
select A.s_date, A.ecgi, PRE_FIELD5 as CELL_NAME, COUNTY, key "指标项", regexp_substr(value, '[^/]+',1,1,'i') "是否质差", regexp_substr(value, '[^/]+',1,2,'i') "是否突变", KPI_9 as "KPI_9", KPI_10, KPI_11, KPI_12, KPI_13, KPI_14, KPI_15, KPI_16, KPI_17, KPI_18, KPI_19, KPI_20, KPI_21, KPI_22, KPI_23/*,C.ex*/
,zc_style, tb_style
from
(
    select s_date, ecgi, key, value from
    (
        select s_date, ecgi,
        decode(jtl_badflag,1,'是','否')||':'|| jtl_badflag_source ||'/'|| decode(jtl_tbflag,1,'是','否') ||':'|| jtl_tbflag_source "4G接通率",
        decode(dxl_badflag,1,'是','否')||':'|| dxl_badflag_source ||'/'|| decode(dxl_tbflag,1,'是','否') ||':'|| dxl_tbflag_source "4G掉线率",
        decode(avg_rtwp_badflag,1,'是','否')||':'|| avg_rtwp_badflag_source ||'/'|| decode(avg_rtwp_tbflag,1,'是','否') ||':'|| avg_rtwp_tbflag_source "4G高干扰",
        ' '||'/'|| decode(ll_tbflag,1,'是','否')||':'|| ll_tbflag_source "4G上下行总流量",
        decode(csfb_cgl_badflag,1,'是','否')||':'|| csfb_cgl_badflag_source ||'/'|| decode(csfb_cgl_tbflag,1,'是','否') ||':'|| csfb_cgl_tbflag_source "CSFB成功率",
        decode(tpqh_cgl_badflag,1,'是','否')||':'|| tpqh_cgl_badflag_source ||'/'|| decode(tpqh_cgl_tbflag,1,'是','否') ||':'|| tpqh_cgl_tbflag_source "4G同频切换",
        ' '||'/'|| decode(ta_tbflag,1,'是','否')||':'|| ta_tbflag_source "4GTA覆盖距离",
        decode(mr_badflag,1,'是','否')||':'|| mr_badflag_source ||'/'|| decode(mr_tbflag,1,'是','否') ||':'|| mr_tbflag_source "4GMR弱覆盖"
        from TB_INDEX_CELL_DAY where s_date >= trunc(sysdate-60, 'mm')  --and ecgi = 8806412
    ) t1 unpivot
    (
      VALUE for KEY in ("4G接通率", "4G掉线率", "4G高干扰", "4G上下行总流量", "CSFB成功率", "4G同频切换", "4GTA覆盖距离", "4GMR弱覆盖"/*,
      JTL_BADFLAG_SOURCE, DXL_BADFLAG_SOURCE, AVG_RTWP_BADFLAG_SOURCE, CSFB_CGL_BADFLAG_SOURCE,
      TPQH_CGL_BADFLAG_SOURCE, MR_BADFLAG_SOURCE, JTL_TBFLAG_SOURCE, DXL_TBFLAG_SOURCE, AVG_RTWP_TBFLAG_SOURCE,
      LL_TBFLAG_SOURCE, CSFB_CGL_TBFLAG_SOURCE, TPQH_CGL_TBFLAG_SOURCE, TA_TBFLAG_SOURCE, MR_TBFLAG_SOURCE*/)
    )
)A
left join
(
    select s_date, ecgi, style, KPI_9, KPI_10, KPI_11, KPI_12, KPI_13, KPI_14, KPI_15, KPI_16, KPI_17, KPI_18, KPI_19, KPI_20, KPI_21, KPI_22, KPI_23, /*PROVINCE, VENDOR_CELL_ID,*/ COUNTY,
    /*VENDOR_ID, RESERVED3, RESERVED8, TOWN_ID, RNC, RESERVED4, RESERVED5, COVER_TYPE, PRE_FIELD4,*/ PRE_FIELD5,/*, LIFE, LON, LAT*/
    case when (style = '4G上下行总流量' or style = '4GTA覆盖距离') then '' else '质差-'||style end as zc_style,
    '突变-'||style tb_style
    from TB_EXPORT
    where s_date >= trunc(sysdate-60, 'mm') --and ecgi = 8806412
)B
on A.s_date = B.s_date and A.ecgi = B.ecgi and A.key = B.style
/

comment on table TB_EXPORT_VIEW is '4G质差突变趋势表'
/

comment on column TB_EXPORT_VIEW.S_DATE is '日期'
/

comment on column TB_EXPORT_VIEW.ECGI is 'ECGI'
/

comment on column TB_EXPORT_VIEW.CELL_NAME is '小区中文名'
/

comment on column TB_EXPORT_VIEW.COUNTY is '优化分区'
/

comment on column TB_EXPORT_VIEW."指标项" is '指标项'
/

comment on column TB_EXPORT_VIEW."是否质差" is '质差标签（粒度：天+小区）是:3<连续3日> / 是:6<累计6日> / 是:3-6 / 否:0'
/

comment on column TB_EXPORT_VIEW."是否突变" is '突变标签（粒度：天+小区）是:3<连续3日> / 是:6<累计6日> / 是:3-6 / 否:0'
/

comment on column TB_EXPORT_VIEW.KPI_9 is '9点(上周\本周)，"~"表示单指标含两组判定内容，如：4G掉线率~4G掉线次数'
/

comment on column TB_EXPORT_VIEW.KPI_10 is '10点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_11 is '11点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_12 is '12点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_13 is '13点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_14 is '14点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_15 is '15点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_16 is '16点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_17 is '17点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_18 is '18点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_19 is '19点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_20 is '20点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_21 is '21点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_22 is '22点(上周\本周)，"~"表示单指标含两组判定内容'
/

comment on column TB_EXPORT_VIEW.KPI_23 is '23点(上周\本周)，"~"表示单指标含两组判定内容'
/

