create view CSV_CHECKRESULT_HOUR as
select decode(s_date, null, trunc(sysdate-1), s_date) as s_date,
decode(pathname,
'/oradata/LTE/MOBILE/HUAWEI/OMC1/PM/','HW_4G_PM<OMC1>',
'/oradata/LTE/MOBILE/HUAWEI/OMC2/PM/','HW_4G_PM<OMC2>',
'/oradata/LTE/MOBILE/NOKIA/OMC1/PM/','NSN_4G_PM',
'/LTE/MOBILE/HUAWEI/OMC1/CM/','HW_4G_CM<OMC1>',
'/LTE/MOBILE/HUAWEI/OMC2/CM/','HW_4G_CM<OMC2>',
'/LTE/MOBILE/NOKIA/OMC1/CM/','NSN_4G_CM'
) "data_style<file_path>",
file_hour "HOUR",
decode(to_number(file_hour)-1, '-1', 23, to_number(file_hour)-1) "包内数据时间",
file_num "NORMAL",
A_file_num "NOW_NUM",
B_file_num "BEF_NUM",
file_size "NORMAL_FILE_SIZE/MB",
A_file_size "NOW_SIZE/MB", B_file_size "BEF_SIZE/MB",
(A_file_num - B_file_num) as "FILE_NUM<今-昨>",
(A_file_size - B_file_size) as "FILE_SIZE<今-昨>/MB",
case when A_file_num - B_file_num> 0 then '文件增多'
  when A_file_num - B_file_num< 0 then '文件减少' else '数量未变' end as file_num_status,
case when abs(A_file_size - B_file_size)>= 500
         then '大小波动严重'
       when abs(A_file_size - B_file_size) >= 200 and abs(A_file_size - B_file_size)< 500
         then '大小波动较大'
       else '大小波动小' end as file_size_status,
pathname
from
(
    select
    C.pathname, C.file_hour, C.file_num, C.file_size,
    A.s_date, /*A.pathname, A.file_hour,*/ decode(A.file_num,null,0,A.file_num) A_file_num, decode(A.file_size,null,0,A.file_size) A_file_size,
    /*B.pathname, B.file_hour,*/ decode(B.file_num,null,0,B.file_num) B_file_num, decode(B.file_size,null,0,B.file_size) B_file_size from
    (
        select s_date, pathname, file_hour, count(1) file_num, sum(file_size) file_size from
        (
          select
          t.s_date, t.pathname, /*t.file_date,*/ round(t.file_size/1024/1024,2) file_size, t.file_name,
          substr(regexp_substr(t.file_name,'[^_]+',1,9,'i'),9,2) as file_hour
          from
          (
             select * from CHECK_RESULT_2G4G partition(P_20191025)--取本月正常日为标准值
          )t
          where (pathname like '%PM%' or pathname like '%CM%')
        )--1天前数据
        group by s_date, pathname, file_hour
        --order by pathname, file_hour
    )C
    left join
    (
        select s_date, pathname, file_hour, count(1) file_num, sum(file_size) file_size from
        (
          select
          t.s_date, t.pathname, /*t.file_date,*/ round(t.file_size/1024/1024,2) file_size, t.file_name,
          substr(regexp_substr(t.file_name,'[^_]+',1,9,'i'),9,2) as file_hour
          from
          (
             select * from CHECK_RESULT_2G4G where s_date = trunc(sysdate-1)--partition(P_20190901)
          )t
          where (pathname like '%PM%' or pathname like '%CM%')
        )--1天前数据
        group by s_date, pathname, file_hour
        --order by pathname, file_hour
    )A
    on C.pathname = A.pathname and C.file_hour = A.file_hour
    left join
    (
        select s_date, pathname, file_hour, decode(count(1),null,0,count(1)) file_num, decode(sum(file_size),null,0,sum(file_size)) file_size from
        (
          select
          t.s_date, t.pathname, /*t.file_date,*/ round(t.file_size/1024/1024,2) file_size, t.file_name,
          substr(regexp_substr(t.file_name,'[^_]+',1,9,'i'),9,2) as file_hour
          from
          (
             select * from CHECK_RESULT_2G4G where s_date = trunc(sysdate-2)--partition(P_20190901)
          )t
          where (pathname like '%PM%' or pathname like '%CM%')
        )--2天前数据
        group by s_date, pathname, file_hour
        order by pathname, file_hour
    )B
    on C.pathname = B.pathname and C.file_hour = B.file_hour
)
order by pathname, file_hour
/

