create view PM_CM_23G_DAY as
select
T1.start_time as s_date,
T1.cnt as "3G PM HW",
T2.cnt as "3G PM NSN",
/*T3.cnt as "2G PM HW",
T4.cnt as "2G PM NSN",*/
T3.cnt as "2G PM"
from
(
    select t1.start_time,/* t2.factory,*/ count(1) cnt from
    (
      select distinct start_time, lac_ci from
      (select start_time, lac||'-'||ci lac_ci from perf_cell_w_3@wrnop_44  where start_time >= sysdate-1)
      --group by start_time, lac_ci
    )t1
    left join
    (
    select lac||'-'||ci lac_ci, dt.factory from dt_cell_w dt
    )t2
    on t1.lac_ci = t2.lac_ci
    where factory ='华为'
    group by t1.start_time, t2.factory
    /*having count(1) <20000*/
    --order by factory,start_time desc
)T1--3G PM NSN
LEFT JOIN
-- 3G HW PM 小区 小时
(
    select t1.start_time, /*t2.factory,*/ count(1) cnt from
    (
      select distinct start_time, lac_ci from
      (select start_time, lac||'-'||ci lac_ci from perf_cell_w_3@wrnop_44  where start_time >= sysdate-1)
      --group by start_time, lac_ci
    )t1
    left join
    (
    select lac||'-'||ci lac_ci, dt.factory from dt_cell_w dt
    )t2
    on t1.lac_ci = t2.lac_ci
    where factory ='诺基亚'
    group by t1.start_time, t2.factory
    --having count(1) <40000
    --order by factory,start_time desc
)T2--3G PM HW
on T1.start_time = T2.start_time

/*left join
(
select start_time, \*vendor_id,*\ count(1) cnt from perf_cell_g_3@grnop_38 where start_time>=sysdate -1
\*(
   select start_time from perf_cell_g_3@grnop_38 where start_time >=sysdate -1 group by start_time --having count(1)<20000
)*\
and vendor_id = '1'
group by start_time, vendor_id
)T3-- 2G PM HW
on T1.start_time = T3.start_time
left join
(
select start_time, \*vendor_id, *\count(1) cnt from perf_cell_g_3@grnop_38 where start_time in
(
   select start_time from perf_cell_g_3@grnop_38 where start_time >=sysdate -1 group by start_time --having count(1)<20000
)
and vendor_id = '7'
group by start_time, vendor_id
)T4-- 2G PM NSN
on T1.start_time = T4.start_time*/

left join
(
    select start_time, count(1) cnt from perf_cell_g_3@grnop_38 where start_time >=sysdate -1 group by start_time --having count(1)<20000
)T3-- 2G PM HW&NSN
on T1.start_time = T3.start_time
order by s_date desc
/

