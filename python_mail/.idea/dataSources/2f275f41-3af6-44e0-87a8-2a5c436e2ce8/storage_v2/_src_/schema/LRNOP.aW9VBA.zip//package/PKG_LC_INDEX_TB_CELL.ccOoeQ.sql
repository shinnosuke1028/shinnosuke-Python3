create PACKAGE PKG_LC_INDEX_TB_CELL AUTHID CURRENT_USER AS
------------------------------------------------------------------------
    --  OVERVIEW
    --
    --  ZYJ-突变&质差小区流程包
    --
    --  OWNER:       Shinnosuke
    --
    --  VERSION:     2.1
    --
    --  CREATE DATE：2019/10/12 version 1.0
    --               1.增加4GTB小区小时级质差清单过程（含计算字段，用于后续质差计算）PROC_TB_LIST_CELL_HOUR
    --
    --  UPDATE DATE：2019/10/14 version 1.2
    --               1.增加4GTB小区小时级质差突变清单过程（不含基本字段，含分子分母）PROC_TB_LIST_CELL_HOUR_TBZC
    --               2.增加4GTB小区天级质差&突变指标结果表过程（仅含标签） PROC_TB_INDEX_CELL_DAY
    --               3.增加4GTB小区导出表所需中间表过程（中间表，用于最后的导出表） PROC_TB_LIST_CELL_HOUR_FORMAT
    --               4.增加4GTB小区导出表最终表过程（每行：小区单指标；列：多小时） PROC_TB_LIST_CELL_HOUR_FORMAT2
    --
    --  UPDATE DATE：2019/10/15 version 1.3
    --               1.修正4GTB小区天级质差&突变指标结果表过程
    --               2.修正4GTB小区导出表所需中间表过程
    --               3.修正4GTB小区导出表最终表过程
    --
    --  UPDATE DATE：2019/10/15 version 1.4
    --               1.增加4GTB小区清单指标自动化流转过程
    --               2.增加4GTB小区小时级质差清单过程小时触发模式（入口参数不填小时时，默认处理全天忙时数据）
    --
    --  UPDATE DATE：2019/10/23 version 1.5
    --               1.修正4GTB小区小时级质差清单过程小时触发模式（入口参数不填小时时，默认处理全天忙时数据）
    --               2.修正4GTB小区导出表最终表过程（PROC_TB_LIST_CELL_HOUR_FORMAT2 的小时入口默认参数修正至23）
    --
    --  UPDATE DATE：2019/10/24 version 1.6
    --               1.修正PROC_TB_INDEX_CELL_DAY（判定过程中切换小区时，遗漏终极标签和终极标签来源的初始化 & 修正循环标签）
    --
    --  UPDATE DATE：2019/10/25 version 1.7
    --               1.修正PROC_TB_LIST_CELL_HOUR_FORMAT2（底层数据按时间段区分<9~13, 14~18, 19~23>，并进行行转列操作，进一步区数据错列时，底层数据缺失的时间段）
    --               1.修正PROC_TB_LIST_CELL_HOUR_FORMAT2（底层数据按时间段区分<9~16, 17~23>，分段太多，关联耗时过大）
    --
    --  UPDATE DATE：2019/10/29 version 1.8
    --               1.底层过程 Bulk Collect 优化，优先 PROC_TB_LIST_CELL_HOUR_FORMAT2
    --
    --  UPDATE DATE：2019/10/29 version 1.9
    --               1.新增页面问题小区统计结果过程（分区统计结果）PROC_TB_OSS_DAY
    --               2.修正页面问题小区统计结果过程（修正分区清理部分，区分制式）
    --
    --  UPDATE DATE：2019/10/31 version 2.0
    --               1.新增全流程数据补偿过程（仅需指定天级时间即可补全单日全量数据，也可用于单日临时补充） ACTIVE_LC_ZCTB_SUPPLEMENT
    --
    --  UPDATE DATE：2019/11/15 version 2.1
    --               1.修正全流程数据补偿过程（区分当日数据正常处理和历史数据补充，避免冲突）
    --
    --  TODO    1.增加VOLTE区域指标结果表周期性汇聚任务自动激活 ACTIVE_LC_INDEX_VOLTE_3_AUTO（小时级自动调度任务 天级入口时间戳修正）    --  TODO    1.增加分区表自动清理功能（Finished）
    --               2.PROC_LC_INDEX_VOLTE_9 中的OMC_LTE_8表暂无分区，后续需优化并进行脚本替换
    --               3.OMC_LTE_3已有系统自增分区（格式较差）/PMC_LTE_8/9/A均为无分区生产表，待更新
    --               4.评估是否新增进程相关监控信息
    --
    --
------------------------------------------------------------------------

    --LTE
    --TB小区小时级质差清单过程 
    --in：OMC_LTE_3 / MR_LTE_MRS_CELL_3 / DT_CELL_L
    --out：TB_LIST_CELL_HOUR
    PROCEDURE PROC_TB_LIST_CELL_HOUR(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := NULL);

    -- --TB小区小时级质差&突变清单过程（不含基本字段，含分子分母）
    --in：TB_LIST_CELL_HOUR
    --out：TB_LIST_CELL_HOUR_TBZC    
    PROCEDURE PROC_TB_LIST_CELL_HOUR_TBZC(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := NULL);

    --TB小区天级质差&突变指标结果表过程（仅含标签）
    --in：TB_LIST_CELL_HOUR_TBZC
    --out：TB_INDEX_CELL_DAY    
    PROCEDURE PROC_TB_INDEX_CELL_DAY(V_DATE_THRESHOLD_START VARCHAR2);

    --TB小区天级区域数量统计
    --in：TB_INDEX_CELL_DAY / DT_CELL_L
    --out：OSS_CELL_DAY
    PROCEDURE PROC_TB_OSS_DAY(V_DATE_THRESHOLD_START VARCHAR2);

    --TB小区导出表所需中间表过程（中间表）
    --in：TB_LIST_CELL_HOUR_TBZC
    --out：TB_EXPORT_TMP
    PROCEDURE PROC_TB_LIST_CELL_HOUR_FORMAT(V_DATE_THRESHOLD_START VARCHAR2);
    
    --TB小区导出表最终表过程
    --in：TB_EXPORT_TMP / DT_CELL_L
    --out：TB_EXPORT
    --计算全天，可以将入口参数2设置为：23
    PROCEDURE PROC_TB_LIST_CELL_HOUR_FORMAT2(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := '23');
    
    --TB小区数据补采专用过程（仅替换最后两步）
    PROCEDURE PROC_TB_FORMAT_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);
    PROCEDURE PROC_TB_FORMAT2_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2 := '23');

    -- --TB小区小时级清单&天级标签周期性汇聚任务自动激活（运行粒度：小时）
    PROCEDURE ACTIVE_LC_ZCTB_AUTO;
    
    -- --TB小区小时级清单&天级标签周期性汇聚补偿任务（全流程，只需传递天级标签，按天补数据）
    PROCEDURE ACTIVE_LC_ZCTB_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);
  
    --客户端视图呈现
    --TB_EXPORT_VIEW
    --in：TB_EXPORT / TB_INDEX_CELL_DAY
    --out：TB_EXPORT_VIEW

    PROCEDURE PROC_TEST;
    


END PKG_LC_INDEX_TB_CELL;
/

