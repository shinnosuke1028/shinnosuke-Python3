create PACKAGE BODY PKG_LC_INDEX_LXN_BAD_CELL_DAY  AS
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：PERF_CELL_G_3@GRNOP_38 /DT_CELL_G@GRNOP_38/ 
  --out：ZC_CELL_LIST_2G
  PROCEDURE PROC_ZC_CELL_LIST_2G(V_DATE_THRESHOLD_START VARCHAR2) IS
    v_date_start  date;
    v_date_end   date;
    --v_loop_log number := 0 ;
    v_insert_cnt   number;
    v_insert_repeat   number;
    v_partition_name varchar2(30);
    v_ssql varchar2(500);
    v_clean_flag number;
    --v_proc_end_flag number :=0;


    BEGIN
        --起止时间戳格式化
        --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
        select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
        --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
        select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
        
        --从系统中获取待插入分区名
        select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
        where t.table_name = 'ZC_CELL_LIST_2G' 
        and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
        and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
        --或拼接待插入分区名
        --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
        
        --PLUS7暂未部署
        --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_CELL_LIST_2G',v_date_start,v_date_start,'0','0');
        
        --分区数据清理
        /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
        execute immediate v_ssql;*/

        select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
        while v_clean_flag !=0 loop
        /*select 'DELETE FROM ZC_CELL_LIST_2G PARTITION(' || v_partition_name||')' into v_ssql from dual;
        execute immediate v_ssql;*/
        select
        'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
        into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
        where s.table_name = 'ZC_CELL_LIST_2G';
        execute immediate v_ssql;
        select count(1) into v_clean_flag from ZC_CELL_LIST_2G where s_date >= v_date_start and s_date < v_date_end;
        end loop;
        
        /*execute immediate 'DELETE FROM ZC_CELL_LIST_2G PARTITION(' || v_partition_name||')';
        commit;*/
        
        /*while v_date_start< to_date(20190613,'yyyymmdd') and v_loop_log<=2 loop
          v_loop_log := v_loop_log + 1; 
        end loop;*/
        insert into ZC_CELL_LIST_2G
        select
        s_date, s_hour, oid, JTL_2G, DXL_2G,
        case when JTL_2G <95 then 1 else 0 end as JTL_BADFLAG_2G,--"JTL_2G<95"
        case when DXL_2G>2 then 1 else 0 end as DXL_BADFLAG_2G,--"DXL_2G>2"
        PROVINCE,--上海
        CITY ,--行政区
        COUNTRY,--优化分区
        FACTORY ,--厂家
        GRID ,--单元格
        COMPANY ,--区县分公司
        LOOP_LINE ,--环线
        --RNC, --RNC
        PRE_FIELD1 ,--聚焦区域
        --RESERVED5,--频段（频点）
        PRE_FIELD3 ,--基站类型
        LIFE,--报维护,
        PRE_FIELD4,
        PRE_FIELD5,
        F0014, F0018, F0026, F0108, F0120
        from
        (
          select
          s_date, s_hour, oid,
          100*decode(F0018*F0014, 0,null,null,null,round((F0120*F0108)/(F0018*F0014),4)) as JTL_2G,--"JTL_2G<95"
          100*decode(F0120,0,null,null,null,round(F0026/F0120,4)) as DXL_2G,--"DXL_2G>2"
          PROVINCE,--上海
          CITY ,--行政区
          COUNTRY,--优化分区
          FACTORY ,--厂家
          GRID ,--单元格
          COMPANY ,--区县分公司
          LOOP_LINE ,--环线
          --RNC, --RNC
          PRE_FIELD1 ,--聚焦区域
          --RESERVED5,--频段（频点）
          PRE_FIELD3 ,--基站类型
          LIFE,--报维护
          PRE_FIELD4,
          PRE_FIELD5,
          F0014, F0018, F0026, F0108, F0120
          from
          (
            select
            s_date, s_hour, A.oid,
            F0005,--排序字段
            row_number() over(partition by s_date, A.oid order by F0005 desc ) as seq,
            PROVINCE,--上海
            CITY ,--行政区
            COUNTRY,--优化分区
            FACTORY ,--厂家
            GRID ,--单元格
            COMPANY ,--区县分公司
            LOOP_LINE ,--环线
            --RNC, --RNC
            PRE_FIELD1 ,--聚焦区域
            --RESERVED5,--频段（频点）
            PRE_FIELD3 ,--基站类型
            B.LIFE,--报维护
            PRE_FIELD4,
            PRE_FIELD5,
            F0014, F0018, F0026, F0108, F0120
            from
            (
                select trunc(start_time, 'dd') s_date, t.* from PERF_CELL_G_3@GRNOP_38 t
                where start_time >= v_date_start--to_date('20190611 00:00:00' ,'yyyymmdd hh24:mi:ss')
                and start_time < v_date_end--to_date('20190612 00:00:00' ,'yyyymmdd hh24:mi:ss')
                --and t.oid= '2188_49672'--测试用LIMIT取样
            )A--数据信息
            left join(
            select * from DT_CELL_G@GRNOP_38 dt
            )B--区域信息
            on A.oid = B.oid
            where B.life like  '%报维护%'
          )
          where seq =1--自忙时指标
          and s_date is not null
        )--2G忙时指标
        ;
        commit;
        select count(1) into v_insert_cnt from ZC_CELL_LIST_2G t where t.s_date >= v_date_start and t.s_date< v_date_end;
        
        select count(1) into v_insert_repeat from
        (
               select count(1) from ZC_CELL_LIST_2G t where t.s_date >= v_date_start and s_date< v_date_end group by t.oid having count(1)>1
        );
        dbms_output.put_line('表 ZC_CELL_LIST_2G 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
        ');
        
        --v_proc_end_flag :=1;
        
        /*if v_proc_end_flag = 1 then 
             RAISE_APPLICATION_ERROR(-20124, '表 ZC_CELL_LIST_2G 数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，重复数据行数：'||v_insert_repeat||'行.', FALSE);
             --RAISE_APPLICATION_ERROR(-20124, '表'||i_owner||'.'||i_tablename||' 不存在', TRUE);
        end if;*/

  END PROC_ZC_CELL_LIST_2G;
    
    
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：OMC_UMTS_3 /DT_CELL_W /OMC_UMTS_8 /MR_STAT_CELL_8@WRNOP_44 /
  --out：ZC_CELL_LIST_3G
  PROCEDURE PROC_ZC_CELL_LIST_3G(V_DATE_THRESHOLD_START VARCHAR2) IS
     v_date_start  date;
     v_date_end   date;
     --v_loop_log number := 0 ;
     v_insert_cnt   number;
     v_insert_repeat   number;
     v_partition_name varchar2(30);
     v_ssql varchar2(500);
     v_clean_flag number;
     --v_proc_end_flag number :=0;


     BEGIN
          --起止时间戳格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          
          --从系统中获取待插入分区名
          select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
          where t.table_name = 'ZC_CELL_LIST_3G' 
          and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
          and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
          --或拼接待插入分区名
          --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.('LRNOP','ZC_CELL_LIST_3G',v_date_start,v_date_start,'0','0');
          
          --分区数据清理
          /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
          execute immediate v_ssql;*/

          select count(1) into v_clean_flag from ZC_CELL_LIST_3G where s_date >= v_date_start and s_date < v_date_end;
          while v_clean_flag !=0 loop
            
          select
          'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
          into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
          where s.table_name = 'ZC_CELL_LIST_3G';
          execute immediate v_ssql;
          
          /*select 'DELETE FROM ZC_CELL_LIST_3G PARTITION(' || v_partition_name||')' into v_ssql from dual;
          execute immediate v_ssql;*/
          select count(1) into v_clean_flag from ZC_CELL_LIST_3G where s_date >= v_date_start and s_date < v_date_end;
          end loop;

          INSERT INTO ZC_CELL_LIST_3G
          --select s_date, count(1) from( 
          SELECT 
          T1.S_DATE, T1.S_HOUR, T1.LAC_ID, T2.CELL_ID, T2.LAC_CI,
          T1.TPQH_3G,
          T1.CJL_3G,
          T2.RTWP_3G,--天表内的N3_0014，非忙时字段

          T3.RSRP_3G,
          T3.ECIO_3G,

          T1.JTL_3G,
          T1.DXL_3G,

          CASE WHEN TPQH_3G<98 then 1 else 0 end as TPQH_BADFLAG_3G,--"TPQH_3G<98",
          CASE WHEN CJL_3G>5 then 1 else 0 end as CJL_BADFLAG_3G,--"CJL_3G>5",
          CASE WHEN RTWP_3G>-95 then 1 else 0 end as RTWP_BADFLAG_3G,--"RTWP>-95"--上行干扰均值--N3_0014
          CASE WHEN RSRP_3G>30 then 1 else 0 end as RSRP_BADFLAG_3G,--"RSRP_3G>30"
          CASE WHEN ECIO_3G>30 then 1 else 0 end as ECIO_BADFLAG_3G,--"ECIO_3G>30"--ECIO<-12db比例大于30%小区占比

          CASE WHEN JTL_3G<95 then 1 else 0 end  as JTL_BADFLAG_3G,--"JTL_3G<95"
          CASE WHEN DXL_3G>2 then 1 else 0 end  as DXL_BADFLAG_3G,--"DXL_3G>2"
          T1.PROVINCE,--上海
          T1.CITY ,--行政区
          T1.COUNTRY,--优化分区
          T1.FACTORY ,--厂家
          T1.GRID ,--单元格 
          T1.COMPANY ,--区县分公司
          T1.LOOP_LINE ,--环线
          T1.RNC, --RNC
          T1.PRE_FIELD1 ,--聚焦区域 
          --RESERVED5,--频段（频点）
          T1.PRE_FIELD2 ,--基站类型 
          T1.LIFE,--报维护
          --OMC字段
          --T2.N3_0014 as N3_0014_D,--N3_0014保留天级字段，方便后续区域级汇聚使用，其实RTWP_3G = N3_0014！！！
          --其余OMC字段均为忙时级 
          N3_0001, N3_0002, N3_0003, N3_0004, N3_0005, N3_0006, N3_0007, 
          N3_0008, N3_0009, N3_0010, N3_0011, N3_0012, N3_0013, --T2.N3_0014
          N3_0015, N3_0016, N3_0017, N3_0018, N3_0019, N3_0020,

          --MR字段
          MR_COUNT_ECNO_0,MR_COUNT_ECNO_1,MR_COUNT_ECNO_2,MR_COUNT_ECNO_3,MR_COUNT_ECNO_4,MR_COUNT_ECNO_5,
          MR_COUNT_ECNO_6,MR_COUNT_ECNO_7,MR_COUNT_ECNO_8,MR_COUNT_ECNO_9,MR_COUNT_ECNO_10,MR_COUNT_ECNO_11,
          MR_COUNT_ECNO_12,MR_COUNT_ECNO_13,MR_COUNT_ECNO_14,MR_COUNT_ECNO_15,MR_COUNT_ECNO_16,MR_COUNT_ECNO_17,
          MR_COUNT_ECNO_18,MR_COUNT_ECNO_19,MR_COUNT_ECNO_20,MR_COUNT_ECNO_21,MR_COUNT_ECNO_22,MR_COUNT_ECNO_23,
          MR_COUNT_ECNO_24,MR_COUNT_ECNO_25,MR_COUNT_ECNO_26,MR_COUNT_ECNO_27,MR_COUNT_ECNO_28,MR_COUNT_ECNO_29,
          MR_COUNT_ECNO_30,MR_COUNT_ECNO_31,MR_COUNT_ECNO_32,MR_COUNT_ECNO_33,MR_COUNT_ECNO_34,MR_COUNT_ECNO_35,
          MR_COUNT_ECNO_36,MR_COUNT_ECNO_37,MR_COUNT_ECNO_38,MR_COUNT_ECNO_39,MR_COUNT_ECNO_40,MR_COUNT_ECNO_41,
          MR_COUNT_ECNO_42,MR_COUNT_ECNO_43,MR_COUNT_ECNO_44,MR_COUNT_ECNO_45,MR_COUNT_ECNO_46,MR_COUNT_ECNO_47,
          MR_COUNT_ECNO_48,MR_COUNT_ECNO_49,

          MR_COUNT_RSCP_N5,MR_COUNT_RSCP_N4,MR_COUNT_RSCP_N3,MR_COUNT_RSCP_N2,MR_COUNT_RSCP_N1,
          MR_COUNT_RSCP_0,MR_COUNT_RSCP_1,MR_COUNT_RSCP_2,MR_COUNT_RSCP_3,MR_COUNT_RSCP_4,MR_COUNT_RSCP_5,
          MR_COUNT_RSCP_6,MR_COUNT_RSCP_7,MR_COUNT_RSCP_8,MR_COUNT_RSCP_9,MR_COUNT_RSCP_10,MR_COUNT_RSCP_11,
          MR_COUNT_RSCP_12,MR_COUNT_RSCP_13,MR_COUNT_RSCP_14,MR_COUNT_RSCP_15,MR_COUNT_RSCP_16,MR_COUNT_RSCP_17,
          MR_COUNT_RSCP_18,MR_COUNT_RSCP_19,MR_COUNT_RSCP_20,MR_COUNT_RSCP_21,MR_COUNT_RSCP_22,MR_COUNT_RSCP_23,
          MR_COUNT_RSCP_24,MR_COUNT_RSCP_25,MR_COUNT_RSCP_26,MR_COUNT_RSCP_27,MR_COUNT_RSCP_28,MR_COUNT_RSCP_29,
          MR_COUNT_RSCP_30,MR_COUNT_RSCP_31,MR_COUNT_RSCP_32,MR_COUNT_RSCP_33,MR_COUNT_RSCP_34,MR_COUNT_RSCP_35,
          MR_COUNT_RSCP_36,MR_COUNT_RSCP_37,MR_COUNT_RSCP_38,MR_COUNT_RSCP_39,MR_COUNT_RSCP_40,MR_COUNT_RSCP_41,
          MR_COUNT_RSCP_42,MR_COUNT_RSCP_43,MR_COUNT_RSCP_44,MR_COUNT_RSCP_45,MR_COUNT_RSCP_46,MR_COUNT_RSCP_47,
          MR_COUNT_RSCP_48,MR_COUNT_RSCP_49,MR_COUNT_RSCP_50,MR_COUNT_RSCP_51,MR_COUNT_RSCP_52,MR_COUNT_RSCP_53,
          MR_COUNT_RSCP_54,MR_COUNT_RSCP_55,MR_COUNT_RSCP_56,MR_COUNT_RSCP_57,MR_COUNT_RSCP_58,MR_COUNT_RSCP_59,
          MR_COUNT_RSCP_60,MR_COUNT_RSCP_61,MR_COUNT_RSCP_62,MR_COUNT_RSCP_63,MR_COUNT_RSCP_64,MR_COUNT_RSCP_65,
          MR_COUNT_RSCP_66,MR_COUNT_RSCP_67,MR_COUNT_RSCP_68,MR_COUNT_RSCP_69,MR_COUNT_RSCP_70,MR_COUNT_RSCP_71,
          MR_COUNT_RSCP_72,MR_COUNT_RSCP_73,MR_COUNT_RSCP_74,MR_COUNT_RSCP_75,MR_COUNT_RSCP_76,MR_COUNT_RSCP_77,
          MR_COUNT_RSCP_78,MR_COUNT_RSCP_79,MR_COUNT_RSCP_80,MR_COUNT_RSCP_81,MR_COUNT_RSCP_82,MR_COUNT_RSCP_83,
          MR_COUNT_RSCP_84,MR_COUNT_RSCP_85,MR_COUNT_RSCP_86,MR_COUNT_RSCP_87,MR_COUNT_RSCP_88,MR_COUNT_RSCP_89,
          MR_COUNT_RSCP_90,MR_COUNT_RSCP_91
          FROM
          --select count(distinct RNC) from
          (
            select 
            s_date, s_hour, lac_id, cell_id, lac_ci,
            100*decode(n3_0016,0,null,null,null,round(n3_0015/n3_0016,4)) as TPQH_3G,--"TPQH_3G<98",
            100*decode(n3_0008,0,null,null,null,round(n3_0007/n3_0008,4)) as CJL_3G,--"CJL_3G>5",
            100*decode(n3_0002*n3_0004,0,null,null,null,round(n3_0001*n3_0003/(n3_0002*n3_0004),4)) as JTL_3G,--"JTL_3G<95"
            100*decode(n3_0006,0,null,null,null,round(n3_0005/n3_0006,4)) as DXL_3G,--"DXL_3G>2"
            N3_0001, N3_0002, N3_0003, N3_0004, N3_0005, N3_0006, N3_0007, 
            N3_0008, N3_0009, N3_0010, N3_0011, N3_0012, N3_0013, --N3_0014, --去除天级该字段
            N3_0015, N3_0016, N3_0017, N3_0018, N3_0019, N3_0020,
            PROVINCE,--上海
            CITY ,--行政区
            COUNTRY,--优化分区
            FACTORY ,--厂家
            GRID ,--单元格 
            COMPANY ,--区县分公司
            LOOP_LINE ,--环线
            RNC, --RNC
            PRE_FIELD1 ,--聚焦区域 
            --RESERVED5,--频段（频点）
            PRE_FIELD2 ,--基站类型 
            LIFE--报维护
            --select count(distinct RNC)-- from
            from
            (
              select 
              s_date, s_hour, lac_id, cell_id, A.lac_ci,
              n3_0019,--排序字段
              row_number() over(partition by s_date,A.lac_ci order by n3_0019 desc ) as seq, 
              n3_0001, n3_0002, n3_0003, n3_0004, n3_0005, n3_0006, n3_0007, 
              n3_0008, n3_0009, n3_0010, n3_0011, n3_0012, n3_0013, --n3_0014, 
              n3_0015, n3_0016, n3_0017, n3_0018,  n3_0020,
              PROVINCE,--上海
              CITY ,--行政区
              COUNTRY,--优化分区
              FACTORY ,--厂家
              GRID ,--单元格 
              COMPANY ,--区县分公司
              LOOP_LINE ,--环线
              RNC, --RNC
              PRE_FIELD1 ,--聚焦区域 
              --RESERVED5,--频段（频点）
              PRE_FIELD2 ,--基站类型 
              B.LIFE--报维护
              from
              (
                select lac_id||'-'||cell_id  lac_ci_new, omc.* 
                from OMC_UMTS_3 omc
                where s_date >= v_date_start and s_date < v_date_end--to_date('20190611','yyyymmdd')
                --and lac_id =43009 and cell_id between 10291 and 10421--测试用LIMIT取样
              )A--数据信息
              left join
              --select count(distinct RNC) from
              (
                       select /*lac||'-'||ci  lac_ci,*/ dt.* from DT_CELL_W dt
              )B--区域信息--44个RNC
              /*(
                       select lac||'-'||ci  lac_ci, dt.* from DT_CELL_W dt
              )B--区域信息--44个RNC
              left join
              (
                select lac_id||'-'||cell_id  lac_ci, omc.* 
                from OMC_UMTS_3 omc
                where s_date=to_date('20190611','yyyymmdd')
                --and lac_id =43009 and cell_id between 10291 and 10421--测试用LIMIT取样
              )A--数据信息 */   
              on A.lac_ci_new = B.lac_ci
              where B.life like  '%报维护%' --and s_date is not null
            )--3G工参关联OMC_3后，丢失1个RNC，故选择工参表为基表
            where seq =1
          )T1--自忙时指标
          LEFT JOIN
          (
              select 
              s_date, s_hour, lac_id, cell_id, A.lac_ci,
              decode(n3_0014,0,null,null,null, round(n3_0014,2)) as RTWP_3G,--"RTWP>-95"--上行干扰均值--N3_0014
              decode(n3_0014,0,null,null,null, n3_0014) as n3_0014, 
              PROVINCE,--上海
              CITY ,--行政区
              COUNTRY,--优化分区
              FACTORY ,--厂家
              GRID ,--单元格 
              COMPANY ,--区县分公司
              LOOP_LINE ,--环线
              RNC, --RNC
              PRE_FIELD1 ,--聚焦区域 
              --RESERVED5,--频段（频点）
              PRE_FIELD2 ,--基站类型 
              B.LIFE--报维护
              from
              (
                select lac_id||'-'||cell_id  as lac_ci_new, omc.* 
                from OMC_UMTS_8 omc
                where s_date >= v_date_start and s_date< v_date_end--=to_date('20190611','yyyymmdd')
                --and lac_id =43009 and cell_id between 10291 and 10421--测试用LIMIT取样
              )A--数据信息
              left join(
              select /*lac||'-'||ci  lac_ci,*/ dt.* from DT_CELL_W dt
              )B--区域信息
              /*(
                   select lac||'-'||ci  lac_ci, dt.* from DT_CELL_W dt
              )B--区域信息
              left join
              (
                select lac_id||'-'||cell_id  as lac_ci, omc.* 
                from OMC_UMTS_8 omc
                where s_date=to_date('20190611','yyyymmdd')
                --and lac_id =43009 and cell_id between 10291 and 10421--测试用LIMIT取样
              )A--数据信息*/
              on A.lac_ci_new = B.lac_ci     
              where B.life like  '%报维护%' --and s_date is not null
          )T2--天级指标
          --ON T1.LAC_CI = T2.LAC_CI
          ON T1.LAC_ID = T2.LAC_ID AND T1.CELL_ID = T2.CELL_ID
          AND T1.S_DATE = T2.S_DATE
          LEFT JOIN
          (
              select 
              A.TIME_STAMP as S_DATE,
              round(B.LAC)as LAC, round(B.CI) as CI,
              A.LAC_CI,
              A.SERV_CELL_OID,
              B.LAC_CI_FULL,
              /*100*decode(
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+MR_COUNT_RSCP_5+
              MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+
              MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+
              MR_COUNT_RSCP_18+MR_COUNT_RSCP_19+MR_COUNT_RSCP_20+MR_COUNT_RSCP_21+MR_COUNT_RSCP_22+MR_COUNT_RSCP_23+
              MR_COUNT_RSCP_24+MR_COUNT_RSCP_25+MR_COUNT_RSCP_26+MR_COUNT_RSCP_27+MR_COUNT_RSCP_28+MR_COUNT_RSCP_29+
              MR_COUNT_RSCP_30+MR_COUNT_RSCP_31+MR_COUNT_RSCP_32+MR_COUNT_RSCP_33+MR_COUNT_RSCP_34+MR_COUNT_RSCP_35+
              MR_COUNT_RSCP_36+MR_COUNT_RSCP_37+MR_COUNT_RSCP_38+MR_COUNT_RSCP_39+MR_COUNT_RSCP_40+MR_COUNT_RSCP_41+
              MR_COUNT_RSCP_42+MR_COUNT_RSCP_43+MR_COUNT_RSCP_44+MR_COUNT_RSCP_45+MR_COUNT_RSCP_46+MR_COUNT_RSCP_47+
              MR_COUNT_RSCP_48+MR_COUNT_RSCP_49+MR_COUNT_RSCP_50+MR_COUNT_RSCP_51+MR_COUNT_RSCP_52+MR_COUNT_RSCP_53+
              MR_COUNT_RSCP_54+MR_COUNT_RSCP_55+MR_COUNT_RSCP_56+MR_COUNT_RSCP_57+MR_COUNT_RSCP_58+MR_COUNT_RSCP_59+
              MR_COUNT_RSCP_60+MR_COUNT_RSCP_61+MR_COUNT_RSCP_62+MR_COUNT_RSCP_63+MR_COUNT_RSCP_64+MR_COUNT_RSCP_65+
              MR_COUNT_RSCP_66+MR_COUNT_RSCP_67+MR_COUNT_RSCP_68+MR_COUNT_RSCP_69+MR_COUNT_RSCP_70+MR_COUNT_RSCP_71+
              MR_COUNT_RSCP_72+MR_COUNT_RSCP_73+MR_COUNT_RSCP_74+MR_COUNT_RSCP_75+MR_COUNT_RSCP_76+MR_COUNT_RSCP_77+
              MR_COUNT_RSCP_78+MR_COUNT_RSCP_79+MR_COUNT_RSCP_80+MR_COUNT_RSCP_81+MR_COUNT_RSCP_82+MR_COUNT_RSCP_83+
              MR_COUNT_RSCP_84+MR_COUNT_RSCP_85+MR_COUNT_RSCP_86+MR_COUNT_RSCP_87+MR_COUNT_RSCP_88+MR_COUNT_RSCP_89+
              MR_COUNT_RSCP_90+MR_COUNT_RSCP_91), 0,null,null,null,
              round(
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4)
              /
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+MR_COUNT_RSCP_5+
              MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+
              MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+
              MR_COUNT_RSCP_18+MR_COUNT_RSCP_19+MR_COUNT_RSCP_20+MR_COUNT_RSCP_21+MR_COUNT_RSCP_22+MR_COUNT_RSCP_23+
              MR_COUNT_RSCP_24+MR_COUNT_RSCP_25+MR_COUNT_RSCP_26+MR_COUNT_RSCP_27+MR_COUNT_RSCP_28+MR_COUNT_RSCP_29+
              MR_COUNT_RSCP_30+MR_COUNT_RSCP_31+MR_COUNT_RSCP_32+MR_COUNT_RSCP_33+MR_COUNT_RSCP_34+MR_COUNT_RSCP_35+
              MR_COUNT_RSCP_36+MR_COUNT_RSCP_37+MR_COUNT_RSCP_38+MR_COUNT_RSCP_39+MR_COUNT_RSCP_40+MR_COUNT_RSCP_41+
              MR_COUNT_RSCP_42+MR_COUNT_RSCP_43+MR_COUNT_RSCP_44+MR_COUNT_RSCP_45+MR_COUNT_RSCP_46+MR_COUNT_RSCP_47+
              MR_COUNT_RSCP_48+MR_COUNT_RSCP_49+MR_COUNT_RSCP_50+MR_COUNT_RSCP_51+MR_COUNT_RSCP_52+MR_COUNT_RSCP_53+
              MR_COUNT_RSCP_54+MR_COUNT_RSCP_55+MR_COUNT_RSCP_56+MR_COUNT_RSCP_57+MR_COUNT_RSCP_58+MR_COUNT_RSCP_59+
              MR_COUNT_RSCP_60+MR_COUNT_RSCP_61+MR_COUNT_RSCP_62+MR_COUNT_RSCP_63+MR_COUNT_RSCP_64+MR_COUNT_RSCP_65+
              MR_COUNT_RSCP_66+MR_COUNT_RSCP_67+MR_COUNT_RSCP_68+MR_COUNT_RSCP_69+MR_COUNT_RSCP_70+MR_COUNT_RSCP_71+
              MR_COUNT_RSCP_72+MR_COUNT_RSCP_73+MR_COUNT_RSCP_74+MR_COUNT_RSCP_75+MR_COUNT_RSCP_76+MR_COUNT_RSCP_77+
              MR_COUNT_RSCP_78+MR_COUNT_RSCP_79+MR_COUNT_RSCP_80+MR_COUNT_RSCP_81+MR_COUNT_RSCP_82+MR_COUNT_RSCP_83+
              MR_COUNT_RSCP_84+MR_COUNT_RSCP_85+MR_COUNT_RSCP_86+MR_COUNT_RSCP_87+MR_COUNT_RSCP_88+MR_COUNT_RSCP_89+
              MR_COUNT_RSCP_90+MR_COUNT_RSCP_91),4)
              ) as RSRP_3G,--"RSRP_3G>30"*/
              100*decode(
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+MR_COUNT_RSCP_5+
              MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+
              MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+
              MR_COUNT_RSCP_18+MR_COUNT_RSCP_19+MR_COUNT_RSCP_20+MR_COUNT_RSCP_21+MR_COUNT_RSCP_22+MR_COUNT_RSCP_23+
              MR_COUNT_RSCP_24+MR_COUNT_RSCP_25+MR_COUNT_RSCP_26+MR_COUNT_RSCP_27+MR_COUNT_RSCP_28+MR_COUNT_RSCP_29+
              MR_COUNT_RSCP_30+MR_COUNT_RSCP_31+MR_COUNT_RSCP_32+MR_COUNT_RSCP_33+MR_COUNT_RSCP_34+MR_COUNT_RSCP_35+
              MR_COUNT_RSCP_36+MR_COUNT_RSCP_37+MR_COUNT_RSCP_38+MR_COUNT_RSCP_39+MR_COUNT_RSCP_40+MR_COUNT_RSCP_41+
              MR_COUNT_RSCP_42+MR_COUNT_RSCP_43+MR_COUNT_RSCP_44+MR_COUNT_RSCP_45+MR_COUNT_RSCP_46+MR_COUNT_RSCP_47+
              MR_COUNT_RSCP_48+MR_COUNT_RSCP_49+MR_COUNT_RSCP_50+MR_COUNT_RSCP_51+MR_COUNT_RSCP_52+MR_COUNT_RSCP_53+
              MR_COUNT_RSCP_54+MR_COUNT_RSCP_55+MR_COUNT_RSCP_56+MR_COUNT_RSCP_57+MR_COUNT_RSCP_58+MR_COUNT_RSCP_59+
              MR_COUNT_RSCP_60+MR_COUNT_RSCP_61+MR_COUNT_RSCP_62+MR_COUNT_RSCP_63+MR_COUNT_RSCP_64+MR_COUNT_RSCP_65+
              MR_COUNT_RSCP_66+MR_COUNT_RSCP_67+MR_COUNT_RSCP_68+MR_COUNT_RSCP_69+MR_COUNT_RSCP_70+MR_COUNT_RSCP_71+
              MR_COUNT_RSCP_72+MR_COUNT_RSCP_73+MR_COUNT_RSCP_74+MR_COUNT_RSCP_75+MR_COUNT_RSCP_76+MR_COUNT_RSCP_77+
              MR_COUNT_RSCP_78+MR_COUNT_RSCP_79+MR_COUNT_RSCP_80+MR_COUNT_RSCP_81+MR_COUNT_RSCP_82+MR_COUNT_RSCP_83+
              MR_COUNT_RSCP_84+MR_COUNT_RSCP_85+MR_COUNT_RSCP_86+MR_COUNT_RSCP_87+MR_COUNT_RSCP_88+MR_COUNT_RSCP_89+
              MR_COUNT_RSCP_90+MR_COUNT_RSCP_91), 0,null,null,null,
              round(
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+
              MR_COUNT_RSCP_5+MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+
              MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+
              MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+MR_COUNT_RSCP_18+MR_COUNT_RSCP_19)--100-<大于-95>
              /
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+MR_COUNT_RSCP_5+
              MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+
              MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+
              MR_COUNT_RSCP_18+MR_COUNT_RSCP_19+MR_COUNT_RSCP_20+MR_COUNT_RSCP_21+MR_COUNT_RSCP_22+MR_COUNT_RSCP_23+
              MR_COUNT_RSCP_24+MR_COUNT_RSCP_25+MR_COUNT_RSCP_26+MR_COUNT_RSCP_27+MR_COUNT_RSCP_28+MR_COUNT_RSCP_29+
              MR_COUNT_RSCP_30+MR_COUNT_RSCP_31+MR_COUNT_RSCP_32+MR_COUNT_RSCP_33+MR_COUNT_RSCP_34+MR_COUNT_RSCP_35+
              MR_COUNT_RSCP_36+MR_COUNT_RSCP_37+MR_COUNT_RSCP_38+MR_COUNT_RSCP_39+MR_COUNT_RSCP_40+MR_COUNT_RSCP_41+
              MR_COUNT_RSCP_42+MR_COUNT_RSCP_43+MR_COUNT_RSCP_44+MR_COUNT_RSCP_45+MR_COUNT_RSCP_46+MR_COUNT_RSCP_47+
              MR_COUNT_RSCP_48+MR_COUNT_RSCP_49+MR_COUNT_RSCP_50+MR_COUNT_RSCP_51+MR_COUNT_RSCP_52+MR_COUNT_RSCP_53+
              MR_COUNT_RSCP_54+MR_COUNT_RSCP_55+MR_COUNT_RSCP_56+MR_COUNT_RSCP_57+MR_COUNT_RSCP_58+MR_COUNT_RSCP_59+
              MR_COUNT_RSCP_60+MR_COUNT_RSCP_61+MR_COUNT_RSCP_62+MR_COUNT_RSCP_63+MR_COUNT_RSCP_64+MR_COUNT_RSCP_65+
              MR_COUNT_RSCP_66+MR_COUNT_RSCP_67+MR_COUNT_RSCP_68+MR_COUNT_RSCP_69+MR_COUNT_RSCP_70+MR_COUNT_RSCP_71+
              MR_COUNT_RSCP_72+MR_COUNT_RSCP_73+MR_COUNT_RSCP_74+MR_COUNT_RSCP_75+MR_COUNT_RSCP_76+MR_COUNT_RSCP_77+
              MR_COUNT_RSCP_78+MR_COUNT_RSCP_79+MR_COUNT_RSCP_80+MR_COUNT_RSCP_81+MR_COUNT_RSCP_82+MR_COUNT_RSCP_83+
              MR_COUNT_RSCP_84+MR_COUNT_RSCP_85+MR_COUNT_RSCP_86+MR_COUNT_RSCP_87+MR_COUNT_RSCP_88+MR_COUNT_RSCP_89+
              MR_COUNT_RSCP_90+MR_COUNT_RSCP_91),4)
              ) as RSRP_3G,--"RSCP_3G>30"
              
              100*decode(
              (MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+
              MR_COUNT_ECNO_6+MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+
              MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+
              MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+
              MR_COUNT_ECNO_24+MR_COUNT_ECNO_25+MR_COUNT_ECNO_26+MR_COUNT_ECNO_27+MR_COUNT_ECNO_28+MR_COUNT_ECNO_29+
              MR_COUNT_ECNO_30+MR_COUNT_ECNO_31+MR_COUNT_ECNO_32+MR_COUNT_ECNO_33+MR_COUNT_ECNO_34+MR_COUNT_ECNO_35+
              MR_COUNT_ECNO_36+MR_COUNT_ECNO_37+MR_COUNT_ECNO_38+MR_COUNT_ECNO_39+MR_COUNT_ECNO_40+MR_COUNT_ECNO_41+
              MR_COUNT_ECNO_42+MR_COUNT_ECNO_43+MR_COUNT_ECNO_44+MR_COUNT_ECNO_45+MR_COUNT_ECNO_46+MR_COUNT_ECNO_47+
              MR_COUNT_ECNO_48+MR_COUNT_ECNO_49),0,null,null,null,
              round(
              (MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+MR_COUNT_ECNO_6+
              MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+
              MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+
              MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+MR_COUNT_ECNO_24)
              /(MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+
              MR_COUNT_ECNO_6+MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+
              MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+
              MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+
              MR_COUNT_ECNO_24+MR_COUNT_ECNO_25+MR_COUNT_ECNO_26+MR_COUNT_ECNO_27+MR_COUNT_ECNO_28+MR_COUNT_ECNO_29+
              MR_COUNT_ECNO_30+MR_COUNT_ECNO_31+MR_COUNT_ECNO_32+MR_COUNT_ECNO_33+MR_COUNT_ECNO_34+MR_COUNT_ECNO_35+
              MR_COUNT_ECNO_36+MR_COUNT_ECNO_37+MR_COUNT_ECNO_38+MR_COUNT_ECNO_39+MR_COUNT_ECNO_40+MR_COUNT_ECNO_41+
              MR_COUNT_ECNO_42+MR_COUNT_ECNO_43+MR_COUNT_ECNO_44+MR_COUNT_ECNO_45+MR_COUNT_ECNO_46+MR_COUNT_ECNO_47+
              MR_COUNT_ECNO_48+MR_COUNT_ECNO_49),4)
              )as ECIO_3G,--"ECIO_3G>30"--ECIO<-12db比例大于30%小区占比
              PROVINCE,--上海
              CITY ,--行政区
              COUNTRY,--优化分区
              FACTORY ,--厂家
              GRID ,--单元格 
              COMPANY ,--区县分公司
              LOOP_LINE ,--环线
              RNC, --RNC
              PRE_FIELD1 ,--聚焦区域 
              --RESERVED5,--频段（频点）
              PRE_FIELD2 ,--基站类型 
              B.LIFE,--报维护
              MR_COUNT_ECNO_0,MR_COUNT_ECNO_1,MR_COUNT_ECNO_2,MR_COUNT_ECNO_3,MR_COUNT_ECNO_4,MR_COUNT_ECNO_5,
              MR_COUNT_ECNO_6,MR_COUNT_ECNO_7,MR_COUNT_ECNO_8,MR_COUNT_ECNO_9,MR_COUNT_ECNO_10,MR_COUNT_ECNO_11,
              MR_COUNT_ECNO_12,MR_COUNT_ECNO_13,MR_COUNT_ECNO_14,MR_COUNT_ECNO_15,MR_COUNT_ECNO_16,MR_COUNT_ECNO_17,
              MR_COUNT_ECNO_18,MR_COUNT_ECNO_19,MR_COUNT_ECNO_20,MR_COUNT_ECNO_21,MR_COUNT_ECNO_22,MR_COUNT_ECNO_23,
              MR_COUNT_ECNO_24,MR_COUNT_ECNO_25,MR_COUNT_ECNO_26,MR_COUNT_ECNO_27,MR_COUNT_ECNO_28,MR_COUNT_ECNO_29,
              MR_COUNT_ECNO_30,MR_COUNT_ECNO_31,MR_COUNT_ECNO_32,MR_COUNT_ECNO_33,MR_COUNT_ECNO_34,MR_COUNT_ECNO_35,
              MR_COUNT_ECNO_36,MR_COUNT_ECNO_37,MR_COUNT_ECNO_38,MR_COUNT_ECNO_39,MR_COUNT_ECNO_40,MR_COUNT_ECNO_41,
              MR_COUNT_ECNO_42,MR_COUNT_ECNO_43,MR_COUNT_ECNO_44,MR_COUNT_ECNO_45,MR_COUNT_ECNO_46,MR_COUNT_ECNO_47,
              MR_COUNT_ECNO_48,MR_COUNT_ECNO_49,
              
              MR_COUNT_RSCP_N5,MR_COUNT_RSCP_N4,MR_COUNT_RSCP_N3,MR_COUNT_RSCP_N2,MR_COUNT_RSCP_N1,
              MR_COUNT_RSCP_0,MR_COUNT_RSCP_1,MR_COUNT_RSCP_2,MR_COUNT_RSCP_3,MR_COUNT_RSCP_4,MR_COUNT_RSCP_5,
              MR_COUNT_RSCP_6,MR_COUNT_RSCP_7,MR_COUNT_RSCP_8,MR_COUNT_RSCP_9,MR_COUNT_RSCP_10,MR_COUNT_RSCP_11,
              MR_COUNT_RSCP_12,MR_COUNT_RSCP_13,MR_COUNT_RSCP_14,MR_COUNT_RSCP_15,MR_COUNT_RSCP_16,MR_COUNT_RSCP_17,
              MR_COUNT_RSCP_18,MR_COUNT_RSCP_19,MR_COUNT_RSCP_20,MR_COUNT_RSCP_21,MR_COUNT_RSCP_22,MR_COUNT_RSCP_23,
              MR_COUNT_RSCP_24,MR_COUNT_RSCP_25,MR_COUNT_RSCP_26,MR_COUNT_RSCP_27,MR_COUNT_RSCP_28,MR_COUNT_RSCP_29,
              MR_COUNT_RSCP_30,MR_COUNT_RSCP_31,MR_COUNT_RSCP_32,MR_COUNT_RSCP_33,MR_COUNT_RSCP_34,MR_COUNT_RSCP_35,
              MR_COUNT_RSCP_36,MR_COUNT_RSCP_37,MR_COUNT_RSCP_38,MR_COUNT_RSCP_39,MR_COUNT_RSCP_40,MR_COUNT_RSCP_41,
              MR_COUNT_RSCP_42,MR_COUNT_RSCP_43,MR_COUNT_RSCP_44,MR_COUNT_RSCP_45,MR_COUNT_RSCP_46,MR_COUNT_RSCP_47,
              MR_COUNT_RSCP_48,MR_COUNT_RSCP_49,MR_COUNT_RSCP_50,MR_COUNT_RSCP_51,MR_COUNT_RSCP_52,MR_COUNT_RSCP_53,
              MR_COUNT_RSCP_54,MR_COUNT_RSCP_55,MR_COUNT_RSCP_56,MR_COUNT_RSCP_57,MR_COUNT_RSCP_58,MR_COUNT_RSCP_59,
              MR_COUNT_RSCP_60,MR_COUNT_RSCP_61,MR_COUNT_RSCP_62,MR_COUNT_RSCP_63,MR_COUNT_RSCP_64,MR_COUNT_RSCP_65,
              MR_COUNT_RSCP_66,MR_COUNT_RSCP_67,MR_COUNT_RSCP_68,MR_COUNT_RSCP_69,MR_COUNT_RSCP_70,MR_COUNT_RSCP_71,
              MR_COUNT_RSCP_72,MR_COUNT_RSCP_73,MR_COUNT_RSCP_74,MR_COUNT_RSCP_75,MR_COUNT_RSCP_76,MR_COUNT_RSCP_77,
              MR_COUNT_RSCP_78,MR_COUNT_RSCP_79,MR_COUNT_RSCP_80,MR_COUNT_RSCP_81,MR_COUNT_RSCP_82,MR_COUNT_RSCP_83,
              MR_COUNT_RSCP_84,MR_COUNT_RSCP_85,MR_COUNT_RSCP_86,MR_COUNT_RSCP_87,MR_COUNT_RSCP_88,MR_COUNT_RSCP_89,
              MR_COUNT_RSCP_90,MR_COUNT_RSCP_91
              from
              (
                  select 
                  regexp_substr(serv_cell_oid,'[0-9]+')||'-'||regexp_substr(serv_cell_oid,'[^.]+',1,2,'i') as lac_ci ,--10-10031
                  mr.* 
                  from MR_STAT_CELL_8@WRNOP_44 mr
                  where mr.time_stamp  >= v_date_start and mr.time_stamp < v_date_end--= to_date(20190611,'yyyymmdd') /*and regexp_substr(serv_cell_oid,'[0-9]+') = 10*/
              )A--数据信息
              left join
              (
                  select 
                  /*substr(dt.lac,4)||'-'||dt.ci as lac_ci ,*/lac||'-'||ci  as LAC_CI_FULL, --10-10031 = 43010-10031--保留原始拼接是为了和忙时/天级指标关联
                  dt.* 
                  from DT_CELL_W dt /*where substr(dt.lac,4)= 10*/
              )B--区域信息
              on B.lac_ci = A.lac_ci
              where B.life like  '%报维护%' 
              /*(
                  select 
                  substr(dt.lac,4)||'-'||dt.ci as lac_ci ,lac||'-'||ci  as LAC_CI_FULL, --10-10031 = 43010-10031--保留原始拼接是为了和忙时/天级指标关联
                  dt.* 
                  from DT_CELL_W dt \*where substr(dt.lac,4)= 10*\
              )B--区域信息
              left join
              (
                  select 
                  regexp_substr(serv_cell_oid,'[0-9]+')||'-'||regexp_substr(serv_cell_oid,'[^.]+',1,2,'i') as lac_ci ,--10-10031
                  mr.* 
                  from MR_STAT_CELL_8 mr
                  where time_stamp  = to_date(20190611,'yyyymmdd') \*and regexp_substr(serv_cell_oid,'[0-9]+') = 10*\
              )A--数据信息
              on B.lac_ci = A.lac_ci
              where B.life like  '%报维护%'  and s_date is not null*/
          )T3--天级MR指标
          ON T1.LAC_ID=T3.LAC
          AND T1.CELL_ID = T3.CI
          AND T1.S_DATE = T3.S_DATE;
          commit;
          select count(1) into v_insert_cnt from ZC_CELL_LIST_3G t where t.s_date >= v_date_start and t.s_date< v_date_end;
          select count(1) into v_insert_repeat from
          (
                 select count(1) from ZC_CELL_LIST_3G t 
                 where t.s_date >= v_date_start and t.s_date< v_date_end 
                 group by t.lac_ci  having count(1)>1
          );
          dbms_output.put_line('表 ZC_CELL_LIST_3G 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
          ');

     END PROC_ZC_CELL_LIST_3G;
    
    
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：OMC_LTE_3 /DT_CELL_L /OMC_LTE_8 /MR_LTE_MRS_CELL_8 /
  --out：ZC_CELL_LIST_4G
  PROCEDURE PROC_ZC_CELL_LIST_4G(V_DATE_THRESHOLD_START VARCHAR2) IS
        v_date_start  date;
        v_date_end   date;
        --v_loop_log number := 0 ;
        v_insert_cnt   number;
        v_insert_repeat   number;
        v_partition_name varchar2(30);
        v_ssql varchar2(500);
        v_clean_flag number;
        --v_proc_end_flag number :=0;
        
        BEGIN
            --起止时间戳格式化
            --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
            select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
            --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
            select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
            
            --从系统中获取待插入分区名
            select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
            where t.table_name = 'ZC_CELL_LIST_4G' 
            and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
            and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
            --或拼接待插入分区名
            --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
            
            --PLUS7暂未部署
            --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_TRUNCATE_RANGE_INDEX('LRNOP','ZC_CELL_LIST_4G',v_date_start,v_date_start,'0','0');
            
            --分区数据清理
            /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_CELL_LIST_2G partition(' ||v_partition_name||');' into v_ssql from dual;
            execute immediate v_ssql;*/

            select count(1) into v_clean_flag from ZC_CELL_LIST_4G where s_date >= v_date_start and s_date < v_date_end;
            while v_clean_flag !=0 loop
              
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = 'ZC_CELL_LIST_4G';
            execute immediate v_ssql;
            
            /*select 'DELETE FROM ZC_CELL_LIST_4G PARTITION(' || v_partition_name||')' into v_ssql from dual;
            execute immediate v_ssql;*/
            select count(1) into v_clean_flag from ZC_CELL_LIST_4G where s_date >= v_date_start and s_date < v_date_end;
            end loop;
        
            INSERT INTO ZC_CELL_LIST_4G
            SELECT T1.S_DATE, T1.S_HOUR,--所选取的指标所在天级时段 
            T1.ECGI, 
            --各种4G小区指标
            "TPQH_4G<95" as TPQH_4G , "CQI_4G>20" CQI_4G, "XXGZSL_4G<5" XXGZSL_4G, "JTL_4G<90"JTL_4G, "DHL_4G>2"DHL_4G, "CSFB_4G<95" CSFB_4G,
            "PRB底噪_4G>-95" PRB_4G, "RSRP<-100_4G>30"RSRP_4G, 
            RFG_BADFLAG_4G_NUM,--Numerator--天级别RFG小区数量分子
            RFG_BADFLAG_4G_DEN,--Denominator--天级别RFG小区数量分母
            --各种4G小区问题标签
            TPQH_BADFLAG_4G, CQI_BADFLAG_4G, XXGZSL_BADFLAG_4G, JTL_BADFLAG_4G, DHL_BADFLAG_4G, CSFB_BADFLAG_4G, H_JAM_BADFLAG_4G, RFG_BADFLAG_4G, 
            --OMC指标源值：其中N4_0033/N4_0046~N4_0049为天级OMC指标，其余均为忙时指标！！！
            N4_0001, N4_0002, N4_0003, N4_0004, N4_0005, N4_0006, N4_0007, 
            N4_0008, N4_0009, N4_0010, N4_0011, N4_0012, N4_0013, N4_0014, 
            N4_0015, N4_0016, N4_0017, N4_0018, N4_0019, N4_0020, N4_0021, 
            N4_0022, N4_0023, N4_0024, N4_0025, N4_0026, N4_0027, N4_0028, 
            N4_0029, N4_0030, N4_0031, N4_0032, 
            N4_0033, --求取底噪的相关字段保留天级别！！！
            N4_0034, N4_0035, 
            N4_0036, N4_0037, N4_0038, N4_0039, N4_0040, N4_0041, N4_0042, 
            N4_0043, N4_0044, N4_0045, 
            N4_0046, N4_0047, N4_0048, N4_0049,--求取底噪的相关字段保留天级别！！！
            N4_0050, AVG_CQI,
            T1.province,--上海
            T1.vendor_cell_id,--行政区
            T1.county,--优化分区
            T1.vendor_id,--厂家
            T1.reserved3,--单元格 
            T1.reserved8,--区县分公司
            T1.town_id,--环线
            T1.rnc, --RNC
            T1.reserved4,--聚焦区域 
            T1.reserved5,--频段（频点）
            T1.cover_type,--基站类型 
            T1.life--报维护
            /*select count(1) from(
            select distinct RESERVED3*/
            FROM
            (
              select A.*,
              PROVINCE,--上海
              VENDOR_CELL_ID,--行政区
              COUNTY,--优化分区
              VENDOR_ID,--厂家
              RESERVED3,--单元格 
              RESERVED8,--区县分公司
              TOWN_ID,--环线
              RNC, --RNC
              RESERVED4,--聚焦区域 
              RESERVED5,--频段（频点）
              COVER_TYPE,--基站类型 
              LIFE--报维护
              from
              (
                select s_date, ECGI, s_hour,--被选取的小时时间, 
                --6组4G指标具体值，用来确认标签是否正确
                100* decode(n4_0042,0,null,null,null,round(n4_0041/n4_0042,4)) as "TPQH_4G<95",
                100*decode(
                (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013+n4_0014+n4_0015+n4_0016+n4_0017+n4_0018+n4_0019+n4_0020+n4_0021+n4_0022),0,null,null,null,
                round(
                (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013)
                /(n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013+n4_0014+n4_0015+n4_0016+n4_0017+n4_0018+n4_0019+n4_0020+n4_0021+n4_0022)
                ,4)) "CQI_4G>20",
                round(n4_0032*1024*1024/1000/1000,2) "XXGZSL_4G<5",
                100*decode(n4_0002*n4_0004,0,null,null,null,round((n4_0001*n4_0003)/(n4_0002*n4_0004),4)) as "JTL_4G<90",  
                100*decode(n4_0006,0,null,null,null,round(n4_0005/n4_0006,4)) as "DHL_4G>2",
                100*decode(n4_0024,0,null,null,null,round(n4_0023/n4_0024,4)) as "CSFB_4G<95",
                
                --TPQH差小区标签
                case when 100* decode(n4_0042,0,null,null,null,round(n4_0041/n4_0042,4))<95 then 1 else 0 end as TPQH_BADFLAG_4G,--TPQH_BADCELL_NUM_4G 

                --CQI差小区标签
                case when decode(
                (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013+n4_0014+n4_0015+n4_0016+n4_0017+n4_0018+n4_0019+n4_0020+n4_0021+n4_0022),0,null,null,null,
                round(
                (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013)
                /(n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013+n4_0014+n4_0015+n4_0016+n4_0017+n4_0018+n4_0019+n4_0020+n4_0021+n4_0022)
                ,4))>0.2 
                then 1 else 0 end as CQI_BADFLAG_4G,--CQI_BADCELL_NUM_4G 

                --单用户下行感知速率<5M 差小区标签
                case when round(n4_0032*1024*1024/1000/1000,4) <5 then 1 else 0 end as XXGZSL_BADFLAG_4G,--USER_BADCELL_NUM_4G 

                --接通率差小区标签--指标门限待确认
                case when 100*decode(n4_0002*n4_0004,0,null,null,null,round((n4_0001*n4_0003)/(n4_0002*n4_0004),4))<90 then 1 else 0 end as JTL_BADFLAG_4G,--JTL_BADCELL_NUM_4G 

                --掉话率高小区标签
                case when 100*decode(n4_0006,0,null,null,null,round(n4_0005/n4_0006,4))>2 then 1 else 0 end as DHL_BADFLAG_4G,--DXL_BADCELL_NUM_4G 

                --CSFB差小区标签
                case when 100*decode(n4_0024,0,null,null,null,round(n4_0023/n4_0024,4))<95 then 1 else 0 end as CSFB_BADFLAG_4G,--CSFB_BAD_CELL_NUM 

                n4_0001, n4_0002, n4_0003, n4_0004, n4_0005, n4_0006, n4_0007,
                n4_0008, n4_0009, n4_0010, n4_0011, n4_0012, n4_0013, n4_0014,
                n4_0015, n4_0016, n4_0017, n4_0018, n4_0019, n4_0020, n4_0021,
                n4_0022, n4_0023, n4_0024, n4_0025, n4_0026, n4_0027, n4_0028,
                n4_0029, n4_0030, n4_0031, n4_0032,/* n4_0033,*/ n4_0034, n4_0035,
                n4_0036, n4_0037, n4_0038, n4_0039, n4_0040, n4_0041, n4_0042,
                n4_0043, n4_0044, n4_0045, /*n4_0046, n4_0047, n4_0048, n4_0049,*/
                n4_0050, avg_cqi

                --select *
                from
                (
                  select 
                  s_date, ECGI, s_hour, 
                  (decode(n4_0027,null,0,n4_0027)+decode(n4_0050,null,0,n4_0050)) as TPQHCGL,--每个小区每小时，按照同频切换成功率进行排序
                  row_number() over(partition by s_date,ecgi order by (n4_0027+decode(n4_0050,null,0,n4_0050)) desc ) as seq, 
                  n4_0001, n4_0002, n4_0003, n4_0004, n4_0005, n4_0006, n4_0007, 
                  n4_0008, n4_0009, n4_0010, n4_0011, n4_0012, n4_0013, n4_0014, 
                  n4_0015, n4_0016, n4_0017, n4_0018, n4_0019, n4_0020, n4_0021, 
                  n4_0022, n4_0023, n4_0024, n4_0025, n4_0026, n4_0027, n4_0028, 
                  n4_0029, n4_0030, n4_0031, n4_0032, /*n4_0033,*/ n4_0034, n4_0035, 
                  n4_0036, n4_0037, n4_0038, n4_0039, n4_0040, n4_0041, n4_0042, 
                  n4_0043, n4_0044, n4_0045, /*n4_0046, n4_0047, n4_0048, n4_0049,*/ n4_0050, avg_cqi
                  from
                  (
                    select * from omc_lte_3 t 
                    where t.s_date >= v_date_start and t.s_date < v_date_end--=to_date('20190611','yyyymmdd')
                    --and ECGI between 8388619 and 8388630--测试用LIMIT取样
                    --and n4_0050 is null--该字段大量为NULL
                  )
                  /*group by s_date, ecgi, s_hour, (n4_0027+decode(n4_0050,null,0,n4_0050)),
                  n4_0001, n4_0002, n4_0003, n4_0004, n4_0005, n4_0006, n4_0007, 
                  n4_0008, n4_0009, n4_0010, n4_0011, n4_0012, n4_0013, n4_0014, 
                  n4_0015, n4_0016, n4_0017, n4_0018, n4_0019, n4_0020, n4_0021, 
                  n4_0022, n4_0023, n4_0024, n4_0025, n4_0026, n4_0027, n4_0028, 
                  n4_0029, n4_0030, n4_0031, n4_0032, n4_0033, n4_0034, n4_0035, 
                  n4_0036, n4_0037, n4_0038, n4_0039, n4_0040, n4_0041, n4_0042, 
                  n4_0043, n4_0044, n4_0045, n4_0046, n4_0047, n4_0048, n4_0049, 
                  n4_0050, avg_cqi*/
                )
                where seq = 1
              )A--质差小区标签
              left join
              (
                   select /*enb_id*256+ci as ecgi,*/ dt.* 
                   from dt_cell_l dt
              )B--分区信息 
              on A.ECGI = B.ECGI
              where B.life like  '%报维护%' --分子中仅考虑报维护类型的小区？？？--待确认点
            )T1--自忙时指标
            /*)*/
            LEFT JOIN
            (
              select A.s_date, A.ECGI, round(A.n4_0033,2) as "PRB底噪_4G>-95", 
              n4_0033, n4_0046, n4_0047, n4_0048, n4_0049,--求取底噪的相关字段保留天级别！！！
              B.POORRSRP110_RATE as "RSRP<-100_4G>30",
              A.H_JAM_BADFLAG_4G, B.RFG_BADFLAG_4G, B.RFG_BADFLAG_4G_NUM, B.RFG_BADFLAG_4G_DEN,
              PROVINCE,--上海
              VENDOR_CELL_ID,--行政区
              COUNTY,--优化分区
              VENDOR_ID,--厂家
              RESERVED3,--单元格 
              RESERVED8,--区县分公司
              TOWN_ID,--环线
              RNC, --RNC
              RESERVED4,--聚焦区域 
              RESERVED5,--频段（频点）
              COVER_TYPE,--基站类型 
              C.LIFE--报维护
              from
              (
                  select s_date, ECGI, 
                  decode(n4_0033,0,null,null,null, n4_0033) as n4_0033,                
                  n4_0046, n4_0047, n4_0048, n4_0049,--求取底噪的相关字段保留天级别！！！
                  case when n4_0033>-95 then 1 else 0 end as H_JAM_BADFLAG_4G --4g高干扰质差小区标签 --H_JAM_NUM_4G 
                  from omc_lte_8 omc 
                  where omc.s_date >= v_date_start and omc.s_date< v_date_end--= to_date(20190611,'yyyymmdd') 
                  --and ECGI between 8388619 and 8388630--测试用LIMIT取样--9436437
              )A--底噪数据
              left join
              (
                  select start_time as s_date, 
                  cell_uk, 
                  --regexp_substr(cell_uk,'[^-]+',1,1,'i') enb_id, 
                  --regexp_substr(cell_uk,'[^-]+',1,2,'i') cell_id,
                  regexp_substr(cell_uk,'[^-]+',1,1,'i')*256+ regexp_substr(cell_uk,'[^-]+',1,2,'i') ECGI,
                  100*decode((RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47),
                  0,null,null,null, round((RSRP00+RSRP01+RSRP02_04+RSRP05_06)/
                  (RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47),4)) as POORRSRP110_RATE,
                  case when 
                    decode((RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47),
                    0,null,null,null, 
                    round((RSRP00+RSRP01+RSRP02_04+RSRP05_06)/
                    (RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47),4))>0.3 
                  then 1 else 0 end as RFG_BADFLAG_4G,--RFG_CELL_NUM_4G 
                  RSRP00+RSRP01+RSRP02_04+RSRP05_06 as RFG_BADFLAG_4G_NUM,
                  RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47 as RFG_BADFLAG_4G_DEN
                  from mr_lte_mrs_cell_8 mr
                  where mr.start_time >= v_date_start and mr.start_time< v_date_end--= to_date(20190611,'yyyymmdd')
                  --and ECGI between 8388619 and 8388630--测试用LIMIT取样
              )B--MR_RSRP数据
              on A.s_date = B.s_date
              and A.ECGI = B.ECGI
              left join
              (
                 select /*enb_id*256+ci as ECGI,*/ dt.*
                 from dt_cell_l dt
              )C--分区信息
              on A.ECGI = C.ECGI
              where C.life like '%报维护%' --分子中仅考虑报维护类型的小区？？？--待确认点
            )T2--天级指标
            ON T1.S_DATE = T2.S_DATE /*AND T1.AREA = T2.AREA*/ AND T1.ECGI = T2.ECGI
            ;
            commit;
            select count(1) into v_insert_cnt from ZC_CELL_LIST_4G t where t.s_date >= v_date_start and t.s_date <v_date_end;
            select count(1) into v_insert_repeat from
            (
                   select count(1) from ZC_CELL_LIST_4G t 
                   where t.s_date >= v_date_start and t.s_date <v_date_end 
                   group by t.ecgi having count(1)>1
            );
            dbms_output.put_line('表 ZC_CELL_LIST_4G 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
            ');

        END PROC_ZC_CELL_LIST_4G;
      

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：ZC_CELL_LIST_2G
  --out：ZC_BAD_CELL_LIST_2G_DAY
  PROCEDURE PROC_ZC_BAD_CELL_LIST_2G(V_DATE_THRESHOLD_START VARCHAR2) IS
        v_date_start  date;
        v_date_end   date;
        v_partition_name_1   varchar2(15);--当前日期1天前的分区名
        v_partition_name_2   varchar2(15);--当前日期2天前的分区名
        v_partition_name_3   varchar2(15);--当前日期3天前的分区名
        v_partition_name_4   varchar2(15);--当前日期4天前的分区名
        v_partition_name_5   varchar2(15);--当前日期5天前的分区名
        v_partition_name_6   varchar2(15);--当前日期6天前的分区名
        v_partition_name_7   varchar2(15);--当前日期7天前的分区名
        
        --v_loop_log number := 0 ;
        v_insert_cnt   number;
        v_insert_repeat   number;
        v_partition_name varchar2(30);
        v_ssql varchar2(4000);
        v_clean_flag number;
        --v_proc_end_flag number :=0;
        v_date_end_vc varchar2(10);
        
        BEGIN
            --起止时间戳格式化
            v_date_start := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd');--起始时间戳'yyyymmdd'格式化--2019/06/25
            v_date_end  := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd')-7;--2019/08/05
            
            --v_date_start_vc := to_char(v_date_start-1, 'yyyymmdd');--20190811
            v_date_end_vc := to_char(v_date_end, 'yyyymmdd');--20190805            
            
            --从系统中获取待插入分区名
            select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
            where t.table_name = 'ZC_BAD_CELL_LIST_2G_DAY' 
            and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
            and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
            --或拼接待插入分区名
            --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
            
            --PLUS7暂未部署
            --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_BAD_CELL_LIST_2G_DAY',v_date_start,v_date_start,'0','0');
            
            --分区数据清理
            /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_BAD_CELL_LIST_2G_DAY partition(' ||v_partition_name||');' into v_ssql from dual;
            execute immediate v_ssql;*/
            select count(1) into v_clean_flag from ZC_BAD_CELL_LIST_2G_DAY where s_date  = v_date_start /*and start_time  < v_date_end*/;
            while v_clean_flag != 0 loop
              /*execute immediate 'DELETE FROM ZC_BAD_CELL_LIST_2G_DAY PARTITION(' || v_partition_name||')';
              commit;*/
              select
              'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
              into v_ssql
              from FAST_DATA_PROCESS_TEMPLATE s
              where s.table_name = 'ZC_BAD_CELL_LIST_2G_DAY';
              execute immediate v_ssql;
              
              select count(1) into v_clean_flag from ZC_BAD_CELL_LIST_2G_DAY where s_date = v_date_start /*and start_time < v_date_end*/;
            end loop;

            
            --周期数据分区罗列
            --下述拼接读取方式失败，动态SQL内引入Partition时，Partition结果需为最终值，不可加入计算
            --P_20190624-P_20190623-P_20190622-P_20190621-P_20190620-P_20190619-P_20190618
            v_partition_name_1 := 'P_'||to_char(v_date_start-1,'yyyymmdd');
            v_partition_name_2 := 'P_'||to_char(v_date_start-2,'yyyymmdd');
            v_partition_name_3 := 'P_'||to_char(v_date_start-3,'yyyymmdd');
            v_partition_name_4 := 'P_'||to_char(v_date_start-4,'yyyymmdd');
            v_partition_name_5 := 'P_'||to_char(v_date_start-5,'yyyymmdd');
            v_partition_name_6 := 'P_'||to_char(v_date_start-6,'yyyymmdd');
            v_partition_name_7 := 'P_'||to_char(v_date_start-7,'yyyymmdd');
            
            
            /*select 'P_'||
            to_char(v_date_start-1,'yyyymmdd') ||'-P_'|| to_char(v_date_start-2,'yyyymmdd') ||'-P_'|| to_char(v_date_start-3,'yyyymmdd') ||'-P_'|| 
            to_char(v_date_start-4,'yyyymmdd') ||'-P_'|| to_char(v_date_start-5,'yyyymmdd') ||'-P_'|| to_char(v_date_start-6,'yyyymmdd') ||'-P_'|| 
            to_char(v_date_start-7,'yyyymmdd') into v_partition_name_7 from dual;*/

            /*regexp_substr(v_partition_name_7,'[^-]+',1,1,'i') --P_20190624
            regexp_substr(v_partition_name_7,'[^-]+',1,2,'i') --P_20190623
            regexp_substr(v_partition_name_7,'[^-]+',1,3,'i') --P_20190622
            regexp_substr(v_partition_name_7,'[^-]+',1,4,'i') --P_20190621
            regexp_substr(v_partition_name_7,'[^-]+',1,5,'i') --P_20190620
            regexp_substr(v_partition_name_7,'[^-]+',1,6,'i') --P_20190619
            regexp_substr(v_partition_name_7,'[^-]+',1,7,'i') --P_20190618*/
    
            execute immediate'
            insert into ZC_BAD_CELL_LIST_2G_DAY
            SELECT
            ZC.S_DATE ,
            EX.DAYS_RANGE ,--评估周级范围, --当前日期下的前7天
            s_hour ,--忙时时间戳, 
            ZC.OID ,--"OID", 
            --1.接通
            JTL_2G ,--"2G接通率<95%",
            --100*DECODE(F0014*F0018,0,null,(F0108*F0120)/(F0014*F0018)) 验证,
            F0018,--"TCH请求次数",
            F0014,--"SDCCH请求次数",

            --2.掉话
            DXL_2G ,--"2G掉话率>2%", 
            --100*DECODE(F0120,0,null,F0026/F0120) 验证,
            trunc(F0026) F0026,--"TCH掉话次数",
            trunc(F0120) F0120,--"TCH占用成功次数",

            --质差小区标签
            regexp_substr(EX.JTL_BADFLAG_2G_EXP,''[^-]+'',1,2,''i'') JTL_BADFLAG_2G_EXP,--"2G低接通质差小区",
            regexp_substr(EX.DXL_BADFLAG_2G_EXP,''[^-]+'',1,2,''i'') DXL_BADFLAG_2G_EXP,--"2G高掉话质差小区",

            PROVINCE ,--省份, 
            CITY ,--行政区,
            COUNTRY ,--优化分区, 
            FACTORY ,--厂家, 
            GRID ,--单元格, 
            COMPANY ,--区县分公司, 
            LOOP_LINE ,--环线,
            --RNC RNC, 
            PRE_FIELD1 ,--聚焦区域, 
            PRE_FIELD3 ,--基站类型, 
            LIFE ,--小区状态,
            PRE_FIELD4,
            PRE_FIELD5
            FROM
            (
              select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name||')--PARTITION(P_20190625)
              --where OID = "2180_14935" --测试用LIMIT取样
            )ZC
            left join
            (
              select 
              T3.oid, 
              --to_char(max(s_date),''yy'')||''/''||to_char(min(s_date),''mm'')||'': ''|| to_char(min(s_date),''dd'')||''~''||to_char(max(s_date),''dd'') DAYS_RANGE, 
              substr('||V_DATE_THRESHOLD_START||',3,2)||'': ''||to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''mm'')||''/''|| to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''dd'')||''~''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''mm'')||''/''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''dd'') DAYS_RANGE, --评估周级范围, --当前日期下的前7天
              case when sum(JTL_BADFLAG_2G_EXP) >=3 then ''1-是'' else ''0-否'' end JTL_BADFLAG_2G_EXP,
              case when sum(DXL_BADFLAG_2G_EXP) >=3 then ''1-是'' else ''0-否'' end DXL_BADFLAG_2G_EXP
              
              FROM
              (
                  select 
                  s_date, 
                  s_hour, 
                  T2.oid, 
                  jtl_badflag_2g*JTL_BADFLAG_2G_2 as JTL_BADFLAG_2G_EXP, 
                  dxl_badflag_2g*DXL_BADFLAG_2G_2 as DXL_BADFLAG_2G_EXP

                  from
                  (
                      select s_date, s_hour, T1.oid,

                      jtl_2g , jtl_badflag_2g ,--接通率小于95% 
                      dxl_2g ,dxl_badflag_2g ,--掉话率大于2%            
                      case when (F0014 > 20 and F0018>20) then 1 else 0 end JTL_BADFLAG_2G_2 ,--SDCCH请求次数>20 & TCH请求次数同时满足>20
                      case when F0026 > 5   then 1 else 0 end DXL_BADFLAG_2G_2,--掉话/掉线次数>5
                      F0014,--SDCCH请求次数
                      F0018--TCH请求次数同时满足
                      from
                      (
                          --分区模式                       
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_1||')
                           union all
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_2||')
                           union all
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_3||')
                           union all
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_4||')
                           union all
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_5||')
                           union all
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_6||')
                           union all
                           select * from ZC_CELL_LIST_2G PARTITION('||v_partition_name_7||')
                      )T1--当前日期前7天数据拼接
                  )T2--打二次标签，导出功能中的额外筛选条件！！！
              )T3--可以仅保留导出标签 & OID 两字段
              group by oid--统计各小区7日内导出标签为1的数量
            )EX
            ON ZC.OID = EX.OID
            WHERE
            (
                      regexp_substr(EX.JTL_BADFLAG_2G_EXP,''[^-]+'',1,1,''i'')
                   + regexp_substr(EX.DXL_BADFLAG_2G_EXP,''[^-]+'',1,1,''i'')
            )>0';
            commit;
            
            --入库数量判断
            select count(1) into v_insert_cnt from ZC_BAD_CELL_LIST_2G_DAY t 
            where t.s_date = v_date_start /*and t.s_date< v_date_end*/;
            
            --重复率判断
            select count(1) into v_insert_repeat from
            (
                   select count(1) from ZC_BAD_CELL_LIST_2G_DAY t 
                   where t.s_date  = v_date_start /*and t.s_date< v_date_end*/ 
                   group by t.oid having count(1)>1
            );
            dbms_output.put_line('表 ZC_BAD_CELL_LIST_2G_DAY 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
            ');

            
            
        END  PROC_ZC_BAD_CELL_LIST_2G;
        
  
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：ZC_CELL_LIST_3G
  --out：ZC_BAD_CELL_LIST_3G_DAY
  PROCEDURE PROC_ZC_BAD_CELL_LIST_3G(V_DATE_THRESHOLD_START VARCHAR2) IS
        v_date_start  date;
        v_date_end   date;
        v_partition_name_1   varchar2(15);--当前日期1天前的分区名
        v_partition_name_2   varchar2(15);--当前日期2天前的分区名
        v_partition_name_3   varchar2(15);--当前日期3天前的分区名
        v_partition_name_4   varchar2(15);--当前日期4天前的分区名
        v_partition_name_5   varchar2(15);--当前日期5天前的分区名
        v_partition_name_6   varchar2(15);--当前日期6天前的分区名
        v_partition_name_7   varchar2(15);--当前日期7天前的分区名
        
        --v_loop_log number := 0 ;
        v_insert_cnt   number;
        v_insert_repeat   number;
        v_partition_name varchar2(30);
        v_ssql varchar2(4000);
        v_clean_flag number;
        v_date_end_vc varchar2(10);
        
        BEGIN
            --起止时间戳格式化
            v_date_start := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd');--起始时间戳'yyyymmdd'格式化--2019/06/25
            v_date_end  := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd')-7;--2019/08/05
            
            --v_date_start_vc := to_char(v_date_start-1, 'yyyymmdd');--20190811
            v_date_end_vc := to_char(v_date_end, 'yyyymmdd');--20190805       
            
            --从系统中获取待插入分区名
            select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
            where t.table_name = 'ZC_BAD_CELL_LIST_3G_DAY' 
            and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
            and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
            --或拼接待插入分区名
            --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
            
            --PLUS7暂未部署
            --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_BAD_CELL_LIST_3G_DAY',v_date_start,v_date_start,'0','0');
            
            --分区数据清理
            /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_BAD_CELL_LIST_3G_DAY partition(' ||v_partition_name||');' into v_ssql from dual;
            execute immediate v_ssql;*/
            select count(1) into v_clean_flag from ZC_BAD_CELL_LIST_3G_DAY where s_date  = v_date_start /*and start_time  < v_date_end*/;
            while v_clean_flag != 0 loop
              /*execute immediate 'DELETE FROM ZC_BAD_CELL_LIST_3G_DAY PARTITION(' || v_partition_name||')';
              commit;*/
              select
              'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
              into v_ssql
              from FAST_DATA_PROCESS_TEMPLATE s
              where s.table_name = 'ZC_BAD_CELL_LIST_3G_DAY';
              execute immediate v_ssql;
              select count(1) into v_clean_flag from ZC_BAD_CELL_LIST_3G_DAY where s_date = v_date_start /*and start_time < v_date_end*/;
            end loop;
            --周期数据分区罗列
            --P_20190624-P_20190623-P_20190622-P_20190621-P_20190620-P_20190619-P_20190618
            v_partition_name_1 := 'P_'||to_char(v_date_start-1,'yyyymmdd');
            v_partition_name_2 := 'P_'||to_char(v_date_start-2,'yyyymmdd');
            v_partition_name_3 := 'P_'||to_char(v_date_start-3,'yyyymmdd');
            v_partition_name_4 := 'P_'||to_char(v_date_start-4,'yyyymmdd');
            v_partition_name_5 := 'P_'||to_char(v_date_start-5,'yyyymmdd');
            v_partition_name_6 := 'P_'||to_char(v_date_start-6,'yyyymmdd');
            v_partition_name_7 := 'P_'||to_char(v_date_start-7,'yyyymmdd');
            
            execute immediate'            
            insert into ZC_BAD_CELL_LIST_3G_DAY
            SELECT
            S_DATE ,--as 评估日期,
            DAYS_RANGE ,--as 评估周级范围, --当前日期下的前7天
            s_hour ,--as 忙时时间戳,
            LAC_ID, 
            CELL_ID, 
            ZC.LAC_CI,
            --1.同频切换 
            TPQH_3G ,--as "3G软切换成功率<98%", 
            --100*DECODE(n3_0016,0,null,n3_0015/n3_0016) 验证,
            trunc(n3_0015) n3_0015,--as "3G软切换成功次数",
            trunc(n3_0016)n3_0016 ,--as "3G软切换尝试次数>20",

            --2.重建
            CJL_3G ,--as "3G重建率>5%",
            --100*DECODE(n3_0008,0,null,n3_0007/n3_0008) 验证,
            trunc(n3_0007) n3_0007,--as "3G重建率-分子",
            trunc(n3_0008) n3_0008,--as "3G重建率-分母>20",

            --3.接通
            JTL_3G ,--as "3G接通率<95%", 
            --100*DECODE(n3_0002*n3_0004,0,null,n3_0001*n3_0003/(n3_0002*n3_0004)) 验证,
            trunc(n3_0001)n3_0001,-- "RRC连接建立完成次数",
            trunc(n3_0002)n3_0002,--"RRC连接请求次数>20",
            trunc(n3_0003)n3_0003,-- "RAB建立成功总次数",
            trunc(n3_0004)n3_0004,-- "RAB建立尝试总次数",

            --4.掉话
            DXL_3G ,--as "3G掉话率>2%", 
            --100*DECODE(n3_0006,0,null,n3_0005/n3_0006) 验证,
            trunc(n3_0005)n3_0005,--as "CS掉话次数",
            trunc(n3_0006)n3_0006,--as "CS释放次数",

            --5.上行干扰RTWP
            RTWP_3G ,--as "3G上行干扰均值>-95(天级)" , 

            --6.RSRP
            RSRP_3G ,--as "3G RSCP<-95的比例>30%(天级)",
            --100*DECODE(RFG_BADFLAG_3G_DEN,0,NULL,RFG_BADFLAG_3G_NUM/RFG_BADFLAG_3G_DEN) 验证,
            RFG_BADFLAG_3G_NUM ,--"3GMR RSCP<-95 采样点数(天级)",
            RFG_BADFLAG_3G_DEN  ,--"3GMR 总采样点数(天级)"
            
            
            --7.ECIO
            ECIO_3G ,--as "3G ECIO<-12的比例>30%(天级)",
            --100*DECODE(ECIO_BADFLAG_3G_DEN,0,NULL,ECIO_BADFLAG_3G_NUM/ECIO_BADFLAG_3G_DEN) 验证,
            ECIO_BADFLAG_3G_NUM,-- "3GMR ECIO<-12 采样点数(天级)",
            ECIO_BADFLAG_3G_DEN ,-- "3GMR ECIO 总采样点数(天级)",


            --质差小区标签
            regexp_substr(EX.TPQH_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'') TPQH_BADFLAG_3G_EXP,--"3G同频切换质差小区",
            regexp_substr(EX.CJL_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'') CJL_BADFLAG_3G_EXP,--"3G高重建率质差小区",
            regexp_substr(EX.JTL_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'') JTL_BADFLAG_3G_EXP,--"3G低接通质差小区 ",
            regexp_substr(EX.DXL_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'') DXL_BADFLAG_3G_EXP,--"3G高掉话质差小区 ", 
            regexp_substr(EX.RTWP_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'')RTWP_BADFLAG_3G_EXP,-- "3G高上行干扰质差小区", 
            regexp_substr(EX.RSRP_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'')RSRP_BADFLAG_3G_EXP,-- "3GMR弱覆盖小区",
            regexp_substr(EX.ECIO_BADFLAG_3G_EXP,''[^-]+'',1,2,''i'')ECIO_BADFLAG_3G_EXP,-- "3GECIO质差小区",


            PROVINCE ,--省份, 
            CITY ,--行政区,
            COUNTRY ,--优化分区, 
            FACTORY ,--厂家, 
            GRID ,--单元格, 
            COMPANY,-- 区县分公司, 
            LOOP_LINE,-- 环线,
            RNC RNC,
            PRE_FIELD1 ,--聚焦区域, 
            PRE_FIELD2 ,--基站类型, 
            LIFE, --小区状态,
            AVG_RSRP_BADFLAG_3G_DEN_7,--"7天 3GMR 平均采样点数 >1000",
            SUM_RSRP_BADFLAG_3G_NUM_7,--"7天 3GMR RSCP<-95 采样点数"
            SUM_RSRP_BADFLAG_3G_DEN_7,--"7天 3GMR 总采样点数"
            AVG_ECIO_BADFLAG_3G_DEN_7,--"7天3GMR ECIO 平均采样点数>1000"
            SUM_ECIO_BADFLAG_3G_NUM_7,--"7天3GMR ECIO<-12 采样点数"
            SUM_ECIO_BADFLAG_3G_DEN_7--"7天3GMR ECIO 总采样点数"        

            FROM
            (
              select t.*, 
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
              MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+
              MR_COUNT_RSCP_5+MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+
              MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+
              MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+MR_COUNT_RSCP_18+MR_COUNT_RSCP_19) as RFG_BADFLAG_3G_NUM,--天级别指标，3GMR弱覆盖小区分子
               
               
              (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
               MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+MR_COUNT_RSCP_5+
               MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+
               MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+
               MR_COUNT_RSCP_18+MR_COUNT_RSCP_19+MR_COUNT_RSCP_20+MR_COUNT_RSCP_21+MR_COUNT_RSCP_22+MR_COUNT_RSCP_23+
               MR_COUNT_RSCP_24+MR_COUNT_RSCP_25+MR_COUNT_RSCP_26+MR_COUNT_RSCP_27+MR_COUNT_RSCP_28+MR_COUNT_RSCP_29+
               MR_COUNT_RSCP_30+MR_COUNT_RSCP_31+MR_COUNT_RSCP_32+MR_COUNT_RSCP_33+MR_COUNT_RSCP_34+MR_COUNT_RSCP_35+
               MR_COUNT_RSCP_36+MR_COUNT_RSCP_37+MR_COUNT_RSCP_38+MR_COUNT_RSCP_39+MR_COUNT_RSCP_40+MR_COUNT_RSCP_41+
               MR_COUNT_RSCP_42+MR_COUNT_RSCP_43+MR_COUNT_RSCP_44+MR_COUNT_RSCP_45+MR_COUNT_RSCP_46+MR_COUNT_RSCP_47+
               MR_COUNT_RSCP_48+MR_COUNT_RSCP_49+MR_COUNT_RSCP_50+MR_COUNT_RSCP_51+MR_COUNT_RSCP_52+MR_COUNT_RSCP_53+
               MR_COUNT_RSCP_54+MR_COUNT_RSCP_55+MR_COUNT_RSCP_56+MR_COUNT_RSCP_57+MR_COUNT_RSCP_58+MR_COUNT_RSCP_59+
               MR_COUNT_RSCP_60+MR_COUNT_RSCP_61+MR_COUNT_RSCP_62+MR_COUNT_RSCP_63+MR_COUNT_RSCP_64+MR_COUNT_RSCP_65+
               MR_COUNT_RSCP_66+MR_COUNT_RSCP_67+MR_COUNT_RSCP_68+MR_COUNT_RSCP_69+MR_COUNT_RSCP_70+MR_COUNT_RSCP_71+
               MR_COUNT_RSCP_72+MR_COUNT_RSCP_73+MR_COUNT_RSCP_74+MR_COUNT_RSCP_75+MR_COUNT_RSCP_76+MR_COUNT_RSCP_77+
               MR_COUNT_RSCP_78+MR_COUNT_RSCP_79+MR_COUNT_RSCP_80+MR_COUNT_RSCP_81+MR_COUNT_RSCP_82+MR_COUNT_RSCP_83+
               MR_COUNT_RSCP_84+MR_COUNT_RSCP_85+MR_COUNT_RSCP_86+MR_COUNT_RSCP_87+MR_COUNT_RSCP_88+MR_COUNT_RSCP_89+
               MR_COUNT_RSCP_90+MR_COUNT_RSCP_91) as RFG_BADFLAG_3G_DEN,--天级别指标，3GMR弱覆盖小区分母
               
              (MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+MR_COUNT_ECNO_6+
               MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+
               MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+
               MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+MR_COUNT_ECNO_24) as ECIO_BADFLAG_3G_NUM,--天级别指标，3GMR质差小区分子
                
              (MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+
               MR_COUNT_ECNO_6+MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+
               MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+
               MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+
               MR_COUNT_ECNO_24+MR_COUNT_ECNO_25+MR_COUNT_ECNO_26+MR_COUNT_ECNO_27+MR_COUNT_ECNO_28+MR_COUNT_ECNO_29+
               MR_COUNT_ECNO_30+MR_COUNT_ECNO_31+MR_COUNT_ECNO_32+MR_COUNT_ECNO_33+MR_COUNT_ECNO_34+MR_COUNT_ECNO_35+
               MR_COUNT_ECNO_36+MR_COUNT_ECNO_37+MR_COUNT_ECNO_38+MR_COUNT_ECNO_39+MR_COUNT_ECNO_40+MR_COUNT_ECNO_41+
               MR_COUNT_ECNO_42+MR_COUNT_ECNO_43+MR_COUNT_ECNO_44+MR_COUNT_ECNO_45+MR_COUNT_ECNO_46+MR_COUNT_ECNO_47+
               MR_COUNT_ECNO_48+MR_COUNT_ECNO_49) as ECIO_BADFLAG_3G_DEN--天级别指标，3GMR质差小区分母
              from ZC_CELL_LIST_3G PARTITION('||v_partition_name||')t
              --and lac_ci = ''43010-11581'' --测试用LIMIT取样
            )ZC
            left join
            (
              select 
              LAC_CI, 
              substr('||V_DATE_THRESHOLD_START||',3,2)||'': ''||to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''mm'')||''/''|| to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''dd'')||''~''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''mm'')||''/''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''dd'') DAYS_RANGE, --评估周级范围, --当前日期下的前7天
              case when sum(TPQH_BADFLAG_3G_EXP)>=3 then ''1-是'' else ''0-否'' end TPQH_BADFLAG_3G_EXP,
              case when sum(CJL_BADFLAG_3G_EXP)   >=3 then ''1-是'' else ''0-否'' end CJL_BADFLAG_3G_EXP,
              case when sum(JTL_BADFLAG_3G_EXP)    >=3 then ''1-是'' else ''0-否'' end JTL_BADFLAG_3G_EXP,
              case when sum(DXL_BADFLAG_3G_EXP)   >=3 then ''1-是'' else ''0-否'' end DXL_BADFLAG_3G_EXP,
              case when avg(RTWP_3G)                      >-95 then ''1-是'' else ''0-否'' end RTWP_BADFLAG_3G_EXP,
              case when avg(RSRP_BADFLAG_3G_DEN)>1000 --7日日均采样点大于1000
                and decode(sum(RSRP_BADFLAG_3G_DEN),0,null,null,null,round(sum(RSRP_BADFLAG_3G_NUM)/sum(RSRP_BADFLAG_3G_DEN),2) )>0.3--7日内RSRP<-110的比例>30%
                then ''1-是'' else ''0-否'' end RSRP_BADFLAG_3G_EXP,
              case when avg(ECIO_BADFLAG_3G_DEN)>1000 --7日日均采样点大于1000
                and decode(sum(ECIO_BADFLAG_3G_DEN),0,null,null,null,round(sum(ECIO_BADFLAG_3G_NUM)/sum(ECIO_BADFLAG_3G_DEN),2) )>0.3--7日内ECIO<-12的比例>30%
                then ''1-是'' else ''0-否'' end ECIO_BADFLAG_3G_EXP,
                  
              round(avg(RSRP_BADFLAG_3G_DEN) ,2)AVG_RSRP_BADFLAG_3G_DEN_7,
              sum(RSRP_BADFLAG_3G_NUM) SUM_RSRP_BADFLAG_3G_NUM_7,
              sum(RSRP_BADFLAG_3G_DEN) SUM_RSRP_BADFLAG_3G_DEN_7,
              round(avg(ECIO_BADFLAG_3G_DEN),2) AVG_ECIO_BADFLAG_3G_DEN_7,
              sum(ECIO_BADFLAG_3G_NUM) SUM_ECIO_BADFLAG_3G_NUM_7,
              sum(ECIO_BADFLAG_3G_DEN) SUM_ECIO_BADFLAG_3G_DEN_7   
                
              FROM
              (
                  select 
                  s_date, 
                  s_hour, 
                  lac_ci, 
                  tpqh_badflag_3g*TPQH_BADFLAG_3G_2 as TPQH_BADFLAG_3G_EXP,--''同频切换出请求次数>20，同频切换出成功率<95%''
                  cjl_badflag_3g*CJL_BADFLAG_3G_2 as CJL_BADFLAG_3G_EXP,--''重建次数>20，重建率大于5%''
                  jtl_badflag_3g*JTL_BADFLAG_3G_2 as JTL_BADFLAG_3G_EXP, --''接通率小于95% RRC请求次数大于20次''
                  dxl_badflag_3g*DXL_BADFLAG_3G_2 as DXL_BADFLAG_3G_EXP,--''掉话率大于2% 掉话次数大于5次''
                  RTWP_3G,--上行干扰均值，一周的均值>-95的小区，即天级 N3_0014，该字段非忙时指标 
                  --N3_0014, --即 RTWP_3G 
                  n3_0016,--同频切换出请求次数
                  n3_0008,--重建次数
                  n3_0002,--RRC请求次数
                  n3_0005,--掉话/掉线次数
                  --n3_0014,--即 RTWP_3G
                  RSRP_BADFLAG_3G_NUM,--天级别指标，3GMR弱覆盖小区分子 
                  RSRP_BADFLAG_3G_DEN,--天级别指标，3GMR弱覆盖小区分母 
                  ECIO_BADFLAG_3G_NUM,--天级别指标，3GMR质差小区分子     
                  ECIO_BADFLAG_3G_DEN--天级别指标，3GMR质差小区分母      
                  from
                  (
                      select s_date, s_hour, lac_id, cell_id, lac_ci,
                      tpqh_3g , tpqh_badflag_3g , --软切换成功率<98%的小区
                      cjl_3g , cjl_badflag_3g ,--重建率大于5%  
                      ecio_3g , ecio_badflag_3g ,--ecio<-12db比例大于30%小区占比  
                      jtl_3g, jtl_badflag_3g,--接通率小于95% 
                      dxl_3g,dxl_badflag_3g,--掉话率大于2%  
                      RTWP_3G, rtwp_badflag_3g,--n3_0014，小区每天的rtwp>-95的小区，天表内的 N3_0014，非忙时字段 
                      rsrp_3g, rsrp_badflag_3g,--3G-mr rscp<-110比例大于30%小区占比   
                      case when n3_0016>20 then 1 else 0 end TPQH_BADFLAG_3G_2, --同频切换出请求次数>20
                      case when n3_0008>20 then 1 else 0 end CJL_BADFLAG_3G_2, --重建次数>20
                      case when n3_0002>20 then 1 else 0 end JTL_BADFLAG_3G_2, --RRC请求次数>20
                      case when n3_0005>5   then 1 else 0 end DXL_BADFLAG_3G_2,--掉话/掉线次数>5
                      n3_0016,--同频切换出请求次数
                      n3_0008,--重建次数
                      n3_0002,--RRC请求次数
                      n3_0005,--掉话/掉线次数
                      --n3_0014,--即 RTWP_3G
                      (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
                      MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+
                      MR_COUNT_RSCP_5+MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+
                      MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+
                      MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+MR_COUNT_RSCP_18+MR_COUNT_RSCP_19) as RSRP_BADFLAG_3G_NUM,--天级别指标，3GMR弱覆盖小区分子
                      
                      (MR_COUNT_RSCP_N5+MR_COUNT_RSCP_N4+MR_COUNT_RSCP_N3+MR_COUNT_RSCP_N2+MR_COUNT_RSCP_N1+
                      MR_COUNT_RSCP_0+MR_COUNT_RSCP_1+MR_COUNT_RSCP_2+MR_COUNT_RSCP_3+MR_COUNT_RSCP_4+MR_COUNT_RSCP_5+
                      MR_COUNT_RSCP_6+MR_COUNT_RSCP_7+MR_COUNT_RSCP_8+MR_COUNT_RSCP_9+MR_COUNT_RSCP_10+MR_COUNT_RSCP_11+
                      MR_COUNT_RSCP_12+MR_COUNT_RSCP_13+MR_COUNT_RSCP_14+MR_COUNT_RSCP_15+MR_COUNT_RSCP_16+MR_COUNT_RSCP_17+
                      MR_COUNT_RSCP_18+MR_COUNT_RSCP_19+MR_COUNT_RSCP_20+MR_COUNT_RSCP_21+MR_COUNT_RSCP_22+MR_COUNT_RSCP_23+
                      MR_COUNT_RSCP_24+MR_COUNT_RSCP_25+MR_COUNT_RSCP_26+MR_COUNT_RSCP_27+MR_COUNT_RSCP_28+MR_COUNT_RSCP_29+
                      MR_COUNT_RSCP_30+MR_COUNT_RSCP_31+MR_COUNT_RSCP_32+MR_COUNT_RSCP_33+MR_COUNT_RSCP_34+MR_COUNT_RSCP_35+
                      MR_COUNT_RSCP_36+MR_COUNT_RSCP_37+MR_COUNT_RSCP_38+MR_COUNT_RSCP_39+MR_COUNT_RSCP_40+MR_COUNT_RSCP_41+
                      MR_COUNT_RSCP_42+MR_COUNT_RSCP_43+MR_COUNT_RSCP_44+MR_COUNT_RSCP_45+MR_COUNT_RSCP_46+MR_COUNT_RSCP_47+
                      MR_COUNT_RSCP_48+MR_COUNT_RSCP_49+MR_COUNT_RSCP_50+MR_COUNT_RSCP_51+MR_COUNT_RSCP_52+MR_COUNT_RSCP_53+
                      MR_COUNT_RSCP_54+MR_COUNT_RSCP_55+MR_COUNT_RSCP_56+MR_COUNT_RSCP_57+MR_COUNT_RSCP_58+MR_COUNT_RSCP_59+
                      MR_COUNT_RSCP_60+MR_COUNT_RSCP_61+MR_COUNT_RSCP_62+MR_COUNT_RSCP_63+MR_COUNT_RSCP_64+MR_COUNT_RSCP_65+
                      MR_COUNT_RSCP_66+MR_COUNT_RSCP_67+MR_COUNT_RSCP_68+MR_COUNT_RSCP_69+MR_COUNT_RSCP_70+MR_COUNT_RSCP_71+
                      MR_COUNT_RSCP_72+MR_COUNT_RSCP_73+MR_COUNT_RSCP_74+MR_COUNT_RSCP_75+MR_COUNT_RSCP_76+MR_COUNT_RSCP_77+
                      MR_COUNT_RSCP_78+MR_COUNT_RSCP_79+MR_COUNT_RSCP_80+MR_COUNT_RSCP_81+MR_COUNT_RSCP_82+MR_COUNT_RSCP_83+
                      MR_COUNT_RSCP_84+MR_COUNT_RSCP_85+MR_COUNT_RSCP_86+MR_COUNT_RSCP_87+MR_COUNT_RSCP_88+MR_COUNT_RSCP_89+
                      MR_COUNT_RSCP_90+MR_COUNT_RSCP_91) as RSRP_BADFLAG_3G_DEN,--天级别指标，3GMR弱覆盖小区分母
                      
                      (MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+MR_COUNT_ECNO_6+
                      MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+
                      MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+
                      MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+MR_COUNT_ECNO_24) as ECIO_BADFLAG_3G_NUM,--天级别指标，3GMR质差小区分子
                      
                      (MR_COUNT_ECNO_0+MR_COUNT_ECNO_1+MR_COUNT_ECNO_2+MR_COUNT_ECNO_3+MR_COUNT_ECNO_4+MR_COUNT_ECNO_5+
                      MR_COUNT_ECNO_6+MR_COUNT_ECNO_7+MR_COUNT_ECNO_8+MR_COUNT_ECNO_9+MR_COUNT_ECNO_10+MR_COUNT_ECNO_11+
                      MR_COUNT_ECNO_12+MR_COUNT_ECNO_13+MR_COUNT_ECNO_14+MR_COUNT_ECNO_15+MR_COUNT_ECNO_16+MR_COUNT_ECNO_17+
                      MR_COUNT_ECNO_18+MR_COUNT_ECNO_19+MR_COUNT_ECNO_20+MR_COUNT_ECNO_21+MR_COUNT_ECNO_22+MR_COUNT_ECNO_23+
                      MR_COUNT_ECNO_24+MR_COUNT_ECNO_25+MR_COUNT_ECNO_26+MR_COUNT_ECNO_27+MR_COUNT_ECNO_28+MR_COUNT_ECNO_29+
                      MR_COUNT_ECNO_30+MR_COUNT_ECNO_31+MR_COUNT_ECNO_32+MR_COUNT_ECNO_33+MR_COUNT_ECNO_34+MR_COUNT_ECNO_35+
                      MR_COUNT_ECNO_36+MR_COUNT_ECNO_37+MR_COUNT_ECNO_38+MR_COUNT_ECNO_39+MR_COUNT_ECNO_40+MR_COUNT_ECNO_41+
                      MR_COUNT_ECNO_42+MR_COUNT_ECNO_43+MR_COUNT_ECNO_44+MR_COUNT_ECNO_45+MR_COUNT_ECNO_46+MR_COUNT_ECNO_47+
                      MR_COUNT_ECNO_48+MR_COUNT_ECNO_49) as ECIO_BADFLAG_3G_DEN--天级别指标，3GMR质差小区分母
                      from
                      --select * from
                      (
                          --分区模式
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_1||')
                           union all
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_2||')
                           union all
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_3||')
                           union all
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_4||')
                           union all
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_5||')
                           union all
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_6||')
                           union all
                           select * from ZC_CELL_LIST_3G PARTITION('||v_partition_name_7||')
                      )T1--当前日期前7天数据拼接
                      --where lac_ci = ''43010-11581'' --测试用LIMIT取样
                  )T2--打二次标签，导出功能中的额外筛选条件！！！
              )T3--可以仅保留导出标签 & LAC_CI 两字段
              group by lac_ci--统计各小区7日内导出标签为1的数量
            )EX
            ON ZC.LAC_CI = EX.LAC_CI
            WHERE 
            (
                   regexp_substr(EX.TPQH_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.CJL_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.JTL_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.DXL_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.RTWP_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.RSRP_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.ECIO_BADFLAG_3G_EXP,''[^-]+'',1,1,''i'')
            )>0';
            commit;
            
            --针对某些小区去重，大约2个小区
            execute immediate'
            delete from ZC_BAD_CELL_LIST_3G_DAY
            where rowid in
            (
                select rowid from
                (
                   select row_number() over(partition by s_date, days_range, lac_ci 
                   order by a.lac_ci desc)seq, a.*
                   from ZC_BAD_CELL_LIST_3G_DAY PARTITION('||v_partition_name||') a
                   where a.lac_ci in
                   (
                      select lac_ci
                      from ZC_BAD_CELL_LIST_3G_DAY PARTITION('||v_partition_name||') t
                      group by s_date, days_range, lac_ci
                      having count(*) > 1
                   )
                )x
                where x.seq <>1
            )';
            commit;
                
            --入库数量判断
            select count(1) into v_insert_cnt from ZC_BAD_CELL_LIST_3G_DAY t 
            where t.s_date = v_date_start /*and t.s_date< v_date_end*/;
            
            --重复率判断
            select count(1) into v_insert_repeat from
            (
                   select count(1) from ZC_BAD_CELL_LIST_3G_DAY t 
                   where t.s_date  = v_date_start /*and t.s_date< v_date_end*/ 
                   group by t.lac_ci having count(1)>1
            );
            dbms_output.put_line('表 ZC_BAD_CELL_LIST_3G_DAY 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
            ');

         
            
        END  PROC_ZC_BAD_CELL_LIST_3G;
        
        
  
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：ZC_CELL_LIST_4G
  --out：ZC_BAD_CELL_LIST_4G_DAY
  PROCEDURE PROC_ZC_BAD_CELL_LIST_4G(V_DATE_THRESHOLD_START VARCHAR2) IS

        v_date_start  date;
        v_date_end   date;
        v_partition_name_1   varchar2(15);--当前日期1天前的分区名
        v_partition_name_2   varchar2(15);--当前日期2天前的分区名
        v_partition_name_3   varchar2(15);--当前日期3天前的分区名
        v_partition_name_4   varchar2(15);--当前日期4天前的分区名
        v_partition_name_5   varchar2(15);--当前日期5天前的分区名
        v_partition_name_6   varchar2(15);--当前日期6天前的分区名
        v_partition_name_7   varchar2(15);--当前日期7天前的分区名
        
        --v_loop_log number := 0 ;
        v_insert_cnt   number;
        v_insert_repeat   number;
        v_partition_name varchar2(30);
        v_ssql varchar2(4000);
        v_clean_flag number;
        v_date_end_vc varchar2(10);
        
        BEGIN
            --起止时间戳格式化
            v_date_start := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd');--起始时间戳'yyyymmdd'格式化--2019/06/25
            v_date_end  := to_date(V_DATE_THRESHOLD_START, 'yyyymmdd')-7;--2019/08/05
            
            --v_date_start_vc := to_char(v_date_start-1, 'yyyymmdd');--20190811
            v_date_end_vc := to_char(v_date_end, 'yyyymmdd');--20190805    
            
            --从系统中获取待插入分区名
            select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
            where t.table_name = 'ZC_BAD_CELL_LIST_4G_DAY' 
            and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
            and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
            --或拼接待插入分区名
            --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
            
            --PLUS7暂未部署
            --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','ZC_BAD_CELL_LIST_4G_DAY',v_date_start,v_date_start,'0','0');
            
            --分区数据清理
            /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from ZC_BAD_CELL_LIST_4G_DAY partition(' ||v_partition_name||');' into v_ssql from dual;
            execute immediate v_ssql;*/
            select count(1) into v_clean_flag from ZC_BAD_CELL_LIST_4G_DAY where s_date  = v_date_start /*and start_time  < v_date_end*/;
            while v_clean_flag != 0 loop
              /*execute immediate 'DELETE FROM ZC_BAD_CELL_LIST_4G_DAY PARTITION(' || v_partition_name||')';
              commit;*/
              select
              'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
              into v_ssql
              from FAST_DATA_PROCESS_TEMPLATE s
              where s.table_name = 'ZC_BAD_CELL_LIST_4G_DAY';
              execute immediate v_ssql;
              select count(1) into v_clean_flag from ZC_BAD_CELL_LIST_4G_DAY where s_date = v_date_start /*and start_time < v_date_end*/;
            end loop;
            --周期数据分区罗列
            --P_20190624-P_20190623-P_20190622-P_20190621-P_20190620-P_20190619-P_20190618
            v_partition_name_1 := 'P_'||to_char(v_date_start-1,'yyyymmdd');
            v_partition_name_2 := 'P_'||to_char(v_date_start-2,'yyyymmdd');
            v_partition_name_3 := 'P_'||to_char(v_date_start-3,'yyyymmdd');
            v_partition_name_4 := 'P_'||to_char(v_date_start-4,'yyyymmdd');
            v_partition_name_5 := 'P_'||to_char(v_date_start-5,'yyyymmdd');
            v_partition_name_6 := 'P_'||to_char(v_date_start-6,'yyyymmdd');
            v_partition_name_7 := 'P_'||to_char(v_date_start-7,'yyyymmdd');
            
            execute immediate'
            insert into ZC_BAD_CELL_LIST_4G_DAY
            select
            ZC.S_DATE ,--as 评估日期,
            EX.DAYS_RANGE ,--as 评估周级范围, --当前日期下的前7天
            s_hour ,--as 忙时时间戳, 
            ZC.ECGI ,--as ECGI,

            --1.同频切换
            tpqh_4g ,--as "4G同频切换成功率<95%", 
            --100*DECODE(n4_0042,0,null,n4_0041/n4_0042) 验证,
            n4_0041 ,--as "4G同频切换成功率-分子",
            n4_0042 ,--as "4G同频切换成功率-分母>20",

            --2.CQI
            cqi_4g ,--as "CQI≤6比例 >20%",
            --100*DECODE(CQI_BADFLAG_4G_DEN,0,NULL,CQI_BADFLAG_4G_NUM/CQI_BADFLAG_4G_DEN) 验证,
            CQI_BADFLAG_4G_NUM,-- "CQI 0~6数量",
            CQI_BADFLAG_4G_DEN,--  "CQI 0~15数量>20",

            --3.下行感知
            xxgzsl_4g ,--as "4G单用户下行感知速率<5M", 
            --DECODE(n4_0031,0,NULL,n4_0030*1024*1024/1000/1000/n4_0031) 验证,
            n4_0030 ,--as "4G下行去尾速率-分子",
            n4_0031 ,--as "4G下行去尾速率-分母", --n4_0030/n4_0031 = n4_0032

            --4.接通
            jtl_4g,-- "4G接通率<90%",
            --100*DECODE(n4_0002*n4_0004,0,null,n4_0001*n4_0003/(n4_0002*n4_0004)) 验证,
            n4_0001,-- "RRC连接建立完成次数",
            n4_0002,-- "RRC连接请求次数>20",
            n4_0003,-- "E-RAB建立成功总次数",
            n4_0004,-- "E-RAB建立尝试总次数",

            --5.掉话
            dxl_4g,-- "4G掉话率>2%", 
            --100*DECODE(n4_0006,0,null,n4_0005/n4_0006) 验证,
            n4_0005,-- "E-RAB异常释放总次数>5",
            n4_0006,-- "E-RAB释放总次数",

            --6.CSFB
            csfb_4g,-- "CSFB成功率<95%",
            --100*DECODE(n4_0024,0,null,n4_0023/n4_0024) 验证,
            n4_0023,-- "CSFB回落成功次数", 
            n4_0024,-- "CSFB回落请求次数>20",

            --7.PRB
            prb_4g,-- "4G上行干扰均值>-95(天级)", 
            --DECODE(n4_0047*n4_0049,0,null,n4_0046/n4_0047-n4_0048/n4_0049) 验证,
            --n4_0046"7-1.N4_0046(天级)", 
            --n4_0047"7-2.N4_0047(天级)", 
            --n4_0048"7-3.N4_0048(天级)", 
            --n4_0049"7-4.N4_0049(天级)", --PRB底噪相关
            
            --8.RSRP
            rsrp_4g ,--as "4G RSRP<-110的比例>30%(天级)", 
            --100*DECODE(RFG_BADFLAG_4G_DEN,0,NULL,RFG_BADFLAG_4G_NUM/RFG_BADFLAG_4G_DEN) 验证,
            RFG_BADFLAG_4G_NUM,-- "4GMR RSRP<-110 采样点数",
            RFG_BADFLAG_4G_DEN,--  "4GMR 总采样点数",
            
            --质差小区标签
            regexp_substr(EX.TPQH_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'')TPQH_BADFLAG_4G_EXP,-- "4G同频切换质差小区",
            regexp_substr(EX.CQI_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'') CQI_BADFLAG_4G_EXP,--"CQI质差小区",
            regexp_substr(EX.XXGZSL_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'') XXGZSL_BADFLAG_4G_EXP,--"4G单用户下行感知速率质差小区 ",
            regexp_substr(EX.JTL_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'') JTL_BADFLAG_4G_EXP,--"4G低接通质差小区 ", 
            regexp_substr(EX.DXL_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'') DXL_BADFLAG_4G_EXP,--"4G高掉话质差小区", 
            regexp_substr(EX.CSFB_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'') CSFB_BADFLAG_4G_EXP,--"CSFB成功率低质差小区",
            regexp_substr(EX.PRB_4G_EXP,''[^-]+'',1,2,''i'') PRB_4G_EXP,--"4G高干扰质差小区", 
            regexp_substr(EX.RFG_BADFLAG_4G_EXP,''[^-]+'',1,2,''i'') RFG_BADFLAG_4G_EXP,--"4GMR弱覆盖小区",
            
            province ,--省份 , 
            vendor_cell_id ,--行政区 , 
            county ,--优化分区 , 
            decode(vendor_id,null,null, 1,''华为'',4,''中兴'', ''诺基亚'') vendor_id,--厂家 , 
            reserved3 ,--单元格 , 
            reserved8 ,--区县分公司 , 
            town_id ,--环线 , 
            rnc, 
            reserved4 ,--聚焦区域 , 
            reserved5 ,--频段 , 
            cover_type ,--基站类型 ,
            life, --小区状态,
            AVG_RFG_BADFLAG_4G_DEN_7,--"7天 4GMR 平均采样点数 >10000"
            SUM_RFG_BADFLAG_4G_NUM_7,--"7天 4GMR RSRP<-110 采样点数"
            SUM_RFG_BADFLAG_4G_DEN_7--"7天 4GMR RSRP 总采样点数"
            FROM
            (
                select t.*, 
                (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013) as CQI_BADFLAG_4G_NUM,
                (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013+n4_0014+n4_0015+n4_0016+n4_0017+n4_0018+n4_0019+n4_0020+n4_0021+n4_0022) as CQI_BADFLAG_4G_DEN
                from ZC_CELL_LIST_4G PARTITION('||v_partition_name||') t
                --and ecgi = 8390411 --测试用LIMIT取样
            )ZC
            left join
            (
                select 
                ECGI, 
                substr('||V_DATE_THRESHOLD_START||',3,2)||'': ''||to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''mm'')||''/''|| to_char(to_date('||v_date_end_vc||',''yyyymmdd''),''dd'')||''~''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''mm'')||''/''||to_char(to_date('||V_DATE_THRESHOLD_START||',''yyyymmdd'')-1,''dd'') DAYS_RANGE, --评估周级范围, --当前日期下的前7天
                case when sum(TPQH_BADFLAG_4G_EXP)  >=3   then  ''1-是''  else  ''0-否''  end TPQH_BADFLAG_4G_EXP,
                case when sum(CQI_BADFLAG_4G_EXP)   >=3   then  ''1-是'' else  ''0-否''  end CQI_BADFLAG_4G_EXP,
                case when avg(N4_0032)              <5    then  ''1-是''  else  ''0-否''  end XXGZSL_BADFLAG_4G_EXP,
                case when sum(JTL_BADFLAG_4G_EXP)   >=3   then  ''1-是''  else  ''0-否''  end JTL_BADFLAG_4G_EXP,
                case when sum(DXL_BADFLAG_4G_EXP)   >=3   then  ''1-是''  else  ''0-否''  end DXL_BADFLAG_4G_EXP,
                case when sum(CSFB_BADFLAG_4G_EXP)  >=3   then  ''1-是''  else  ''0-否''  end CSFB_BADFLAG_4G_EXP,
                case when avg(PRB_4G)               >-95  then  ''1-是''  else  ''0-否''  end PRB_4G_EXP,
                case when avg(RFG_BADFLAG_4G_DEN)>10000 --7日日均采样点大于1000
                  and decode(sum(RFG_BADFLAG_4G_DEN),0,null,null,null,round(sum(RFG_BADFLAG_4G_NUM)/sum(RFG_BADFLAG_4G_DEN),2) )>0.3--7日内RSRP<-110的比例>30%
                  then ''1-是'' else ''0-否'' end RFG_BADFLAG_4G_EXP,
                round(avg(RFG_BADFLAG_4G_DEN) ,2)AVG_RFG_BADFLAG_4G_DEN_7,
                sum(RFG_BADFLAG_4G_NUM) SUM_RFG_BADFLAG_4G_NUM_7,
                sum(RFG_BADFLAG_4G_DEN) SUM_RFG_BADFLAG_4G_DEN_7
                    
                --case when sum(TPQH_BADFLAG_4G_EXP)>=3 then ''1-是'' else ''0-否'' end TPQH_BADFLAG_4G_EXP_1,
                
                FROM
                (
                    select 
                    s_date, 
                    s_hour, 
                    ecgi, 
                    tpqh_badflag_4g*TPQH_BADFLAG_4G_2 TPQH_BADFLAG_4G_EXP,
                    cqi_badflag_4g*CQI_BADFLAG_4G_2 CQI_BADFLAG_4G_EXP,
                    N4_0032,
                    jtl_badflag_4g*JTL_BADFLAG_4G_2 JTL_BADFLAG_4G_EXP,
                    dxl_badflag_4g*DXL_BADFLAG_4G_2 DXL_BADFLAG_4G_EXP,
                    csfb_badflag_4g*CSFB_BADFLAG_4G_2 CSFB_BADFLAG_4G_EXP,
                    PRB_4G,--PRB底噪，一周的均值>-95的小区，即天级N4_0033 
                    --N4_0033, --即 PRB_4G 
                    --n4_0041, 
                    n4_0042, --同频切换出请求次数>20
                    n4_0030,n4_0031, --n4_0030/n4_0031 = n4_0032
                    n4_0002, --RRC请求次数>20
                    n4_0005, --掉话/掉线次数>5
                    n4_0024 --CSFB请求次数>20,
                    n4_0046, n4_0047, n4_0048, n4_0049, --PRB底噪相关
                    RFG_BADFLAG_4G_NUM,--天级别指标，4GMR弱覆盖小区分子 
                    RFG_BADFLAG_4G_DEN--天级别指标，4GMR弱覆盖小区分母 
                    from
                    (
                        select s_date, s_hour, ecgi, 
                        tpqh_4g, tpqh_badflag_4g, --4g同频切换质差小区
                        cqi_4g, cqi_badflag_4g,--cqi质差小区 
                        xxgzsl_4g, xxgzsl_badflag_4g,--单用户下行感知速率质差小区 
                        jtl_4g, jtl_badflag_4g, --4g低接通质差小区 
                        dxl_4g, dxl_badflag_4g, --掉话率>2 
                        csfb_4g, csfb_badflag_4g, --csfb成功率低质差小区 
                        prb_4g, h_jam_badflag_4g, --4g高干扰质差小区 
                        rsrp_4g, rfg_badflag_4g, --4gmr弱覆盖小区 
                        case when n4_0042 > 20  then  1 else  0 end TPQH_BADFLAG_4G_2, --同频切换出请求次数>20
                        case when (n4_0007+n4_0008+n4_0009+n4_0010+n4_0011+n4_0012+n4_0013+n4_0014+n4_0015+n4_0016+n4_0017+n4_0018+n4_0019+n4_0020+n4_0021+n4_0022)
                          >20 then 1 else 0 end CQI_BADFLAG_4G_2, --CQI采样点数>20
                        --decode(n4_0031, 0, null,null,null, round(n4_0030/n4_0031,2)) n4_0032_2, --单用户下行感知速率
                        case when n4_0002 >20   then  1 else  0 end JTL_BADFLAG_4G_2, --RRC请求次数大于20次
                        case when n4_0005 >5    then  1 else  0 end DXL_BADFLAG_4G_2, --掉话/掉线次数>5
                        case when n4_0024 >20   then  1 else  0 end CSFB_BADFLAG_4G_2,--CSFB请求次数>20
                        --n4_0041, 

                        n4_0042,
                        n4_0030,n4_0031, N4_0032, --单用户下行感知速率
                        n4_0002, --RRC请求次数
                        n4_0005, --掉话/掉线次数
                        n4_0024, --CSFB请求次数
                        --N4_0033,--PRB底噪，上行干扰均值
                        --n4_0046/n4_0047-n4_0048/n4_0049 as n4_0033_confirm,
                        n4_0046, n4_0047, n4_0048, n4_0049, --PRB底噪相关
                        rfg_badflag_4g_num,--天级别指标，4GMR弱覆盖小区分子 
                        rfg_badflag_4g_den--天级别指标，4GMR弱覆盖小区分母 
                        --RSRP00+RSRP01+RSRP02_04+RSRP05_06 rfg_badflag_4g_num,
                        --RSRP00+RSRP01+RSRP02_04+RSRP05_06+RSRP07_11+RSRP12_16+RSRP17_21+RSRP22_26+RSRP27_31+RSRP32_36+RSRP37_41+RSRP42_46+RSRP47 rfg_badflag_4g_den
                        from
                        --select * from
                        (
                            --分区模式
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_1||')
                             union all
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_2||')
                             union all
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_3||')
                             union all
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_4||')
                             union all
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_5||')
                             union all
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_6||')
                             union all
                             select * from ZC_CELL_LIST_4G PARTITION('||v_partition_name_7||')
                        )T1--当前日期前7天数据拼接
                        --where ecgi = 8390411 --测试用LIMIT取样
                    )T2--打二次标签，导出功能中的额外筛选条件！！！
                )T3--可以仅保留导出标签&ECGI两字段
                group by ecgi--统计各小区7日内导出标签为1的数量
            )EX
            ON ZC.ECGI = EX.ECGI
            WHERE 
            (
                   regexp_substr(TPQH_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(CQI_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.XXGZSL_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.JTL_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.DXL_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.CSFB_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.PRB_4G_EXP,''[^-]+'',1,1,''i'')
                + regexp_substr(EX.RFG_BADFLAG_4G_EXP,''[^-]+'',1,1,''i'')
            )>0';
            commit;

            --针对某些小区去重，大约2个小区
            execute immediate'
            delete from ZC_BAD_CELL_LIST_4G_DAY
            where rowid in
            (
                select rowid from
                (
                   select row_number() over(partition by s_date, days_range, ecgi 
                   order by a.ecgi desc)seq, a.*
                   from ZC_BAD_CELL_LIST_4G_DAY PARTITION('||v_partition_name||') a
                   where a.ecgi in
                   (
                      select ecgi
                      from ZC_BAD_CELL_LIST_4G_DAY PARTITION('||v_partition_name||') t
                      group by s_date, days_range, ecgi
                      having count(*) > 1
                   )
                )x
                where x.seq <>1
            )';
            commit;

            --入库数量判断
            select count(1) into v_insert_cnt from ZC_BAD_CELL_LIST_4G_DAY t 
            where t.s_date = v_date_start /*and t.s_date< v_date_end*/;
            
            --重复率判断
            select count(1) into v_insert_repeat from
            (
                   select count(1) from ZC_BAD_CELL_LIST_4G_DAY t 
                   where t.s_date  = v_date_start /*and t.s_date< v_date_end*/ 
                   group by t.ecgi having count(1)>1
            );
            dbms_output.put_line('表 ZC_BAD_CELL_LIST_4G_DAY 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
            ');
         
        END  PROC_ZC_BAD_CELL_LIST_4G;
        
        
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：ZC_CELL_LIST_2G /DT_CELL_G@GRNOP_38 /ZC_CELL_LIST_4G /ZC_CELL_LIST_3G
  --out：LC_INDEX_LXN_BAD_CELL_DAY_2G
  PROCEDURE PROC_LC_INDEX_DAY_2G(V_DATE_THRESHOLD_START VARCHAR2) IS

        v_date_start  date;
        v_date_end   date;
        --v_loop_log number := 0 ;
        v_insert_cnt   number;
        v_insert_repeat   number;
        v_partition_name varchar2(30);
        v_ssql varchar2(500);
        v_clean_flag number;
        --v_proc_end_flag number :=0;


        BEGIN
            --起止时间戳格式化
            --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
            select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
            --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
            select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
            
            --从系统中获取待插入分区名
            select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
            where t.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_2G' 
            and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
            and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
            --或拼接待插入分区名
            --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
            
            --PLUS7暂未部署
            --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY_2G',v_date_start,v_date_start,'0','0');
            
            --分区数据清理
            /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from LC_INDEX_LXN_BAD_CELL_DAY_2G partition(' ||v_partition_name||');' into v_ssql from dual;
            execute immediate v_ssql;*/

            select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY_2G where start_time  >= v_date_start and start_time  < v_date_end;
            while v_clean_flag !=0 loop
           /* select 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY_2G PARTITION(' || v_partition_name||')' into v_ssql from dual;
            execute immediate v_ssql;*/
            
            select
            'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
            into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
            where s.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_2G';
            execute immediate v_ssql;
            
            /*execute immediate 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY_2G PARTITION(' || v_partition_name||')';
            commit;*/
            select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY_2G where start_time >= v_date_start and start_time < v_date_end;
            end loop;

            --全上海
            execute immediate
            '
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select
            S_DATE AS START_TIME,
            PROVINCE AS AREA,
            ''上海'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||') t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, PROVINCE, CELL_NUM_BWH'
            ;
            commit;


            --单元格：reserved3<单元格 > /county<优化分区 > /reserved8<区县分公司>  /vendor_id<厂家id,1华为，2中兴，7诺基亚>
            --40
            execute immediate
            '
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            --select count(1) from(
            select 
            S_DATE AS START_TIME,
            GRID AS AREA,
            ''单元格'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||') t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, GRID, CELL_NUM_BWH'
            ;
            commit;


            --行政区
            --16
            execute immediate
            '        
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            CITY  AS AREA,
            ''行政区'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, CITY, CELL_NUM_BWH'
            ;
            commit;

            --优化分区
            --4
            execute immediate
            '
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            COUNTRY  AS AREA,
            ''优化分区'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, COUNTRY, CELL_NUM_BWH';
            commit;
            
            
            
            --厂家：
            --2
            execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            FACTORY  AS AREA,
            ''厂家'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where S_DATE = to_date(20190611,''yyyymmdd'')
            group by S_DATE, FACTORY, CELL_NUM_BWH'
            ;
            commit;



            --区县分公司
            --13
            execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            COMPANY  AS AREA,
            ''区县分公司'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, COMPANY, CELL_NUM_BWH'
            ;
            commit;

            --环线
            --4
            execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            LOOP_LINE  AS AREA,
            ''环线'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, LOOP_LINE, CELL_NUM_BWH'
            ;
            commit;

            --基站类型 
            --2
            execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            PRE_FIELD3  AS AREA,
            ''基站类型'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, PRE_FIELD3, CELL_NUM_BWH';
            commit;

            --RNC：
            --43（实际45）
            --execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select distinct
            S_DATE AS START_TIME,
            RNC AS AREA,
            'RNC' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            to_number('') JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            to_number('') DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from /*ZC_CELL_LIST_2G \*partition('||v_partition_name||')*\t,*/
            (
                 select distinct s_date, RNC from ZC_CELL_LIST_4G /*partition('||v_partition_name||')*/t
                 where t.s_date >= v_date_start and t.s_date <v_date_end and RNC is not null
                 union all
                 select distinct s_date, RNC from ZC_CELL_LIST_3G /*partition('||v_partition_name||')*/t
                 where t.s_date >= v_date_start and t.s_date <v_date_end and RNC is not null
            )t2,--拼接RNC 2G空字段
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  '%报维护%'--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            --group by S_DATE, RNC, CELL_NUM_BWH
            ;
            commit;

            /*--TAC_LIST：
            --43（实际44）
            execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            t2.S_DATE AS START_TIME,
            t2.RNC AS AREA,--RNC
            ''TAC_LIST'' AS AREA_LEVEL,--4G：RNC，3G：TAC_LIST
            to_number('') JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            to_number('') DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from  \*ZC_CELL_LIST_2G t,*\ ZC_CELL_LIST_3G partition('||v_partition_name||')t2,--工参正常，3G工参关联OMC_3后，丢失1个RNC
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            and RNC is not null
            group by t2.S_DATE, t2.RNC,CELL_NUM_BWH';--43
            commit;*/

            --聚焦区域：
            --2
            execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select 
            S_DATE AS START_TIME,
            PRE_FIELD1  AS AREA,
            ''聚焦区域'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
            SUM(T.JTL_BADFLAG_2G) JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            SUM(T.DXL_BADFLAG_2G) DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from ZC_CELL_LIST_2G partition('||v_partition_name||')t,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
            )dt
            --where t.s_date >= v_date_start and t.s_date <v_date_end
            group by S_DATE, PRE_FIELD1, CELL_NUM_BWH';
            commit;

            --频点：
            --5
            --execute immediate'
            insert into LC_INDEX_LXN_BAD_CELL_DAY_2G
            select distinct
            t2.S_DATE AS START_TIME,
            t2.RESERVED5 AS AREA,--频点
            '频点' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
            to_number('') JTL_BADCELL_NUM_2G,--2G低接通质差小区数量 
            to_number('') DXL_BADCELL_NUM_2G,--2G高掉话质差小区数 
            DT.CELL_NUM_BWH AS CELL_NUM_2G--报维护小区数
            from
            (
                 select distinct s_date,RESERVED5 from ZC_CELL_LIST_4G 
                 where S_DATE >= v_date_start and S_DATE <v_date_end
                 and RESERVED5 is not null
            )t2,
            (
                 select count(1) CELL_NUM_BWH from DT_CELL_G@GRNOP_38 dt where dt.life like  '%报维护%'--分母中仅考虑报维护类型的小区
            )dt
            --group by t2.S_DATE, t2.RESERVED5, CELL_NUM_BWH'--5
            ;
            commit;
            
            --入库数量判断
            select count(1) into v_insert_cnt from LC_INDEX_LXN_BAD_CELL_DAY_2G t 
            where t.start_time >= v_date_start and t.start_time< v_date_end;
            
            --重复率判断
            select count(1) into v_insert_repeat from
            (
                   select count(1) from LC_INDEX_LXN_BAD_CELL_DAY_2G t 
                   where t.start_time  >= v_date_start and t.start_time< v_date_end 
                   group by t.area   having count(1)>1
            );
            dbms_output.put_line('表 LC_INDEX_LXN_BAD_CELL_DAY_2G 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
            ');

            
        END PROC_LC_INDEX_DAY_2G;

      
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：ZC_CELL_LIST_3G /DT_CELL_W /ZC_CELL_LIST_4G 
  --out：LC_INDEX_LXN_BAD_CELL_DAY_3G
  PROCEDURE PROC_LC_INDEX_DAY_3G(V_DATE_THRESHOLD_START VARCHAR2) IS

      v_date_start  date;
      v_date_end   date;
      --v_loop_log number := 0 ;
      v_insert_cnt   number;
      v_insert_repeat   number;
      v_partition_name varchar2(30);
      v_ssql varchar2(500);

      v_clean_flag number;
      --v_proc_end_flag number :=0;


      BEGIN
          --起止时间戳格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          
          --从系统中获取待插入分区名
          select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
          where t.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_3G' 
          and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
          and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
          --或拼接待插入分区名
          --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY_3G',v_date_start,v_date_start,'0','0');
          
          --分区数据清理
          /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from LC_INDEX_LXN_BAD_CELL_DAY_3G partition(' ||v_partition_name||');' into v_ssql from dual;
          execute immediate v_ssql;*/

          select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY_3G where start_time  >= v_date_start and start_time  < v_date_end;
          while v_clean_flag !=0 loop
         /* select 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY_3G PARTITION(' || v_partition_name||')' into v_ssql from dual;
          execute immediate v_ssql;*/
          
          select
          'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
          into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
          where s.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_3G';
          execute immediate v_ssql;
          
          /*execute immediate 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY_3G PARTITION(' || v_partition_name||')';
          commit;*/
          select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY_3G where start_time >= v_date_start and start_time < v_date_end;
          end loop;

          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          PROVINCE AS AREA,
          ''上海'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量 
          --SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          --where S_DATE = to_date(20190611,''yyyymmdd'')
          group by S_DATE, PROVINCE, CELL_NUM_BWH';
          commit;


          --单元格：reserved3<单元格 > /county<优化分区 > /reserved8<区县分公司>  /vendor_id<厂家id,1华为，2中兴，7诺基亚>
          --56
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          --select count(1) from(
          select 
          S_DATE AS START_TIME,
          GRID AS AREA,
          ''单元格'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'')
          and*/ GRID is not null
          group by S_DATE, GRID, CELL_NUM_BWH';--56
          commit;

          --行政区
          --16
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          CITY AS AREA,
          ''行政区'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'')
          and*/ CITY is not null
          group by S_DATE, CITY, CELL_NUM_BWH';--16
          commit;

          --优化分区
          --5
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          COUNTRY  AS AREA,
          ''优化分区'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'')
          and*/ COUNTRY is not null
          group by S_DATE, COUNTRY, CELL_NUM_BWH';--5
          commit;

          --厂家
          --2
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          FACTORY AS AREA,
          ''厂家'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          --where S_DATE = to_date(20190611,''yyyymmdd'')
          where FACTORY is not null
          group by S_DATE, FACTORY, CELL_NUM_BWH'
          ;--5
          commit;


          --区县分公司
          --13
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          COMPANY AS AREA,
          ''区县分公司'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'')
          and*/ COMPANY is not null
          group by S_DATE, COMPANY, CELL_NUM_BWH';--13
          commit;

          --环线
          --4
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          LOOP_LINE  AS AREA,
          ''环线'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 

          --SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'')
          and*/ LOOP_LINE is not null
          group by S_DATE, LOOP_LINE, CELL_NUM_BWH';--4
          commit;

          --基站类型 
          --2
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          PRE_FIELD2 AS AREA,
          ''基站类型'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ PRE_FIELD2 is not null
          group by S_DATE, PRE_FIELD2, CELL_NUM_BWH';--2
          commit;


          --RNC：
          --43（实际45）
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          RNC  AS AREA,--RNC
          ''RNC'' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ RNC is not null
          group by S_DATE, RNC, CELL_NUM_BWH';--43
          commit;

          --4G RNC--44
          --execute immediate
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select
          S_DATE AS START_TIME,
          RNC  AS AREA,--RNC
          'RNC' AS AREA_LEVEL,--4G：RNC，3G：TAC_LIST
          to_number('') TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          to_number('') H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          to_number('') RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          to_number('') MR_BADCELL_NUM_3G,--3GMR质差小区数量 
          to_number('') JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          to_number('') DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          to_number('') REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from  
          (
               select distinct s_date,RNC from ZC_CELL_LIST_4G 
               where S_DATE >= v_date_start and S_DATE <v_date_end
               and RNC is not null
          )t2,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  '%报维护%'--分母中仅考虑报维护类型的小区
          )dt;
          commit;

          /*--TAC_LIST：
          --43（实际44）
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          RNC  AS AREA,--RNC
          ''TAC_LIST'' AS AREA_LEVEL,--4G：RNC，3G：TAC_LIST
          to_number('') TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          to_number('') H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          to_number('') RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          to_number('') MR_BADCELL_NUM_3G,--3GMR质差小区数量 
          to_number('') JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          to_number('') DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          to_number('') REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from  ZC_CELL_LIST_3G partition('||v_partition_name||')t,--工参正常，3G工参关联OMC_3后，丢失1个RNC
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where --t.S_DATE = to_date(20190611,''yyyymmdd'') 
          --and  t2.S_DATE = t.S_DATE
          --and 
          RNC is not null
          group by S_DATE, RNC,CELL_NUM_BWH';--43
          commit;*/

          --聚焦区域：
          --2
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select 
          S_DATE AS START_TIME,
          PRE_FIELD1 AS AREA,--聚焦区域
          ''聚焦区域'' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          SUM(T.TPQH_BADFLAG_3G) TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          SUM(T.RTWP_BADFLAG_3G) H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          SUM(T.RSRP_BADFLAG_3G) RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          SUM(T.ECIO_BADFLAG_3G) MR_BADCELL_NUM_3G,--3GMR质差小区数量 
          SUM(T.JTL_BADFLAG_3G) JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          SUM(T.DXL_BADFLAG_3G) DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          SUM(T.CJL_BADFLAG_3G ) REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ PRE_FIELD1 is not null
          group by S_DATE, PRE_FIELD1, CELL_NUM_BWH';--2
          commit;

          --频点：
          --5
          --execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_3G
          select distinct
          t2.S_DATE AS START_TIME,
          t2.RESERVED5 AS AREA,--聚焦区域
          '频点' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          to_number('') TPQH_BADCELL_NUM_3G,--3G同频切换质差小区数 
          to_number('') H_JAM_NUM_3G ,--3G高干扰质差小区数量 
          to_number('') RFG_CELL_NUM_3G,--3GMR弱覆盖小区数量 
          to_number('') MR_BADCELL_NUM_3G,--3GMR质差小区数量 
          to_number('') JTL_BADCELL_NUM_3G,--3G低接通质差小区数量 
          to_number('') DXL_BADCELL_NUM_3G,--3G高掉话质差小区数 
          DT.CELL_NUM_BWH AS CELL_NUM_3G,--报维护小区数
          to_number('') REBUILD_BADCELL_NUM_3G--重建率质差小区数量  
          from
          (
               select distinct s_date,RESERVED5 from ZC_CELL_LIST_4G 
               where S_DATE >= v_date_start and S_DATE <v_date_end
               and RESERVED5 is not null
          )t2,        
          (
               select count(1) CELL_NUM_BWH from DT_CELL_W dt where dt.life like  '%报维护%'--分母中仅考虑报维护类型的小区
          )dt
          ;
          commit;
          
          
          --入库数量判断
          select count(1) into v_insert_cnt from LC_INDEX_LXN_BAD_CELL_DAY_3G t 
          where t.start_time >= v_date_start and t.start_time< v_date_end;
          
          
          --重复率判断
          select count(1) into v_insert_repeat from
          (
                 select count(1) from LC_INDEX_LXN_BAD_CELL_DAY_3G t 
                 where t.start_time  >= v_date_start and t.start_time< v_date_end 
                 group by t.area   having count(1)>1
          );
          dbms_output.put_line('表 LC_INDEX_LXN_BAD_CELL_DAY_3G 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
          ');

          
      END PROC_LC_INDEX_DAY_3G;
    
    
     
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：ZC_CELL_LIST_4G /DT_CELL_L /ZC_CELL_LIST_3G 
  --out：LC_INDEX_LXN_BAD_CELL_DAY_4G
  PROCEDURE PROC_LC_INDEX_DAY_4G(V_DATE_THRESHOLD_START VARCHAR2) IS

      v_date_start  date;
      v_date_end   date;
      --v_loop_log number := 0 ;
      v_insert_cnt   number;
      v_insert_repeat   number;
      v_partition_name varchar2(30);
      v_ssql varchar2(500);

      v_clean_flag number;
      --v_proc_end_flag number :=0;


      BEGIN
          --起止时间戳格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          
          --从系统中获取待插入分区名
          select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
          where t.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_4G' 
          and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
          and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
          --或拼接待插入分区名
          --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY_4G',v_date_start,v_date_start,'0','0');
          
          --分区数据清理
          /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from LC_INDEX_LXN_BAD_CELL_DAY_4G partition(' ||v_partition_name||');' into v_ssql from dual;
          execute immediate v_ssql;*/

          select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY_4G where start_time  >= v_date_start and start_time  < v_date_end;
          while v_clean_flag !=0 loop
          /*select 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY_4G PARTITION(' || v_partition_name||')' into v_ssql from dual;
          execute immediate v_ssql;*/
          
          select
          'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
          into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
          where s.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_4G';
          execute immediate v_ssql;
          
          /*execute immediate 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY_4G PARTITION(' || v_partition_name||')';
          commit;*/
          select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY_4G where start_time >= v_date_start and start_time < v_date_end;
          end loop;
                  
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          PROVINCE AS AREA,
          ''上海'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          --where S_DATE = to_date(20190611,''yyyymmdd'')
          group by S_DATE, PROVINCE, CELL_NUM_BWH'
          ;
          commit;


          --单元格：reserved3<单元格 > /county<优化分区 > /reserved8<区县分公司>  /vendor_id<厂家id,1华为，2中兴，7诺基亚>
          --56
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          --select count(1) from(
          select 
          S_DATE AS START_TIME,
          RESERVED3  AS AREA,
          ''单元格'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'')
          and*/ RESERVED3 is not null
          group by S_DATE, RESERVED3, CELL_NUM_BWH'
          ;--56
          commit;

          --优化分区
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          COUNTY    AS AREA,
          ''优化分区'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ COUNTY is not null
          group by S_DATE, COUNTY, CELL_NUM_BWH'
          ;--5
          commit;

          --区县分公司
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          RESERVED8 AS AREA,
          ''区县分公司'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ RESERVED8 is not null
          group by S_DATE, RESERVED8, CELL_NUM_BWH'
          ;--14
          commit;

          --厂家
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          VENDOR_ID  AS AREA,--厂家
          ''厂家'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ VENDOR_ID is not null
          group by S_DATE, VENDOR_ID, CELL_NUM_BWH'
          ;--2
          commit;


          --行政区
          --16
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          VENDOR_CELL_ID   AS AREA,--行政区
          ''行政区'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ VENDOR_CELL_ID is not null
          group by S_DATE, VENDOR_CELL_ID, CELL_NUM_BWH'
          ;--16
          commit;

          --环线
          --4
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          TOWN_ID    AS AREA,--环线
          ''环线'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ TOWN_ID is not null
          group by S_DATE, TOWN_ID, CELL_NUM_BWH'
          ;--4
          commit;


          --基站类型 
          --2
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          COVER_TYPE  AS AREA,
          ''基站类型'' AS AREA_LEVEL,--能否想办法将这里的area_level改成自动识别，分类
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ COVER_TYPE is not null
          group by S_DATE, COVER_TYPE, CELL_NUM_BWH'
          ;--2
          commit;

          --RNC：
          --44
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select
          S_DATE AS START_TIME,
          RNC  AS AREA,--RNC
          ''RNC'' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ RNC is not null
          group by S_DATE, RNC, CELL_NUM_BWH'
          ;--44
          commit;

          --3G RNC 为了后续拼接大表做准备
          --43
          /*execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          t2.S_DATE AS START_TIME,
          t2.RNC  AS AREA,--RNC
          ''RNC'' AS AREA_LEVEL,--4G：RNC，3G：TAC_LIST
          to_number('')TPQH_BADCELL_NUM_4G,
          to_number('') H_JAM_NUM_4G,
          to_number('') RFG_CELL_NUM_4G,
          to_number('') CSFB_BAD_CELL_NUM,
          to_number('') JTL_BADCELL_NUM_4G,
          to_number('') DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          to_number('') CQI_BADCELL_NUM_4G,
          to_number('') USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from  ZC_CELL_LIST_3G partition('||v_partition_name||')t2,--工参正常，3G工参关联OMC_3后，丢失1个RNC
          (
               select count(1) CELL_NUM_BWH from DT_CELL_L dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where --t2.S_DATE = to_date(20190611,''yyyymmdd'') 
          --and  t2.S_DATE = t.S_DATE
          --and 
          t2.RNC is not null
          group by t2.S_DATE, t2.RNC, CELL_NUM_BWH'
          ;--43*/
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select
          t2.S_DATE AS START_TIME,
          t2.RNC  AS AREA,--RNC
          'RNC' AS AREA_LEVEL,--4G：RNC，3G：TAC_LIST
          to_number('')TPQH_BADCELL_NUM_4G,
          to_number('') H_JAM_NUM_4G,
          to_number('') RFG_CELL_NUM_4G,
          to_number('') CSFB_BAD_CELL_NUM,
          to_number('') JTL_BADCELL_NUM_4G,
          to_number('') DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          to_number('') CQI_BADCELL_NUM_4G,
          to_number('') USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from  
          (
            select distinct s_date, RNC from
            ZC_CELL_LIST_3G
            where S_DATE >= v_date_start and S_DATE <v_date_end
            and RNC is not null
          ) t2,--工参正常，3G工参关联OMC_3后，丢失1个RNC
          (
               select count(1) CELL_NUM_BWH from DT_CELL_L dt where dt.life like  '%报维护%'--分母中仅考虑报维护类型的小区
          )dt;
          --and  t2.S_DATE = t.S_DATE
          --group by t2.S_DATE, t2.RNC, CELL_NUM_BWH;--43
          commit;

          /*--TAC_LIST：
          --43（实际44）
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          t2.S_DATE AS START_TIME,
          t2.RNC  AS AREA,--RNC
          ''TAC_LIST'' AS AREA_LEVEL,--4G：RNC，3G：TAC_LIST
          to_number('')TPQH_BADCELL_NUM_4G,
          to_number('') H_JAM_NUM_4G,
          to_number('') RFG_CELL_NUM_4G,
          to_number('') CSFB_BAD_CELL_NUM,
          to_number('') JTL_BADCELL_NUM_4G,
          to_number('') DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          to_number('') CQI_BADCELL_NUM_4G,
          to_number('') USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_3G partition('||v_partition_name||')t2,--工参正常，3G工参关联OMC_3后，丢失1个RNC
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where --t2.S_DATE = to_date(20190611,''yyyymmdd'') 
          --and  t2.S_DATE = t.S_DATE
          --and 
          t2.RNC is not null
          group by t2.S_DATE, t2.RNC, CELL_NUM_BWH'
          ;--43
          commit;*/

          --聚焦区域：
          --2
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          RESERVED4   AS AREA,--聚焦区域
          ''聚焦区域'' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ RESERVED4 is not null
          group by S_DATE, RESERVED4, CELL_NUM_BWH'
          ;--2
          commit;

          --频点：
          --5
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          S_DATE AS START_TIME,
          RESERVED5   AS AREA,--聚焦区域
          ''频点'' AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          SUM(T.TPQH_BADFLAG_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_BADFLAG_4G) H_JAM_NUM_4G,
          SUM(T.RFG_BADFLAG_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BADFLAG_4G) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADFLAG_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADFLAG_4G) DXL_BADCELL_NUM_4G,
          DT.CELL_NUM_BWH AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADFLAG_4G) CQI_BADCELL_NUM_4G,
          SUM(T.XXGZSL_BADFLAG_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from ZC_CELL_LIST_4G partition('||v_partition_name||')t,
          (
               select count(1) CELL_NUM_BWH from dt_cell_l dt where dt.life like  ''%报维护%''--分母中仅考虑报维护类型的小区
          )dt
          where /*S_DATE = to_date(20190611,''yyyymmdd'') 
          and*/ RESERVED5 is not null
          group by S_DATE, RESERVED5, CELL_NUM_BWH'--5
          ;
          commit;
          
          --非L900
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY_4G
          select 
          START_TIME,
          ''非L900''  AS AREA,--聚焦区域
          AREA_LEVEL AS AREA_LEVEL,--4G：RNC，3G：RNC，2G：TAC_LIST
          SUM(T.TPQH_BADCELL_NUM_4G) TPQH_BADCELL_NUM_4G,
          SUM(T.H_JAM_NUM_4G) H_JAM_NUM_4G,
          SUM(T.RFG_CELL_NUM_4G) RFG_CELL_NUM_4G,
          SUM(T.CSFB_BAD_CELL_NUM) CSFB_BAD_CELL_NUM,
          SUM(T.JTL_BADCELL_NUM_4G) JTL_BADCELL_NUM_4G,
          SUM(T.DXL_BADCELL_NUM_4G) DXL_BADCELL_NUM_4G,
          MAX(CELL_NUM_4G) AS CELL_NUM_4G,--报维护小区数
          SUM(T.CQI_BADCELL_NUM_4G) CQI_BADCELL_NUM_4G,
          SUM(T.USER_BADCELL_NUM_4G) USER_BADCELL_NUM_4G--单用户下行感知速率质差小区数量 
          from 
          LC_INDEX_LXN_BAD_CELL_DAY_4G partition('||v_partition_name||') T
          where (area != ''L900'' and area !=''NB'') 
          and area_level =''频点''
          group by START_TIME, AREA_LEVEL'--1
          ;
          commit;
      
          --入库数量判断
          select count(1) into v_insert_cnt from LC_INDEX_LXN_BAD_CELL_DAY_4G t 
          where t.start_time >= v_date_start and t.start_time< v_date_end;
          
          
          --重复率判断
          select count(1) into v_insert_repeat from
          (
                 select count(1) from LC_INDEX_LXN_BAD_CELL_DAY_4G t 
                 where t.start_time  >= v_date_start and t.start_time< v_date_end 
                 group by t.area   having count(1)>1
          );
          dbms_output.put_line('表 LC_INDEX_LXN_BAD_CELL_DAY_4G 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
          ');

          
          
      END PROC_LC_INDEX_DAY_4G;
    
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --in：LC_INDEX_LXN_BAD_CELL_DAY_4G /LC_INDEX_LXN_BAD_CELL_DAY_3G /LC_INDEX_LXN_BAD_CELL_DAY_2G
  --out：LC_INDEX_LXN_BAD_CELL_DAY
  PROCEDURE PROC_LC_INDEX_DAY_234G(V_DATE_THRESHOLD_START VARCHAR2) IS
      v_date_start  date;
      v_date_end   date;
      --v_loop_log number := 0 ;
      v_insert_cnt   number;
      v_insert_repeat   number;
      v_partition_name varchar2(30);
      v_ssql varchar2(500);

      v_clean_flag number;
      --v_proc_end_flag number :=0;    
      BEGIN
        
          --起止时间戳格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          
          --从系统中获取待插入分区名
          select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
          where t.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY' 
          and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
          and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611
          --或拼接待插入分区名
          --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY',v_date_start,v_date_start,'0','0');
          
          --分区数据清理
          /*v_ssql :=select 'select count(1) \*into v_clean_flag*\ from LC_INDEX_LXN_BAD_CELL_DAY partition(' ||v_partition_name||');' into v_ssql from dual;
          execute immediate v_ssql;*/

          select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY where start_time  >= v_date_start and start_time  < v_date_end;
          while v_clean_flag !=0 loop
         /* select 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY PARTITION(' || v_partition_name||')' into v_ssql from dual;
          execute immediate v_ssql;*/
          
          select
          'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_TRUNCATE_RANGE_INDEX('''|| table_name||''','''|| tm_grn ||''','''||v_date_threshold_start||''','''||v_date_threshold_start||''')'
          into v_ssql from FAST_DATA_PROCESS_TEMPLATE s
          where s.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY';
          execute immediate v_ssql;
          
          /*execute immediate 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY PARTITION(' || v_partition_name||')';
          commit;*/
          select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY where start_time >= v_date_start and start_time < v_date_end;
          end loop;
          
          execute immediate'
          insert into LC_INDEX_LXN_BAD_CELL_DAY
          SELECT 
          L.START_TIME, DECODE(L.AREA,''1'',''华为'',''7'',''诺基亚'',L.AREA) AREA, L.AREA_LEVEL, --时间/分区/分区维度
          to_char(W.TPQH_BADCELL_NUM_3G) TPQH_BADCELL_NUM_3G, 
          to_char(L.TPQH_BADCELL_NUM_4G) TPQH_BADCELL_NUM_4G, 

          to_char(W.H_JAM_NUM_3G) H_JAM_NUM_3G,
          to_char(L.H_JAM_NUM_4G) H_JAM_NUM_4G,


          to_char(W.RFG_CELL_NUM_3G)RFG_CELL_NUM_3G, 
          to_char(W.MR_BADCELL_NUM_3G)MR_BADCELL_NUM_3G, 
          to_char(L.RFG_CELL_NUM_4G)RFG_CELL_NUM_4G, 
          to_char(L.CSFB_BAD_CELL_NUM)CSFB_BAD_CELL_NUM,

          to_char(G.JTL_BADCELL_NUM_2G)JTL_BADCELL_NUM_2G, 
          to_char(W.JTL_BADCELL_NUM_3G)JTL_BADCELL_NUM_3G, 
          to_char(L.JTL_BADCELL_NUM_4G)JTL_BADCELL_NUM_4G,

          to_char(G.DXL_BADCELL_NUM_2G)DXL_BADCELL_NUM_2G, 
          to_char(W.DXL_BADCELL_NUM_3G)DXL_BADCELL_NUM_3G, 
          to_char(L.DXL_BADCELL_NUM_4G)DXL_BADCELL_NUM_4G,

          to_char(G.CELL_NUM_2G)CELL_NUM_2G, 
          to_char(W.CELL_NUM_3G)CELL_NUM_3G, 
          to_char(L.CELL_NUM_4G)CELL_NUM_4G,

          to_char(L.CQI_BADCELL_NUM_4G)CQI_BADCELL_NUM_4G, 
          to_char(W.REBUILD_BADCELL_NUM_3G)REBUILD_BADCELL_NUM_3G, 
          to_char(L.USER_BADCELL_NUM_4G)USER_BADCELL_NUM_4G

          FROM LC_INDEX_LXN_BAD_CELL_DAY_4G partition('||v_partition_name||')L --4G小区质差指标
          LEFT JOIN 
          LC_INDEX_LXN_BAD_CELL_DAY_3G partition('||v_partition_name||')W --3G小区质差指标
          ON (L.START_TIME = W.START_TIME AND L.AREA = W.AREA AND L.AREA_LEVEL = W.AREA_LEVEL) 

          LEFT JOIN LC_INDEX_LXN_BAD_CELL_DAY_2G partition('||v_partition_name||')G --2G小区质差指标
          ON (L.START_TIME = G.START_TIME AND L.AREA = G.AREA AND L.AREA_LEVEL = G.AREA_LEVEL)
          order by area_level, area'
          ;

          commit;
          
          --入库数量判断
          select count(1) into v_insert_cnt from LC_INDEX_LXN_BAD_CELL_DAY t 
          where t.start_time >= v_date_start and t.start_time< v_date_end;
          
          
          --重复率判断
          select count(1) into v_insert_repeat from
          (
                 select count(1) from LC_INDEX_LXN_BAD_CELL_DAY t 
                 where t.start_time  >= v_date_start and t.start_time< v_date_end 
                 group by t.area   having count(1)>1
          );
          dbms_output.put_line('表 LC_INDEX_LXN_BAD_CELL_DAY 天级数据插入完成！时间戳：'||to_char(v_date_start,'yyyymmdd')||'，入库数据行数：'||v_insert_cnt||'，重复数据行数：'||v_insert_repeat||'行.
          ');

          

      END PROC_LC_INDEX_DAY_234G;
      
      
      
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --PROC_ZC_CELL_LIST_4G /PROC_ZC_CELL_LIST_3G /PROC_ZC_CELL_LIST_2G 
  --PROC_ZC_BAD_CELL_LIST_4G /PROC_ZC_BAD_CELL_LIST_3G /PROC_ZC_BAD_CELL_LIST_2G
  PROCEDURE ACTIVE_ZC_CELL_LIST(V_DATE_THRESHOLD_START VARCHAR2) IS
      --v_date_start  date;
      --v_date_end   date;
      v_loop_log number := 0 ;
      --v_insert_cnt   number;
      --v_insert_repeat   number;
      --v_partition_name varchar2(30);
      --v_ssql varchar2(500);

      --v_clean_flag number;
      --v_proc_end_flag number :=0;    
      BEGIN
        
          /*--起止时间戳格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化*/
          
          /*--从系统中获取待插入分区名
          select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
          where t.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_4G' 
          and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
          and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611*/
          --或拼接待插入分区名
          --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY_4G',v_date_start,v_date_start,'0','0');
          
          --激活234G质差小区清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_4G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_3G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_2G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          dbms_output.put_line('234G质差小区清单天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_THRESHOLD_START||'，存储过程执行数量：'||v_loop_log||'.
          ');
          --dbms_output.put_line('\n');
          --激活234G质差小区（坏小区）清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_BAD_CELL_LIST_4G(V_DATE_THRESHOLD_START);
          v_loop_log := 1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_BAD_CELL_LIST_3G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_BAD_CELL_LIST_2G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          dbms_output.put_line('234G质差小区（坏小区）清单天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_THRESHOLD_START||'，存储过程执行数量：'||v_loop_log||'.
          ');
          --dbms_output.put_line('\n'); 
          
      END ACTIVE_ZC_CELL_LIST;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --PROC_LC_INDEX_DAY_4G /PROC_LC_INDEX_DAY_3G /PROC_LC_INDEX_DAY_2G
  --PROC_LC_INDEX_DAY_234G
  PROCEDURE ACTIVE_LC_INDEX_DAY(V_DATE_THRESHOLD_START VARCHAR2) IS
       --v_date_start  date;
      --v_date_end   date;
      v_loop_log number := 0 ;
      --v_insert_cnt   number;
      --v_insert_repeat   number;
      --v_partition_name varchar2(30);
      --v_ssql varchar2(500);

      --v_clean_flag number;
      --v_proc_end_flag number :=0;    
      BEGIN
        
          /*--起止时间戳格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_date(v_date_threshold_start,'yyyymmdd') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          --select to_date(v_date_threshold_start,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          select v_date_start +1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化*/
          
          /*--从系统中获取待插入分区名
          select t.partition_name into v_partition_name from USER_TAB_PARTITIONS t 
          where t.table_name = 'LC_INDEX_LXN_BAD_CELL_DAY_4G' 
          and t.partition_name like 'P\_%' escape '\' --分区名严格遵守时，可忽略此行条件
          and regexp_substr(t.partition_name,'[^_]+',1,2,'i') = v_date_threshold_start; --regexp_substr('P_20190611','[^_]+',1,2,'i') → 20190611*/
          --或拼接待插入分区名
          --select 'P_'||V_DATE_THRESHOLD_START into v_partition_name from dual;
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY_4G',v_date_start,v_date_start,'0','0');
          
          --激活234G质差小区指标汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_4G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_3G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_2G(V_DATE_THRESHOLD_START);
          v_loop_log := v_loop_log +1;
          
          dbms_output.put_line('234G质差小区指标天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_THRESHOLD_START||'，存储过程执行数量：'||v_loop_log||'.
          ');
          
          v_loop_log := 1;
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_234G(V_DATE_THRESHOLD_START);
          dbms_output.put_line('234G质差小区指标天级拼接任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_THRESHOLD_START||'，存储过程执行数量：'||v_loop_log||'.
          ');
          
      END ACTIVE_LC_INDEX_DAY;


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  /*--自动激活234G质差小区清单汇聚脚本
  PROCEDURE ACTIVE_ZC_CELL_LIST_AUTO IS
      v_date_start  varchar2(15);
      --v_date_end   varchar2(15);
      v_loop_log number := 0 ;
      --v_insert_cnt   number;
      --v_insert_repeat   number;
      --v_partition_name varchar2(30);
      --v_ssql varchar2(500);

      --v_clean_flag number;
      --v_proc_end_flag number :=0;    
      BEGIN
        
          --起止时间戳格式化，时间自动化，读取时间：sysdate
          --select to_char(sysdate,'yyyymmdd hh24:mi:ss') into v_date_start from dual;--起始时间戳'yyyymmdd'格式化
          select to_char(sysdate-1,'yyyymmdd') into V_DATE_START from dual;--sysdate-1 !!!
          --select to_char(sysdate+1,'yyyymmdd hh24:mi:ss')+1 into v_date_end from dual;--起始时间戳'yyyymmdd'格式化
          --select to_char(sysdate,'yyyymmdd') into V_DATE_END from dual;--起始时间戳'yyyymmdd'格式化
          
          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY_4G',v_date_start,v_date_start,'0','0');
          
          --自动激活234G质差小区清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_4G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_3G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_2G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          dbms_output.put_line('234G质差小区清单天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_START||'，存储过程执行数量：'||v_loop_log||'.
          ');
          --激活234G质差小区（坏小区）清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_BAD_CELL_LIST_4G(V_DATE_START);
          v_loop_log := 1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_BAD_CELL_LIST_3G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_BAD_CELL_LIST_2G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          dbms_output.put_line('234G质差小区（坏小区）清单天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_START||'，存储过程执行数量：'||v_loop_log||'.
          ');
          --dbms_output.put_line('\n'); 
          
      END ACTIVE_ZC_CELL_LIST_AUTO;*/



-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --自动激活234G质差小区指标汇聚脚本
  PROCEDURE ACTIVE_LC_INDEX_DAY_AUTO IS
      v_date_start  varchar2(15);
      --v_date_end   varchar2(15);
      v_date_start_clean date;
      v_date_start_clean_vc varchar2(15);
      --v_date_end_clean date;
      --v_loop_log number := 0 ;
      --v_insert_cnt   number;
      --v_insert_repeat   number;
      --v_partition_name varchar2(30);
      --v_ssql varchar2(500);
      --v_clean_flag number;

      BEGIN

          --起止时间戳格式化，时间自动化，读取时间：sysdate-1
          select to_char(sysdate-1,'yyyymmdd') into V_DATE_START from dual;--sysdate-1 !!!
          select add_months(trunc(sysdate-1,'dd'),-3) into v_date_start_clean from dual;--数据清理起始时间戳，3个月前
          select to_char(add_months(trunc(sysdate-1,'dd'),-3), 'yyyymmdd') into v_date_start_clean_vc from dual;

          --PLUS7暂未部署
          --PKG_MANAGE_SYSTEM_PLUS7_0.PROC_PARTITION_CLEANUP_RANGE('LRNOP','LC_INDEX_LXN_BAD_CELL_DAY',v_date_start,v_date_start,'0','0');
          
          --自动清理冗余数据
          --暂时关闭
          --LC_INDEX_LXN_BAD_CELL_DAY（启动）
          --ZC_CELL_LIST_4G/ZC_CELL_LIST_3G/ZC_CELL_LIST_2G（暂无）
          --LC_INDEX_LXN_BAD_CELL_DAY_4G/LC_INDEX_LXN_BAD_CELL_DAY_3G/LC_INDEX_LXN_BAD_CELL_DAY_2G（暂无）
          /*if v_partition_name !='0' then
              select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY where start_time = v_date_start_clean;
              while v_clean_flag !=0 loop
                  select 'DELETE FROM LC_INDEX_LXN_BAD_CELL_DAY PARTITION(' || v_partition_name||')' into v_ssql from dual;
                  execute immediate v_ssql;
                  select count(1) into v_clean_flag from LC_INDEX_LXN_BAD_CELL_DAY where start_time = v_date_start;
              end loop;
          end if;*/
          
          
          --自动激活234G质差小区清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.ACTIVE_ZC_CELL_LIST(V_DATE_START);
          /*PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_4G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_3G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_ZC_CELL_LIST_2G(V_DATE_START);
          v_loop_log := v_loop_log +1;       
          dbms_output.put_line('234G质差小区清单天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_START||'，存储过程执行数量：'||v_loop_log||'.'
          );*/
         
          
          --激活234G质差小区清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.ACTIVE_LC_INDEX_DAY(V_DATE_START);

          /*PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_4G(V_DATE_START);
          v_loop_log := 1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_3G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_2G(V_DATE_START);
          v_loop_log := v_loop_log +1;
          dbms_output.put_line('234G质差小区指标天级汇聚任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_START||'，存储过程执行数量：'||v_loop_log||'.
          ');

          PKG_LC_INDEX_LXN_BAD_CELL_DAY.PROC_LC_INDEX_DAY_234G(V_DATE_START);
          
          v_loop_log := 1;
          dbms_output.put_line('234G质差小区指标天级拼接任务完成！完成时间戳：'||to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')||'，汇聚时间戳：'||V_DATE_START||'，存储过程执行数量：'||v_loop_log||'.
          ');*/
          
      END ACTIVE_LC_INDEX_DAY_AUTO;
  
  
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  --自动激活234G质差小区指标汇聚脚本
  PROCEDURE ACTIVE_LC_INDEX_DAY_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2) IS
      --v_date_start  varchar2(15);
      --v_date_end   varchar2(15);
      --v_date_start_clean date;
      --v_date_start_clean_vc varchar2(15);
      --v_date_end_clean date;
      --v_loop_log number := 0 ;
      --v_insert_cnt   number;
      --v_insert_repeat   number;
      --v_partition_name varchar2(30);
      --v_ssql varchar2(500);
      --v_clean_flag number;

      BEGIN
          
          --激活234G质差小区清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.ACTIVE_ZC_CELL_LIST(V_DATE_THRESHOLD_START);
          --激活234G质差小区清单汇聚脚本
          PKG_LC_INDEX_LXN_BAD_CELL_DAY.ACTIVE_LC_INDEX_DAY(V_DATE_THRESHOLD_START);

      END ACTIVE_LC_INDEX_DAY_SUPPLEMENT;
  
  
  
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  PROCEDURE PROC_TEST IS
      v_date_start  VARCHAR2(20);
      --v_ssql CLOB;
      /*i_tablename   varchar2(30);
      --v_loop_log number := 0 ;
      i_tablespace   varchar2(30);
      i_part_name   varchar2(30);
      i_part_date varchar2(30);
      i_partition_name varchar2(500);*/

      --v_clean_flag number;
      --v_proc_end_flag number :=0;    
      BEGIN
         select 1 into v_date_start from dual;
         /*select 
         dbms_output.put_line('234G质差小区清单天级汇聚任务完成！完成时间戳：'||sysdate)
         into v_ssql
         from dual;*/
         --select count(1) into v_date_start from sys.gv_$locked_object a;
      END PROC_TEST;
    
    
END PKG_LC_INDEX_LXN_BAD_CELL_DAY;
/

