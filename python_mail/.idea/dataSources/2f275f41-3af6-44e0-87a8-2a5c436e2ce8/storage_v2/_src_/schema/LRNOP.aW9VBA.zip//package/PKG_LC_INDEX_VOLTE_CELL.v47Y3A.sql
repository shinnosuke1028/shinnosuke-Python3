create PACKAGE PKG_LC_INDEX_VOLTE_CELL AUTHID CURRENT_USER as
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  大屏指标汇总-VOLTE小区
  --
  --  OWNER:       Shinnosuke
  --
  --  VERSION:     1.5
  --
  --  CREATE DATE： 2019/08/12 version 1.0
  --               1.增加VOLTE小区天级清单结果表过程（含计算字段，用于后续质差计算）PROC_VOLTE_CELL_LIST_DAY
  --
  --  UPDATE DATE：2019/08/13 version 1.1
  --               1.增加VOLTE区域小时级指标结果表过程（不含计算字段，前台呈现）PROC_LC_INDEX_VOLTE_3
  --               2.增加VOLTE区域天级指标结果表过程（不含计算字段，前台呈现）PROC_LC_INDEX_VOLTE_8  --               
  --
  --  UPDATE DATE：2019/08/14 version 1.2
  --               1.增加VOLTE质差小区清单结果表过程（含计算字段，前台导出，全量）PROC_ZC_CELL_LIST_VOLTE_DAY
  --               2.增加VOLTE质差小区指标结果表过程（含计算字段，前台导出，全量）PROC_LC_INDEX_VOLTE_BAD_CELL_DAY
  --               3.增加VOLTE区域周级指标结果表过程（不含计算字段，前台呈现）PROC_LC_INDEX_VOLTE_9
  --               4.增加VOLTE区域月级指标结果表过程（不含计算字段，前台呈现）PROC_LC_INDEX_VOLTE_A
  --
  --  UPDATE DATE：2019/08/15 version 1.3
  --               1.修正VOLTE区域小时级指标结果表过程（OMC_LTE_3 为SYS自增分区，时间传递模式修改）
  --               2.修正VOLTE区域天级指标结果表过程（OMC_LTE_8 无分区，时间传递模式修改）
  --               3.修正VOLTE质差小区指标结果表过程（字段 DAYS_RANGE 重复）
  --               4.增加VOLTE区域指标结果表周期性自动汇聚过程 ACTIVE_LC_INDEX_VOLTE_89A_AUTO
  --               5.增加VOLTE区域指标结果表周期性汇聚任务自动激活（小时/区域）ACTIVE_LC_INDEX_VLOTE_3_AUTO
  --
  --  UPDATE DATE：2019/08/16 version 1.4
  --               1.修正VOLTE区域指标结果表周期性汇聚任务自动激活 ACTIVE_LC_INDEX_VOLTE_3_AUTO（小时级自动调度任务 天级入口时间戳修正）
  --
  --  UPDATE DATE：2019/08/26 version 1.5
  --               1.修正VOLTE区域指标结果表周期性自动汇聚过程 ACTIVE_LC_INDEX_VOLTE_89A_AUTO（任务执行成功，无数据，加固执行条件）
  --                
  --               1.增加VOLTE区域指标结果表周期性汇聚任务自动激活 ACTIVE_LC_INDEX_VOLTE_3_AUTO（小时级自动调度任务 天级入口时间戳修正）  --  TODO    1.增加分区表自动清理功能（Finished）
  --               2.PROC_LC_INDEX_VOLTE_9 中的OMC_LTE_8表暂无分区，后续需优化并进行脚本替换
  --               3.OMC_LTE_3已有系统自增分区（格式较差）/PMC_LTE_8/9/A均为无分区生产表，待更新
  --               4.评估是否新增进程相关监控信息
  --
  --
------------------------------------------------------------------------

  --VOLTE小区天级清单结果表过程（含计算字段，用于后续质差计算，纯汇聚清单）
  /*PROCEDURE PROC_VOLTE_CELL_LIST_DAY(V_DATE_THRESHOLD_START VARCHAR2);*/
  
  --VOLTE区域小时级指标结果表过程（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_VOLTE_3(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2);
  --VOLTE区域天级指标结果表过程（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_VOLTE_8(V_DATE_THRESHOLD_START VARCHAR2);
  --VOLTE区域周级指标结果表过程（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_VOLTE_9(V_DATE_THRESHOLD_START VARCHAR2);
  --VOLTE区域月级指标结果表过程（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_VOLTE_A(V_DATE_THRESHOLD_START VARCHAR2);
  
  --VOLTE质差小区清单结果表过程（不含计算字段，前台呈现）
  PROCEDURE PROC_ZC_CELL_LIST_VOLTE_DAY(V_DATE_THRESHOLD_START VARCHAR2);
  --VOLTE质差小区汇总结果表过程（不含计算字段，前台呈现）
  PROCEDURE PROC_LC_INDEX_VOLTE_BAD_CELL_DAY(V_DATE_THRESHOLD_START VARCHAR2);

  --VOLTE区域指标结果表周期性汇聚任务自动激活（不含小时任务）
  PROCEDURE ACTIVE_LC_INDEX_VOLTE_89A_AUTO;
  --VOLTE区域指标结果表周期性汇聚任务自动激活（小时/区域）
  PROCEDURE ACTIVE_LC_INDEX_VOLTE_3_AUTO;

  --VOLTE指标汇聚补偿
  PROCEDURE ACTIVE_LC_INDEX_VOLTE_89A_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);
  
  PROCEDURE PROC_TEST;



end PKG_LC_INDEX_VOLTE_CELL;
/

