create procedure SQL_PROC_PARTITION_ADD_AUTO
IS
--Editor：Shinnosuke
--Updating：2019/05/07
--天级表分区&月级表分区每天进行判断，天级表按日自增，月级表每月月底自增至下月！！！

--Updating：2019/05/08
--1.月级表分区扩展判断条件修正！！！
--2.月级表分区扩展注释修正！！！

---------------------------------------
  ssql varchar2(4000);
  cursor C_JOB   is
  select sql_string from--这里的next_day可行，是因为这里的SQL为动态DDL拼接语句，非单纯的判断条件，被紧跟执行内容！！！
  (
        select
        case
           when s.tm_grn = '2'--每天执行天级表扩展，表分区扩展至sysdate+1
                then 'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_ADD_RANGE('''|| table_name||''','''|| tm_grn ||''','''||to_char(sysdate+1,'yyyymmdd')||''','''||to_char(sysdate+1,'yyyymmdd')||''','''||TABLESPACE_NAME ||''')'
           when s.tm_grn = '3'--每周周三执行，表分区扩展至次周周一
           and trunc(sysdate) = trunc(next_day(sysdate,4))-7
           --and trunc(sysdate,'dd') = last_day(trunc(sysdate, 'mm'))
           --and to_char(sysdate,'yyyymmdd') = '20190626'--测试时间戳
                then 'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_ADD_RANGE('''|| table_name||''','''|| tm_grn ||''','''||to_char(trunc(next_day(sysdate,4)),'yyyymmdd')||''','''||to_char(trunc(next_day(sysdate,4)),'yyyymmdd')||''','''||TABLESPACE_NAME ||''')'
           when s.tm_grn = '4'--每月月底前3天，执行月级表扩展，表分区扩展至次月首日
           and trunc(sysdate) = last_day(trunc(sysdate, 'mm'))-3
                then 'call PKG_MANAGE_SYSTEM_SHIN_PLUS8.PROC_PARTITION_ADD_RANGE('''|| table_name||''','''|| tm_grn ||''','''||to_char(last_day(trunc(sysdate, 'mm'))+1,'yyyymmdd')||''','''||to_char(last_day(trunc(sysdate, 'mm'))+1,'yyyymmdd')||''','''||TABLESPACE_NAME ||''')'
        end as sql_string--拼接分区扩展语句
        from FAST_DATA_PROCESS_TEMPLATE s
        where s.activate_flag = 1
        order by template_id
  )
  where sql_string is not null;
  --定义游标变量 c_row
   c_row c_job%rowtype;
   i number;
   --v_cursor number;
   --v_row number;--行数
   begin
     --SQL_LINE := t_sql_table();
       i := 1;
       open c_job;
               loop
                        fetch c_job into c_row;
                        exit when c_job%notfound;
                        --SQL_LINE.Extend(1);
                        --v_cursor:=dbms_sql.open_cursor;
                        ssql := c_row.sql_string;
                        --dbms_sql.parse(v_cursor,ssql,dbms_sql.native); --分析语句
                        --v_row:=dbms_sql.execute(v_cursor); --执行语句
                        --dbms_sql.close_cursor(v_cursor); --关闭光标
                        --execute immediate ssql;
                        dbms_output.put_line('SQL_LINE_'||i|| ' ：已执行！执行内容：'||ssql||'.
                        ');--执行SQL后输出标记
                        i :=i+1;
               end loop;
       close c_job;
     --return SQL_LINE;
   end;
/

