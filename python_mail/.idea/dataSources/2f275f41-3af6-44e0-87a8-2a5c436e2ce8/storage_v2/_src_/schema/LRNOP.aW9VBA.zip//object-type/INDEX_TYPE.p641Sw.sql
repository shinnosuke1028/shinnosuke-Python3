create TYPE INDEX_TYPE is OBJECT
    (
        TABLE_NAME_TYPE         VARCHAR2(100),
        CONSTRAINT_TYPE         VARCHAR2(30),
        SEARCH_CONDITION_VC     VARCHAR2(50),
        INDEX_VC                VARCHAR2(100),
        TBSPACE                 VARCHAR2(30),
        PART_INDEX_STATUS       VARCHAR2(30),
        NON_PART_TBSPACE        VARCHAR2(30),
        NON_PART_INDEX_STATUS   VARCHAR2(30),
        UNIQUENESS              VARCHAR2(30)
    )
/

