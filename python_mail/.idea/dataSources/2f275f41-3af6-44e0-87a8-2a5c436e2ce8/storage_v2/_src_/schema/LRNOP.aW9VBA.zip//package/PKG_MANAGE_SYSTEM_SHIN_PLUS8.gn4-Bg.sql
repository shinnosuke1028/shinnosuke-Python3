create PACKAGE PKG_MANAGE_SYSTEM_SHIN_PLUS8 AUTHID CURRENT_USER AS
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  Oracle 数据库管理与调度通用包
  --
  --  OWNER:    Shinnosuke
  --
  --  VERSION:   3.6
  --
  --  CREATE DATE： 2019/06/11 version 1.0
  --
  --  UPDATE DATE：2019/06/09 version 1.1
  --               1.分区扩展功能--PROC_PARTITION_ADD_RANGE
  --               2.分区删除功能（暂未启用） --PROC_PARTITION_DROP_RANGE 
  --
  --  UPDATE DATE：2019/06/13 version 1.2
  --               1.增加分区清理功能--PROC_PARTITION_CLEANUP_RANGE
  --
  --  UPDATE DATE：2019/06/18 version 1.3
  --               1.增加分区自动扩展功能--PROC_PARTITION_ADD_AUTO
  --               2.增加分区自动清理功能--PROC_PARTITION_CLEANUP_AUTO
  --
  --  UPDATE DATE：2019/06/19 version 1.4
  --               1.修正分区扩展功能，区分天/月
  --
  --  UPDATE DATE：2019/06/21 version 1.5
  --               1.修正分区扩展功能，增加分区表维度入口参数，区分天/周/月
  --               2.修正分区清理功能，增加分区表维度入口参数 ，区分天/周/月
  --               3.增加分区重建功能Demo --TEST1（暂无分区重建功能）
  --  
  --  UPDATE DATE：2019/06/28 version 2.0
  --               1.修正分区自动扩展功能，区分天/周/月
  --               2.修正分区自动清理功能，区分天/周/月
  --
  --  UPDATE DATE：2019/06/28 version 2.1
  --               1.增加分区重建功能Demo --SQL_GET_DDL（三表流转模式保存数据，A → W → B）
  --               2.修正分区重建功能Demo并更名 --SQL_GET_DDL_WK（两表流转模式保存数据，A → WK_A →(rename to) A）
  --               3.修正分区重建功能Demo --SQL_GET_DDL_WK（暂未开启分区重建数据留存功能）
  --
  --  UPDATE DATE：2019/06/28 version 2.2
  --               1.增加删除表闪回功能
  --               2.修正分区清理功能提示
  --               3.修正分区自动清理功能，适配配置表
  --
  --  UPDATE DATE：2019/07/15 version 2.3
  --               1.增加分区清理功能，兼容SYS自增分区表
  --               2.修正分区自动清理功能，兼容SYS_P*自增分区表，适配配置表
  --               3.修正分区自动清理功能，适配配置表
  --
  --  UPDATE DATE：2019/07/16 version 2.4
  --               1.修正分区重建功能，数据回表时关闭logging
  --               2.修正分区自动清理功能，兼容SYS_P*自增分区表，适配配置表，优化遍历流程
  --               3.修正分区扩展功能，周表扩展
  --
  --  UPDATE DATE：2019/07/19 version 2.5
  --               1.修正分区清理功能，Truncate分区，替换Delete操作
  --
  --  UPDATE DATE：2019/07/22 version 2.6
  --               1.新增分区Truncate功能，大数据清理情况下替换Delete操作
  --               2.修正分区自动清理功能，周/月表告警DBMS打印日志
  --
  --  UPDATE DATE：2019/09/07 version 2.7
  --               1.新增简单日志功能 PROC_LOGGING
  --               2.修正分区自动清理功能，多索引表索引分区性判断（包含主键和普通索引）
  --
  --  UPDATE DATE：2019/09/08 version 2.8
  --               1.二次修正分区自动清理功能，多索引表索引分区性判断（非本地/本地主键、非本地/本地普通Index）
  --
  --  UPDATE DATE：2019/10/16 version 3.0
  --               1.增加分区重建功能Demo --SQL_GET_DDL（不保留原始表，产生的WK表在流转过程中替换掉源表）
  --
  --  UPDATE DATE：2019/10/20 version 3.1
  --               1.修正分区自动清理功能（增加分区是否存在判断，分区不存在，跳过）  
  --
  --  UPDATE DATE：2019/10/31 version 3.2
  --               1.新增分区检索过程，按照时间戳 Locate 并输出分区名
  --
  --  UPDATE DATE：2019/10/31 version 3.3
  --               1.修正分区自动清理功能（修正索引是否分区判断条件，涵盖主键索引&普通全局索引）
  --
  --  UPDATE DATE：2019/11/07 version 3.4
  --               1.修正分区删除功能（优先修正天级分区清理，按时间自动索引分区名并完成删除）
  --
  --  UPDATE DATE：2019/11/18 version 3.5
  --               1.修正分区重建功能（增加表/字段注释迁移，增加源表包含的索引信息展示<不重建>）
  --
  --  UPDATE DATE：2019/11/20 version 3.6
  --               1.修正分区检索过程（区分天/周/月）
  --  
  --  TODO    1.修正分区自动清理功能，适配标准分区格式，同时适配Oracle系统自增分区表的SYS分区格式（Finished）
  --               2.修正分区删除功能（Pending，优先修正天级，已完成天级）
  --               3.增加分区自动删除功能（Pending）
  --               4.修正分区扩展功能（基于分区表），区分小时  --PROC_PARTITION_ADD_RANGE（Pending）
  --               5.评估表分区重建是否需要添加相关过程，通过临时表方式重建老表并添加分区（Finished）
  --               6.评估是否增加进程相关监控信息（增加了简单的过程监控，确认入库程序是否正常）
  --               7.新增 DBMS_SCHEDULER 调度任务系统任务，可保留并预览LOG
------------------------------------------------------------------------


  --Partition Add Manually（分区名格式化：P_20191028）
  PROCEDURE PROC_PARTITION_ADD_RANGE
  (
    V_TBNAME VARCHAR2, V_TM_GRN VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2,
    V_DATE_THRESHOLD_END VARCHAR2, V_TABLESPACE VARCHAR2
  );
  
  --Partition Delete Manually，非Truncate 
  PROCEDURE PROC_PARTITION_CLEANUP_RANGE
  (V_TBNAME VARCHAR2, V_TM_GRN VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2, V_DATE_THRESHOLD_END VARCHAR2);

  --分区高速 Partition Truncate Manually
  PROCEDURE PROC_PARTITION_TRUNCATE_RANGE
  (V_TBNAME VARCHAR2, V_TM_GRN VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2, V_DATE_THRESHOLD_END VARCHAR2);

  --Truncate with Global Index Valid Manually
  PROCEDURE PROC_PARTITION_TRUNCATE_RANGE_INDEX
  (V_TBNAME VARCHAR2, V_TM_GRN VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2, V_DATE_THRESHOLD_END VARCHAR2);

  --Partition Drop Manually
  PROCEDURE PROC_PARTITION_DROP_RANGE(V_TBNAME VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2, V_DATE_THRESHOLD_END VARCHAR2);
  
  --Partition Add Automaticly（分区名格式化：P_20191028）
  PROCEDURE PROC_PARTITION_ADD_AUTO;--分区自动扩展
    
  --Partition Truncate Automaticly（分区名格式化：P_20191028）
  PROCEDURE PROC_PARTITION_CLEANUP_AUTO;--分区自动清理
    
  --Partition Locate
  PROCEDURE PROC_PARTITION_LOCATE(V_TABLE_NAME VARCHAR2, V_DATE_THRESHOLD_START VARCHAR2, V_PARTITION_NAME OUT VARCHAR2);

  --TABLE DDL with WK_Table
  PROCEDURE SQL_GET_DDL_WK
  (
    I_FROM_TABLENAME VARCHAR2, I_TM_GRN VARCHAR2, I_FROM_OWNER VARCHAR2,
    I_TABLESPACE VARCHAR2, I_DATE_THRESHOLD_START VARCHAR2,  I_ENABLE_SYS NUMBER:=0
  );
  
  --TABLE DDL Reborn (without WK_Table)
  PROCEDURE SQL_GET_DDL--和 SQL_GET_DDL_WK 的区别：不产生中间表，DROP源表，确定情况下使用
  (
    I_FROM_TABLENAME VARCHAR2, I_TM_GRN VARCHAR2, I_FROM_OWNER VARCHAR2,
    I_TABLESPACE VARCHAR2, I_DATE_THRESHOLD_START VARCHAR2,  I_ENABLE_SYS NUMBER:=0
  );
  
  --TABLE Drop Manually
  PROCEDURE DROPTABLE_IFEXISTS(I_TABLE_NAME VARCHAR2, PURGE_FLAG NUMBER);

  --简单的过程 Loggging
  PROCEDURE PROC_LOGGING(i_sdate date, i_pkg_name VARCHAR2,  i_inside_loop_log number,  i_exsit_flag number);
  
  PROCEDURE PROC_TEST;--分区自动扩展


END PKG_MANAGE_SYSTEM_SHIN_PLUS8;

/

