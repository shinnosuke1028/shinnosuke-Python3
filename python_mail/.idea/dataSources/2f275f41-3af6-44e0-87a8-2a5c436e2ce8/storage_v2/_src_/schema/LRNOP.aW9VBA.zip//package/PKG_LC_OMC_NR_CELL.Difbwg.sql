create PACKAGE PKG_LC_OMC_NR_CELL AUTHID CURRENT_USER as
------------------------------------------------------------------------
  --  OVERVIEW
  --
  --  5G指标汇总
  --
  --  OWNER:       Shinnosuke
  --
  --  VERSION:     1.2
  --
  --  CREATE DATE: 2019/06/26 version 1.0
  --               1.增加5G小区天/周/月基表数据过程 PROC_OMC_NR_3/8/9/A
  --
  --  UPDATE DATE:2019/06/27 version 1.1
  --               1.增加5G小区天/周/月基表自动调度过程 ACTIVE_OMC_NR_389A_AUTO
  --               2.增加5G小区多维度清单天表过程 PROC_LC_INDEX_5G_DAY
  --               3.修正5G小区天/周/月基表数据过程（改为分区模式汇聚）
  --
  --  UPDATE DATE:2019/08/21 version 1.2
  --               1.该PKG下的5G任务中止
  --
  --  UPDATE DATE:2019/11/18 version 1.3
  --               1.5G所有汇聚任务重做（不含多维度清单天表过程）
  --               2.修正5G小区周/月基表数据过程 
  --               3.修正5G小区天/周/月基表数据过程
  --  
  --  TODO    1.
  --               2.
  --
  --
------------------------------------------------------------------------
  --NR小时级汇聚
  PROCEDURE PROC_OMC_NR_3(V_DATE_THRESHOLD_START VARCHAR2, V_DATE_HOUR VARCHAR2);
  
  --NR天级汇聚
  PROCEDURE PROC_OMC_NR_8(V_DATE_THRESHOLD_START VARCHAR2);
  
  --NR周级汇聚
  PROCEDURE PROC_OMC_NR_9(V_DATE_THRESHOLD_START VARCHAR2);
  
  --NR月级汇聚
  PROCEDURE PROC_OMC_NR_A(V_DATE_THRESHOLD_START VARCHAR2);
  
  --天级别分区指标，暂时关闭
  PROCEDURE PROC_LC_INDEX_5G_DAY(V_DATE_THRESHOLD_START VARCHAR2);

  --5G基表数据周期性汇聚激活
  PROCEDURE ACTIVE_OMC_NR_389A_AUTO;
  
  --5G基表数据汇聚补偿
  PROCEDURE ACTIVE_OMC_NR_389A_SUPPLEMENT(V_DATE_THRESHOLD_START VARCHAR2);


end PKG_LC_OMC_NR_CELL;
/

