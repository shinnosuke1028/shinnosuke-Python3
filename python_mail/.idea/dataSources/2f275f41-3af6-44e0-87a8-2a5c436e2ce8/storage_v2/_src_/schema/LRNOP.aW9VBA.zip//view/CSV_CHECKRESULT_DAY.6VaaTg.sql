create view CSV_CHECKRESULT_DAY as
select pathname,
decode(pathname,'/GSM/CONF/','2G_CM',
'/GSM/KPI/','2G_KPI',
'/LTE/MOBILE/HUAWEI/OMC1/CM/','4G_HW_CM<OMC1>',
'/LTE/MOBILE/HUAWEI/OMC2/CM/','4G_HW_CM<OMC2>',
'/LTE/MOBILE/HUAWEI/OMC1/MR/','4G_HW_MR<OMC1>',
'/LTE/MOBILE/HUAWEI/OMC1/TRACE/','4G_HW_TRACE<OMC1>',
'/LTE/MOBILE/HUAWEI/OMC2/MR/','4G_HW_MR<OMC2>',
'/LTE/MOBILE/HUAWEI/OMC2/TRACE/','4G_HW_TRACE<OMC2>',
'/LTE/MOBILE/NOKIA/OMC1/CM/','4G_NSN_CM',
'/LTE/MOBILE/NOKIA/OMC1/MR1/','4G_NSN_MR',
'/LTE/MOBILE/NOKIA/OMC1/TRACE1/','4G_NSN_TRACE',
'/oradata/LTE/MOBILE/HUAWEI/OMC1/PM/','4G_HW_PM<OMC1>',
'/oradata/LTE/MOBILE/HUAWEI/OMC2/PM/','4G_HW_PM<OMC2>',
'/oradata/LTE/MOBILE/NOKIA/OMC1/PM/','4G_NSN_PM')"data_style<file_path>",
"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31" from
(
  select substr(to_char(s_date, 'yyyymmdd'),7) s_date,
  t.pathname, count(1) as file_num from CHECK_RESULT_2G4G /*partition(P_20190831)*/ t where t.s_date between trunc(sysdate,'mm')- 2 and sysdate group by s_date, pathname
)p
pivot
(
  max(file_num)
  for s_date in
  (
   '01' "1",'02' "2",'03' "3",'04' "4",'05' "5",'06' "6",'07' "7",'08' "8",'09' "9",10"10",11"11",
   12"12",13"13",14"14",15"15",16"16",17"17",18"18",19"19",20"20",21"21",
   22"22",23"23",24"24",25"25",26"26",27"27",28"28",29"29",30"30",31"31"
  )
) order by pathname
/

