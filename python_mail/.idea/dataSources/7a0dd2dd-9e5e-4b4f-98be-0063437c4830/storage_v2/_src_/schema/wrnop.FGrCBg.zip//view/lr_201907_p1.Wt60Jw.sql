create definer = root@`%` view lr_201907_p1 as
select `wrnop`.`mr_intrainterfreq_201907`.`serv_cell_oid`         AS `serv_cell_oid`,
       '01-05'                                                    AS `riqi`,
       count(0)                                                   AS `caiyangdian_cou`,
       count(distinct `wrnop`.`mr_intrainterfreq_201907`.`ue_id`) AS `yonghushu_cou`,
       sum(`wrnop`.`mr_intrainterfreq_201907`.`serv_rscp_dbm`)    AS `sum_rscp`,
       sum(`wrnop`.`mr_intrainterfreq_201907`.`serv_ecio`)        AS `sum_ecio`
from `wrnop`.`mr_intrainterfreq_201907`
where ((`wrnop`.`mr_intrainterfreq_201907`.`time_s` >= '2019-07-01 00:00:00') and
       (`wrnop`.`mr_intrainterfreq_201907`.`time_s` < '2019-07-06 00:00:00'))
group by `wrnop`.`mr_intrainterfreq_201907`.`serv_cell_oid`;

